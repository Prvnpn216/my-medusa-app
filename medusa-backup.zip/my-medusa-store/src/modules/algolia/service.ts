import { algoliasearch, SearchClient } from "algoliasearch"

type AlgoliaOptions = {
  apiKey: string;
  appId: string;
  productIndexName: string;
  productTagIndexName: string;
  productCategoryIndexName: string;
  productCollectionIndexName: string;
  productVariantIndexName: string;
}

export type AlgoliaIndexType = "product" | "tags" | "productCategory" | "productCollection" | "productVariant"

export default class AlgoliaModuleService {
  private client: SearchClient
  private options: AlgoliaOptions

  constructor({}, options: AlgoliaOptions) {
    this.client = algoliasearch(options.appId, options.apiKey)
    this.options = options
  }

  async getIndexName(type: AlgoliaIndexType) {
    switch (type) {
      case "product":
        return this.options.productIndexName
      case "tags":
        return this.options.productTagIndexName
      case "productCategory":
        return this.options.productCategoryIndexName
      case "productCollection":
        return this.options.productCollectionIndexName
      case "productVariant":
        return this.options.productVariantIndexName
      default:
        return this.options.productIndexName
    }
  }

  async indexData(data: Record<string, unknown>[], type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)
    this.client.saveObjects({
      indexName,
      objects: data.map((item) => ({
        ...item,
        // set the object ID to allow updating later
        objectID: item.id,
      })),
    })
  }
  async retrieveFromIndex(objectIDs: string[], type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)
    return await this.client.getObjects<Record<string, unknown>>({
      requests: objectIDs.map((objectID) => ({
        indexName,
        objectID,
      })),
    })
  }

  async deleteFromIndex(objectIDs: string[], type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)
    await this.client.deleteObjects({
      indexName,
      objectIDs,
    })
  }

  async search(query: string, type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)

    if (query === "all") {
      query = "";
      // Fetch all results by paginating through all pages
      const allHits: any[] = []
      let page = 0
      let hasMore = true

      while (hasMore) {
        const response = await this.client.search({
          requests: [
            {
              indexName,
              query,
              hitsPerPage: 1000, // Max per page is 1000
              page,
            },
          ],
        })

        const result = response.results[0] as any
        if (result.hits && Array.isArray(result.hits)) {
          allHits.push(...result.hits)
        }

        // Check if there are more pages
        const totalPages = result.nbPages || 0
        hasMore = page + 1 < totalPages
        page++

        // Safety check to prevent infinite loops
        if (page > 100) {
          break
        }
      }

      // Return a response similar to the original structure but with all hits
      const firstResponse = await this.client.search({
        requests: [
          {
            indexName,
            query,
            hitsPerPage: 1,
          },
        ],
      })

      const firstResult = firstResponse.results[0] as any
      
      return {
        results: [
          {
            ...firstResult,
            hits: allHits,
            nbHits: allHits.length,
            nbPages: 1,
            hitsPerPage: allHits.length,
            page: 0,
          },
        ],
      }
    }

    // Default behavior: return paginated results (max 1000 per page)
    return await this.client.search({
      requests: [
        {
          indexName,
          query,
          hitsPerPage: 1000, // Set to max to get more results in single request
        },
      ],
    })
  }
}