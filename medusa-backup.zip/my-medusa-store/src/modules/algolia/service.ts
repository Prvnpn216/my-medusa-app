import { algoliasearch, SearchClient } from "algoliasearch"
type algoliaFilterResponse = {
  collections: {
      id: string;
      value: string;
  }[];
  categories: {
      id: string;
      value: string;
  }[];
  tags: {
      id: string;
      value: string;
  }[];
};
type AlgoliaOptions = {
  apiKey: string;
  appId: string;
  productIndexName: string;
  productTagIndexName: string;
  productCategoryIndexName: string;
  productCollectionIndexName: string;
  productVariantIndexName: string;
}

export type AlgoliaIndexType = "product" | "tags" | "productCategory" | "productCollection" | "productVariant"

export default class AlgoliaModuleService {
  private client: SearchClient
  private options: AlgoliaOptions

  constructor({}, options: AlgoliaOptions) {
    this.client = algoliasearch(options.appId, options.apiKey)
    this.options = options
  }

  async getIndexName(type: AlgoliaIndexType) {
    switch (type) {
      case "product":
        return this.options.productIndexName
      case "tags":
        return this.options.productTagIndexName
      case "productCategory":
        return this.options.productCategoryIndexName
      case "productCollection":
        return this.options.productCollectionIndexName
      case "productVariant":
        return this.options.productVariantIndexName
      default:
        return this.options.productIndexName
    }
  }

  async indexData(data: Record<string, unknown>[], type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)
    this.client.saveObjects({
      indexName,
      objects: data.map((item) => ({
        ...item,
        // set the object ID to allow updating later
        objectID: item.id,
      })),
    })
  }
  async retrieveFromIndex(objectIDs: string[], type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)
    return await this.client.getObjects<Record<string, unknown>>({
      requests: objectIDs.map((objectID) => ({
        indexName,
        objectID,
      })),
    })
  }

  async deleteFromIndex(objectIDs: string[], type: AlgoliaIndexType = "product") {
    const indexName = await this.getIndexName(type)
    await this.client.deleteObjects({
      indexName,
      objectIDs,
    })
  }

  async search(query: string, type: AlgoliaIndexType = "tags") {
    if (query === "all") {
      // fetch all filters
      const allFilters : algoliaFilterResponse = {
        collections: [],
        categories: [],
        tags: [],
      }
      query = "";
      for(const indexName of ["collections", "categories", "tags"]) {
        // Fetch all results by paginating through all pages
        const allHits: any[] = []
        let page = 0
        let hasMore = true

        while (hasMore) {
          const response = await this.client.search({
            requests: [
              {
                indexName,
                query,
                hitsPerPage: 1000, // Max per page is 1000
                page,
              },
            ],
          })

          const result = response.results[0] as any
          if (result.hits && Array.isArray(result.hits)) {
            allHits.push(...result.hits)
          }

          // Check if there are more pages
          const totalPages = result.nbPages || 0
          hasMore = page + 1 < totalPages
          page++

          // Safety check to prevent infinite loops
          if (page > 100) {
            break
          }
        }
        console.log(indexName,allHits);
        allHits.forEach((hit) => {
          let keyName = Object.keys(hit._highlightResult)[0];
          let indexNameKey = indexName === "categories" ? "category" : indexName.slice(0, -1);
          allFilters[indexName as keyof algoliaFilterResponse].push({
            id: hit.objectID,
            value: hit[keyName][`${indexNameKey}_name`],
          })
        })
      }
      return allFilters;
    }
    else {
      const indexName = await this.getIndexName(type)
      return await this.client.search({
        requests: [
          {
            indexName,
            query,
          },
        ],
      })
    }
  }
}