// src/api/store/filter-product-attributes/route.ts

import { MedusaRequest, MedusaResponse } from "@medusajs/framework/http"
import { ALGOLIA_MODULE } from "../../../modules/algolia"
import AlgoliaModuleService from "../../../modules/algolia/service"
import { z } from "zod"

// Define your request schema (adjust as needed)
export const FilterSchema = z.object({
  query: z.string(),
  // Add other filter parameters as needed
})
type FilterRequest = z.infer<typeof FilterSchema>

type response = {
    collection: {
        id: string;
        value: string;
    }[];
    categories: {
        id: string;
        value: string;
    }[];
    tags: {
        id: string;
        value: string;
    }[];
};

export async function GET(
  req: MedusaRequest<FilterRequest>,
  res: MedusaResponse
) {
  const algoliaModuleService: AlgoliaModuleService = req.scope.resolve(ALGOLIA_MODULE)
  
  // For GET requests, query parameters come from req.query
  const query = req.query.query as string

  // Validate that query parameter is mandatory
  if (!query) {
    return res.status(400).json({
      error: "Query parameter 'query' is required"
    })
  }

  // Validate using the schema to ensure type safety
  const validationResult = FilterSchema.safeParse({ query })
  
  if (!validationResult.success) {
    return res.status(400).json({
      error: "Invalid query parameter",
      details: validationResult.error.errors
    })
  }

  // Call your Algolia service method (implement filtering logic as needed)
  const results = await algoliaModuleService.search(validationResult.data.query, "product")
  results.results.forEach((hit) => {

  })
  res.json(results)
}