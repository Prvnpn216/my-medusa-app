import { MedusaRequest, MedusaResponse } from "@medusajs/framework/http"
import { ALGOLIA_MODULE } from "../../../modules/algolia"
import AlgoliaModuleService, { AlgoliaIndexType } from "../../../modules/algolia/service"

export async function GET(
  req: MedusaRequest,
  res: MedusaResponse
) {
    res.json({
        message: "Hello World",
        status: 200,
        data: {
            name: "John Doe",
            age: 30,
            email: "john.doe@example.com"
        }
    });
//   const algoliaModuleService: AlgoliaModuleService = req.scope.resolve(ALGOLIA_MODULE)
  
//   // Get query parameter from URL query string (optional)
//   const query = (req.query.q as string) || ""

//   // Optional: Get index type from query params (defaults to "product")
//   const type = (req.query.type as AlgoliaIndexType) || "product"

//   // Validate index type if provided
//   const validTypes: AlgoliaIndexType[] = ["product", "tags", "productCategory", "productCollection", "productVariant"]
//   if (req.query.type && !validTypes.includes(type)) {
//     return res.status(400).json({ 
//       error: `Invalid type. Must be one of: ${validTypes.join(", ")}` 
//     })
//   }

//   // Perform search using Algolia (empty query will return all results)
//   const results = await algoliaModuleService.search(query, type)

//   res.json(results)
}

