--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: claim_reason_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.claim_reason_enum AS ENUM (
    'missing_item',
    'wrong_item',
    'production_failure',
    'other'
);


ALTER TYPE public.claim_reason_enum OWNER TO postgres;

--
-- Name: order_claim_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.order_claim_type_enum AS ENUM (
    'refund',
    'replace'
);


ALTER TYPE public.order_claim_type_enum OWNER TO postgres;

--
-- Name: order_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.order_status_enum AS ENUM (
    'pending',
    'completed',
    'draft',
    'archived',
    'canceled',
    'requires_action'
);


ALTER TYPE public.order_status_enum OWNER TO postgres;

--
-- Name: return_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.return_status_enum AS ENUM (
    'open',
    'requested',
    'received',
    'partially_received',
    'canceled'
);


ALTER TYPE public.return_status_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_holder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_holder (
    id text NOT NULL,
    provider_id text NOT NULL,
    external_id text NOT NULL,
    email text,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.account_holder OWNER TO postgres;

--
-- Name: api_key; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    token text NOT NULL,
    salt text NOT NULL,
    redacted text NOT NULL,
    title text NOT NULL,
    type text NOT NULL,
    last_used_at timestamp with time zone,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_by text,
    revoked_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT api_key_type_check CHECK ((type = ANY (ARRAY['publishable'::text, 'secret'::text])))
);


ALTER TABLE public.api_key OWNER TO postgres;

--
-- Name: application_method_buy_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_method_buy_rules (
    application_method_id text NOT NULL,
    promotion_rule_id text NOT NULL
);


ALTER TABLE public.application_method_buy_rules OWNER TO postgres;

--
-- Name: application_method_target_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_method_target_rules (
    application_method_id text NOT NULL,
    promotion_rule_id text NOT NULL
);


ALTER TABLE public.application_method_target_rules OWNER TO postgres;

--
-- Name: auth_identity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_identity (
    id text NOT NULL,
    app_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.auth_identity OWNER TO postgres;

--
-- Name: capture; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.capture (
    id text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    payment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by text,
    metadata jsonb
);


ALTER TABLE public.capture OWNER TO postgres;

--
-- Name: cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart (
    id text NOT NULL,
    region_id text,
    customer_id text,
    sales_channel_id text,
    email text,
    currency_code text NOT NULL,
    shipping_address_id text,
    billing_address_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.cart OWNER TO postgres;

--
-- Name: cart_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_address (
    id text NOT NULL,
    customer_id text,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.cart_address OWNER TO postgres;

--
-- Name: cart_line_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_line_item (
    id text NOT NULL,
    cart_id text NOT NULL,
    title text NOT NULL,
    subtitle text,
    thumbnail text,
    quantity integer NOT NULL,
    variant_id text,
    product_id text,
    product_title text,
    product_description text,
    product_subtitle text,
    product_type text,
    product_collection text,
    product_handle text,
    variant_sku text,
    variant_barcode text,
    variant_title text,
    variant_option_values jsonb,
    requires_shipping boolean DEFAULT true NOT NULL,
    is_discountable boolean DEFAULT true NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    compare_at_unit_price numeric,
    raw_compare_at_unit_price jsonb,
    unit_price numeric NOT NULL,
    raw_unit_price jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    product_type_id text,
    is_custom_price boolean DEFAULT false NOT NULL,
    is_giftcard boolean DEFAULT false NOT NULL,
    CONSTRAINT cart_line_item_unit_price_check CHECK ((unit_price >= (0)::numeric))
);


ALTER TABLE public.cart_line_item OWNER TO postgres;

--
-- Name: cart_line_item_adjustment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_line_item_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    item_id text,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    CONSTRAINT cart_line_item_adjustment_check CHECK ((amount >= (0)::numeric))
);


ALTER TABLE public.cart_line_item_adjustment OWNER TO postgres;

--
-- Name: cart_line_item_tax_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_line_item_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate real NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    item_id text
);


ALTER TABLE public.cart_line_item_tax_line OWNER TO postgres;

--
-- Name: cart_payment_collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_payment_collection (
    cart_id character varying(255) NOT NULL,
    payment_collection_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.cart_payment_collection OWNER TO postgres;

--
-- Name: cart_promotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_promotion (
    cart_id character varying(255) NOT NULL,
    promotion_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.cart_promotion OWNER TO postgres;

--
-- Name: cart_shipping_method; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_shipping_method (
    id text NOT NULL,
    cart_id text NOT NULL,
    name text NOT NULL,
    description jsonb,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    shipping_option_id text,
    data jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT cart_shipping_method_check CHECK ((amount >= (0)::numeric))
);


ALTER TABLE public.cart_shipping_method OWNER TO postgres;

--
-- Name: cart_shipping_method_adjustment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_shipping_method_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    shipping_method_id text
);


ALTER TABLE public.cart_shipping_method_adjustment OWNER TO postgres;

--
-- Name: cart_shipping_method_tax_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_shipping_method_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate real NOT NULL,
    provider_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    shipping_method_id text
);


ALTER TABLE public.cart_shipping_method_tax_line OWNER TO postgres;

--
-- Name: credit_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_line (
    id text NOT NULL,
    cart_id text NOT NULL,
    reference text,
    reference_id text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.credit_line OWNER TO postgres;

--
-- Name: currency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.currency (
    code text NOT NULL,
    symbol text NOT NULL,
    symbol_native text NOT NULL,
    decimal_digits integer DEFAULT 0 NOT NULL,
    rounding numeric DEFAULT 0 NOT NULL,
    raw_rounding jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.currency OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id text NOT NULL,
    company_name text,
    first_name text,
    last_name text,
    email text,
    phone text,
    has_account boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by text
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_account_holder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_account_holder (
    customer_id character varying(255) NOT NULL,
    account_holder_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.customer_account_holder OWNER TO postgres;

--
-- Name: customer_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_address (
    id text NOT NULL,
    customer_id text NOT NULL,
    address_name text,
    is_default_shipping boolean DEFAULT false NOT NULL,
    is_default_billing boolean DEFAULT false NOT NULL,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.customer_address OWNER TO postgres;

--
-- Name: customer_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_group (
    id text NOT NULL,
    name text NOT NULL,
    metadata jsonb,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.customer_group OWNER TO postgres;

--
-- Name: customer_group_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_group_customer (
    id text NOT NULL,
    customer_id text NOT NULL,
    customer_group_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone
);


ALTER TABLE public.customer_group_customer OWNER TO postgres;

--
-- Name: fulfillment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fulfillment (
    id text NOT NULL,
    location_id text NOT NULL,
    packed_at timestamp with time zone,
    shipped_at timestamp with time zone,
    delivered_at timestamp with time zone,
    canceled_at timestamp with time zone,
    data jsonb,
    provider_id text,
    shipping_option_id text,
    metadata jsonb,
    delivery_address_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    marked_shipped_by text,
    created_by text,
    requires_shipping boolean DEFAULT true NOT NULL
);


ALTER TABLE public.fulfillment OWNER TO postgres;

--
-- Name: fulfillment_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fulfillment_address (
    id text NOT NULL,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.fulfillment_address OWNER TO postgres;

--
-- Name: fulfillment_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fulfillment_item (
    id text NOT NULL,
    title text NOT NULL,
    sku text NOT NULL,
    barcode text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    line_item_id text,
    inventory_item_id text,
    fulfillment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.fulfillment_item OWNER TO postgres;

--
-- Name: fulfillment_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fulfillment_label (
    id text NOT NULL,
    tracking_number text NOT NULL,
    tracking_url text NOT NULL,
    label_url text NOT NULL,
    fulfillment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.fulfillment_label OWNER TO postgres;

--
-- Name: fulfillment_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fulfillment_provider (
    id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.fulfillment_provider OWNER TO postgres;

--
-- Name: fulfillment_set; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fulfillment_set (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.fulfillment_set OWNER TO postgres;

--
-- Name: geo_zone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_zone (
    id text NOT NULL,
    type text DEFAULT 'country'::text NOT NULL,
    country_code text NOT NULL,
    province_code text,
    city text,
    service_zone_id text NOT NULL,
    postal_expression jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT geo_zone_type_check CHECK ((type = ANY (ARRAY['country'::text, 'province'::text, 'city'::text, 'zip'::text])))
);


ALTER TABLE public.geo_zone OWNER TO postgres;

--
-- Name: image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.image (
    id text NOT NULL,
    url text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    rank integer DEFAULT 0 NOT NULL,
    product_id text NOT NULL
);


ALTER TABLE public.image OWNER TO postgres;

--
-- Name: inventory_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_item (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    sku text,
    origin_country text,
    hs_code text,
    mid_code text,
    material text,
    weight integer,
    length integer,
    height integer,
    width integer,
    requires_shipping boolean DEFAULT true NOT NULL,
    description text,
    title text,
    thumbnail text,
    metadata jsonb
);


ALTER TABLE public.inventory_item OWNER TO postgres;

--
-- Name: inventory_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_level (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    inventory_item_id text NOT NULL,
    location_id text NOT NULL,
    stocked_quantity numeric DEFAULT 0 NOT NULL,
    reserved_quantity numeric DEFAULT 0 NOT NULL,
    incoming_quantity numeric DEFAULT 0 NOT NULL,
    metadata jsonb,
    raw_stocked_quantity jsonb,
    raw_reserved_quantity jsonb,
    raw_incoming_quantity jsonb
);


ALTER TABLE public.inventory_level OWNER TO postgres;

--
-- Name: invite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invite (
    id text NOT NULL,
    email text NOT NULL,
    accepted boolean DEFAULT false NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.invite OWNER TO postgres;

--
-- Name: link_module_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.link_module_migrations (
    id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    link_descriptor jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.link_module_migrations OWNER TO postgres;

--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.link_module_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.link_module_migrations_id_seq OWNER TO postgres;

--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.link_module_migrations_id_seq OWNED BY public.link_module_migrations.id;


--
-- Name: location_fulfillment_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location_fulfillment_provider (
    stock_location_id character varying(255) NOT NULL,
    fulfillment_provider_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.location_fulfillment_provider OWNER TO postgres;

--
-- Name: location_fulfillment_set; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location_fulfillment_set (
    stock_location_id character varying(255) NOT NULL,
    fulfillment_set_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.location_fulfillment_set OWNER TO postgres;

--
-- Name: mikro_orm_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mikro_orm_migrations (
    id integer NOT NULL,
    name character varying(255),
    executed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.mikro_orm_migrations OWNER TO postgres;

--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mikro_orm_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mikro_orm_migrations_id_seq OWNER TO postgres;

--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mikro_orm_migrations_id_seq OWNED BY public.mikro_orm_migrations.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id text NOT NULL,
    "to" text NOT NULL,
    channel text NOT NULL,
    template text NOT NULL,
    data jsonb,
    trigger_type text,
    resource_id text,
    resource_type text,
    receiver_id text,
    original_notification_id text,
    idempotency_key text,
    external_id text,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    CONSTRAINT notification_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'success'::text, 'failure'::text])))
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_provider (
    id text NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    channels text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.notification_provider OWNER TO postgres;

--
-- Name: order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."order" (
    id text NOT NULL,
    region_id text,
    display_id integer,
    customer_id text,
    version integer DEFAULT 1 NOT NULL,
    sales_channel_id text,
    status public.order_status_enum DEFAULT 'pending'::public.order_status_enum NOT NULL,
    is_draft_order boolean DEFAULT false NOT NULL,
    email text,
    currency_code text NOT NULL,
    shipping_address_id text,
    billing_address_id text,
    no_notification boolean,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    canceled_at timestamp with time zone
);


ALTER TABLE public."order" OWNER TO postgres;

--
-- Name: order_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_address (
    id text NOT NULL,
    customer_id text,
    company text,
    first_name text,
    last_name text,
    address_1 text,
    address_2 text,
    city text,
    country_code text,
    province text,
    postal_code text,
    phone text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_address OWNER TO postgres;

--
-- Name: order_cart; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_cart (
    order_id character varying(255) NOT NULL,
    cart_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_cart OWNER TO postgres;

--
-- Name: order_change; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_change (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer NOT NULL,
    description text,
    status text DEFAULT 'pending'::text NOT NULL,
    internal_note text,
    created_by text,
    requested_by text,
    requested_at timestamp with time zone,
    confirmed_by text,
    confirmed_at timestamp with time zone,
    declined_by text,
    declined_reason text,
    metadata jsonb,
    declined_at timestamp with time zone,
    canceled_by text,
    canceled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    change_type text,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text,
    CONSTRAINT order_change_status_check CHECK ((status = ANY (ARRAY['confirmed'::text, 'declined'::text, 'requested'::text, 'pending'::text, 'canceled'::text])))
);


ALTER TABLE public.order_change OWNER TO postgres;

--
-- Name: order_change_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_change_action (
    id text NOT NULL,
    order_id text,
    version integer,
    ordering bigint NOT NULL,
    order_change_id text,
    reference text,
    reference_id text,
    action text NOT NULL,
    details jsonb,
    amount numeric,
    raw_amount jsonb,
    internal_note text,
    applied boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text
);


ALTER TABLE public.order_change_action OWNER TO postgres;

--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_change_action_ordering_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_change_action_ordering_seq OWNER TO postgres;

--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_change_action_ordering_seq OWNED BY public.order_change_action.ordering;


--
-- Name: order_claim; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_claim (
    id text NOT NULL,
    order_id text NOT NULL,
    return_id text,
    order_version integer NOT NULL,
    display_id integer NOT NULL,
    type public.order_claim_type_enum NOT NULL,
    no_notification boolean,
    refund_amount numeric,
    raw_refund_amount jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    canceled_at timestamp with time zone,
    created_by text
);


ALTER TABLE public.order_claim OWNER TO postgres;

--
-- Name: order_claim_display_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_claim_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_claim_display_id_seq OWNER TO postgres;

--
-- Name: order_claim_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_claim_display_id_seq OWNED BY public.order_claim.display_id;


--
-- Name: order_claim_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_claim_item (
    id text NOT NULL,
    claim_id text NOT NULL,
    item_id text NOT NULL,
    is_additional_item boolean DEFAULT false NOT NULL,
    reason public.claim_reason_enum,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    note text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_claim_item OWNER TO postgres;

--
-- Name: order_claim_item_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_claim_item_image (
    id text NOT NULL,
    claim_item_id text NOT NULL,
    url text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_claim_item_image OWNER TO postgres;

--
-- Name: order_credit_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_credit_line (
    id text NOT NULL,
    order_id text NOT NULL,
    reference text,
    reference_id text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_credit_line OWNER TO postgres;

--
-- Name: order_display_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_display_id_seq OWNER TO postgres;

--
-- Name: order_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_display_id_seq OWNED BY public."order".display_id;


--
-- Name: order_exchange; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_exchange (
    id text NOT NULL,
    order_id text NOT NULL,
    return_id text,
    order_version integer NOT NULL,
    display_id integer NOT NULL,
    no_notification boolean,
    allow_backorder boolean DEFAULT false NOT NULL,
    difference_due numeric,
    raw_difference_due jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    canceled_at timestamp with time zone,
    created_by text
);


ALTER TABLE public.order_exchange OWNER TO postgres;

--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_exchange_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_exchange_display_id_seq OWNER TO postgres;

--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_exchange_display_id_seq OWNED BY public.order_exchange.display_id;


--
-- Name: order_exchange_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_exchange_item (
    id text NOT NULL,
    exchange_id text NOT NULL,
    item_id text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    note text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_exchange_item OWNER TO postgres;

--
-- Name: order_fulfillment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_fulfillment (
    order_id character varying(255) NOT NULL,
    fulfillment_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_fulfillment OWNER TO postgres;

--
-- Name: order_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_item (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer NOT NULL,
    item_id text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    fulfilled_quantity numeric NOT NULL,
    raw_fulfilled_quantity jsonb NOT NULL,
    shipped_quantity numeric NOT NULL,
    raw_shipped_quantity jsonb NOT NULL,
    return_requested_quantity numeric NOT NULL,
    raw_return_requested_quantity jsonb NOT NULL,
    return_received_quantity numeric NOT NULL,
    raw_return_received_quantity jsonb NOT NULL,
    return_dismissed_quantity numeric NOT NULL,
    raw_return_dismissed_quantity jsonb NOT NULL,
    written_off_quantity numeric NOT NULL,
    raw_written_off_quantity jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    delivered_quantity numeric DEFAULT 0 NOT NULL,
    raw_delivered_quantity jsonb NOT NULL,
    unit_price numeric,
    raw_unit_price jsonb,
    compare_at_unit_price numeric,
    raw_compare_at_unit_price jsonb
);


ALTER TABLE public.order_item OWNER TO postgres;

--
-- Name: order_line_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_line_item (
    id text NOT NULL,
    totals_id text,
    title text NOT NULL,
    subtitle text,
    thumbnail text,
    variant_id text,
    product_id text,
    product_title text,
    product_description text,
    product_subtitle text,
    product_type text,
    product_collection text,
    product_handle text,
    variant_sku text,
    variant_barcode text,
    variant_title text,
    variant_option_values jsonb,
    requires_shipping boolean DEFAULT true NOT NULL,
    is_discountable boolean DEFAULT true NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    compare_at_unit_price numeric,
    raw_compare_at_unit_price jsonb,
    unit_price numeric NOT NULL,
    raw_unit_price jsonb NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_custom_price boolean DEFAULT false NOT NULL,
    product_type_id text,
    is_giftcard boolean DEFAULT false NOT NULL
);


ALTER TABLE public.order_line_item OWNER TO postgres;

--
-- Name: order_line_item_adjustment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_line_item_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    item_id text NOT NULL,
    deleted_at timestamp with time zone,
    is_tax_inclusive boolean DEFAULT false NOT NULL
);


ALTER TABLE public.order_line_item_adjustment OWNER TO postgres;

--
-- Name: order_line_item_tax_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_line_item_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate numeric NOT NULL,
    raw_rate jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    item_id text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_line_item_tax_line OWNER TO postgres;

--
-- Name: order_payment_collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_payment_collection (
    order_id character varying(255) NOT NULL,
    payment_collection_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_payment_collection OWNER TO postgres;

--
-- Name: order_promotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_promotion (
    order_id character varying(255) NOT NULL,
    promotion_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_promotion OWNER TO postgres;

--
-- Name: order_shipping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_shipping (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer NOT NULL,
    shipping_method_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text
);


ALTER TABLE public.order_shipping OWNER TO postgres;

--
-- Name: order_shipping_method; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_shipping_method (
    id text NOT NULL,
    name text NOT NULL,
    description jsonb,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    shipping_option_id text,
    data jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_custom_amount boolean DEFAULT false NOT NULL
);


ALTER TABLE public.order_shipping_method OWNER TO postgres;

--
-- Name: order_shipping_method_adjustment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_shipping_method_adjustment (
    id text NOT NULL,
    description text,
    promotion_id text,
    code text,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shipping_method_id text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_shipping_method_adjustment OWNER TO postgres;

--
-- Name: order_shipping_method_tax_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_shipping_method_tax_line (
    id text NOT NULL,
    description text,
    tax_rate_id text,
    code text NOT NULL,
    rate numeric NOT NULL,
    raw_rate jsonb NOT NULL,
    provider_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shipping_method_id text NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_shipping_method_tax_line OWNER TO postgres;

--
-- Name: order_summary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_summary (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    totals jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.order_summary OWNER TO postgres;

--
-- Name: order_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_transaction (
    id text NOT NULL,
    order_id text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    currency_code text NOT NULL,
    reference text,
    reference_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    return_id text,
    claim_id text,
    exchange_id text
);


ALTER TABLE public.order_transaction OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    id text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    currency_code text NOT NULL,
    provider_id text NOT NULL,
    data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    captured_at timestamp with time zone,
    canceled_at timestamp with time zone,
    payment_collection_id text NOT NULL,
    payment_session_id text NOT NULL,
    metadata jsonb
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: payment_collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_collection (
    id text NOT NULL,
    currency_code text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    authorized_amount numeric,
    raw_authorized_amount jsonb,
    captured_amount numeric,
    raw_captured_amount jsonb,
    refunded_amount numeric,
    raw_refunded_amount jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    completed_at timestamp with time zone,
    status text DEFAULT 'not_paid'::text NOT NULL,
    metadata jsonb,
    CONSTRAINT payment_collection_status_check CHECK ((status = ANY (ARRAY['not_paid'::text, 'awaiting'::text, 'authorized'::text, 'partially_authorized'::text, 'canceled'::text, 'failed'::text, 'partially_captured'::text, 'completed'::text])))
);


ALTER TABLE public.payment_collection OWNER TO postgres;

--
-- Name: payment_collection_payment_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_collection_payment_providers (
    payment_collection_id text NOT NULL,
    payment_provider_id text NOT NULL
);


ALTER TABLE public.payment_collection_payment_providers OWNER TO postgres;

--
-- Name: payment_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_provider (
    id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.payment_provider OWNER TO postgres;

--
-- Name: payment_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_session (
    id text NOT NULL,
    currency_code text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    provider_id text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    context jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    authorized_at timestamp with time zone,
    payment_collection_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT payment_session_status_check CHECK ((status = ANY (ARRAY['authorized'::text, 'captured'::text, 'pending'::text, 'requires_more'::text, 'error'::text, 'canceled'::text])))
);


ALTER TABLE public.payment_session OWNER TO postgres;

--
-- Name: price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price (
    id text NOT NULL,
    title text,
    price_set_id text NOT NULL,
    currency_code text NOT NULL,
    raw_amount jsonb NOT NULL,
    rules_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    price_list_id text,
    amount numeric NOT NULL,
    min_quantity integer,
    max_quantity integer
);


ALTER TABLE public.price OWNER TO postgres;

--
-- Name: price_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_list (
    id text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    rules_count integer DEFAULT 0,
    title text NOT NULL,
    description text NOT NULL,
    type text DEFAULT 'sale'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT price_list_status_check CHECK ((status = ANY (ARRAY['active'::text, 'draft'::text]))),
    CONSTRAINT price_list_type_check CHECK ((type = ANY (ARRAY['sale'::text, 'override'::text])))
);


ALTER TABLE public.price_list OWNER TO postgres;

--
-- Name: price_list_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_list_rule (
    id text NOT NULL,
    price_list_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    value jsonb,
    attribute text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.price_list_rule OWNER TO postgres;

--
-- Name: price_preference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_preference (
    id text NOT NULL,
    attribute text NOT NULL,
    value text,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.price_preference OWNER TO postgres;

--
-- Name: price_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_rule (
    id text NOT NULL,
    value text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    price_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    attribute text DEFAULT ''::text NOT NULL,
    operator text DEFAULT 'eq'::text NOT NULL,
    CONSTRAINT price_rule_operator_check CHECK ((operator = ANY (ARRAY['gte'::text, 'lte'::text, 'gt'::text, 'lt'::text, 'eq'::text])))
);


ALTER TABLE public.price_rule OWNER TO postgres;

--
-- Name: price_set; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_set (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.price_set OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    id text NOT NULL,
    title text NOT NULL,
    handle text NOT NULL,
    subtitle text,
    description text,
    is_giftcard boolean DEFAULT false NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    thumbnail text,
    weight text,
    length text,
    height text,
    width text,
    origin_country text,
    hs_code text,
    mid_code text,
    material text,
    collection_id text,
    type_id text,
    discountable boolean DEFAULT true NOT NULL,
    external_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    metadata jsonb,
    CONSTRAINT product_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'proposed'::text, 'published'::text, 'rejected'::text])))
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_category (
    id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    handle text NOT NULL,
    mpath text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    rank integer DEFAULT 0 NOT NULL,
    parent_category_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    metadata jsonb
);


ALTER TABLE public.product_category OWNER TO postgres;

--
-- Name: product_category_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_category_product (
    product_id text NOT NULL,
    product_category_id text NOT NULL
);


ALTER TABLE public.product_category_product OWNER TO postgres;

--
-- Name: product_collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_collection (
    id text NOT NULL,
    title text NOT NULL,
    handle text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_collection OWNER TO postgres;

--
-- Name: product_option; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_option (
    id text NOT NULL,
    title text NOT NULL,
    product_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_option OWNER TO postgres;

--
-- Name: product_option_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_option_value (
    id text NOT NULL,
    value text NOT NULL,
    option_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_option_value OWNER TO postgres;

--
-- Name: product_sales_channel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_sales_channel (
    product_id character varying(255) NOT NULL,
    sales_channel_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_sales_channel OWNER TO postgres;

--
-- Name: product_shipping_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_shipping_profile (
    product_id character varying(255) NOT NULL,
    shipping_profile_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_shipping_profile OWNER TO postgres;

--
-- Name: product_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_tag (
    id text NOT NULL,
    value text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_tag OWNER TO postgres;

--
-- Name: product_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_tags (
    product_id text NOT NULL,
    product_tag_id text NOT NULL
);


ALTER TABLE public.product_tags OWNER TO postgres;

--
-- Name: product_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_type (
    id text NOT NULL,
    value text NOT NULL,
    metadata json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_type OWNER TO postgres;

--
-- Name: product_variant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variant (
    id text NOT NULL,
    title text NOT NULL,
    sku text,
    barcode text,
    ean text,
    upc text,
    allow_backorder boolean DEFAULT false NOT NULL,
    manage_inventory boolean DEFAULT true NOT NULL,
    hs_code text,
    origin_country text,
    mid_code text,
    material text,
    weight integer,
    length integer,
    height integer,
    width integer,
    metadata jsonb,
    variant_rank integer DEFAULT 0,
    product_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_variant OWNER TO postgres;

--
-- Name: product_variant_inventory_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variant_inventory_item (
    variant_id character varying(255) NOT NULL,
    inventory_item_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    required_quantity integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_variant_inventory_item OWNER TO postgres;

--
-- Name: product_variant_option; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variant_option (
    variant_id text NOT NULL,
    option_value_id text NOT NULL
);


ALTER TABLE public.product_variant_option OWNER TO postgres;

--
-- Name: product_variant_price_set; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_variant_price_set (
    variant_id character varying(255) NOT NULL,
    price_set_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.product_variant_price_set OWNER TO postgres;

--
-- Name: promotion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion (
    id text NOT NULL,
    code text NOT NULL,
    campaign_id text,
    is_automatic boolean DEFAULT false NOT NULL,
    type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    status text DEFAULT 'draft'::text NOT NULL,
    is_tax_inclusive boolean DEFAULT false NOT NULL,
    CONSTRAINT promotion_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'active'::text, 'inactive'::text]))),
    CONSTRAINT promotion_type_check CHECK ((type = ANY (ARRAY['standard'::text, 'buyget'::text])))
);


ALTER TABLE public.promotion OWNER TO postgres;

--
-- Name: promotion_application_method; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion_application_method (
    id text NOT NULL,
    value numeric,
    raw_value jsonb,
    max_quantity integer,
    apply_to_quantity integer,
    buy_rules_min_quantity integer,
    type text NOT NULL,
    target_type text NOT NULL,
    allocation text,
    promotion_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    currency_code text,
    CONSTRAINT promotion_application_method_allocation_check CHECK ((allocation = ANY (ARRAY['each'::text, 'across'::text]))),
    CONSTRAINT promotion_application_method_target_type_check CHECK ((target_type = ANY (ARRAY['order'::text, 'shipping_methods'::text, 'items'::text]))),
    CONSTRAINT promotion_application_method_type_check CHECK ((type = ANY (ARRAY['fixed'::text, 'percentage'::text])))
);


ALTER TABLE public.promotion_application_method OWNER TO postgres;

--
-- Name: promotion_campaign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion_campaign (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    campaign_identifier text NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.promotion_campaign OWNER TO postgres;

--
-- Name: promotion_campaign_budget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion_campaign_budget (
    id text NOT NULL,
    type text NOT NULL,
    campaign_id text NOT NULL,
    "limit" numeric,
    raw_limit jsonb,
    used numeric DEFAULT 0 NOT NULL,
    raw_used jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    currency_code text,
    CONSTRAINT promotion_campaign_budget_type_check CHECK ((type = ANY (ARRAY['spend'::text, 'usage'::text])))
);


ALTER TABLE public.promotion_campaign_budget OWNER TO postgres;

--
-- Name: promotion_promotion_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion_promotion_rule (
    promotion_id text NOT NULL,
    promotion_rule_id text NOT NULL
);


ALTER TABLE public.promotion_promotion_rule OWNER TO postgres;

--
-- Name: promotion_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion_rule (
    id text NOT NULL,
    description text,
    attribute text NOT NULL,
    operator text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT promotion_rule_operator_check CHECK ((operator = ANY (ARRAY['gte'::text, 'lte'::text, 'gt'::text, 'lt'::text, 'eq'::text, 'ne'::text, 'in'::text])))
);


ALTER TABLE public.promotion_rule OWNER TO postgres;

--
-- Name: promotion_rule_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.promotion_rule_value (
    id text NOT NULL,
    promotion_rule_id text NOT NULL,
    value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.promotion_rule_value OWNER TO postgres;

--
-- Name: provider_identity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provider_identity (
    id text NOT NULL,
    entity_id text NOT NULL,
    provider text NOT NULL,
    auth_identity_id text NOT NULL,
    user_metadata jsonb,
    provider_metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.provider_identity OWNER TO postgres;

--
-- Name: publishable_api_key_sales_channel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publishable_api_key_sales_channel (
    publishable_key_id character varying(255) NOT NULL,
    sales_channel_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.publishable_api_key_sales_channel OWNER TO postgres;

--
-- Name: refund; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refund (
    id text NOT NULL,
    amount numeric NOT NULL,
    raw_amount jsonb NOT NULL,
    payment_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    created_by text,
    metadata jsonb,
    refund_reason_id text,
    note text
);


ALTER TABLE public.refund OWNER TO postgres;

--
-- Name: refund_reason; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refund_reason (
    id text NOT NULL,
    label text NOT NULL,
    description text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.refund_reason OWNER TO postgres;

--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.region (
    id text NOT NULL,
    name text NOT NULL,
    currency_code text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    automatic_taxes boolean DEFAULT true NOT NULL
);


ALTER TABLE public.region OWNER TO postgres;

--
-- Name: region_country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.region_country (
    iso_2 text NOT NULL,
    iso_3 text NOT NULL,
    num_code text NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL,
    region_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.region_country OWNER TO postgres;

--
-- Name: region_payment_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.region_payment_provider (
    region_id character varying(255) NOT NULL,
    payment_provider_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.region_payment_provider OWNER TO postgres;

--
-- Name: reservation_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservation_item (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    line_item_id text,
    location_id text NOT NULL,
    quantity numeric NOT NULL,
    external_id text,
    description text,
    created_by text,
    metadata jsonb,
    inventory_item_id text NOT NULL,
    allow_backorder boolean DEFAULT false,
    raw_quantity jsonb
);


ALTER TABLE public.reservation_item OWNER TO postgres;

--
-- Name: return; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return (
    id text NOT NULL,
    order_id text NOT NULL,
    claim_id text,
    exchange_id text,
    order_version integer NOT NULL,
    display_id integer NOT NULL,
    status public.return_status_enum DEFAULT 'open'::public.return_status_enum NOT NULL,
    no_notification boolean,
    refund_amount numeric,
    raw_refund_amount jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    received_at timestamp with time zone,
    canceled_at timestamp with time zone,
    location_id text,
    requested_at timestamp with time zone,
    created_by text
);


ALTER TABLE public.return OWNER TO postgres;

--
-- Name: return_display_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.return_display_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.return_display_id_seq OWNER TO postgres;

--
-- Name: return_display_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.return_display_id_seq OWNED BY public.return.display_id;


--
-- Name: return_fulfillment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return_fulfillment (
    return_id character varying(255) NOT NULL,
    fulfillment_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.return_fulfillment OWNER TO postgres;

--
-- Name: return_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return_item (
    id text NOT NULL,
    return_id text NOT NULL,
    reason_id text,
    item_id text NOT NULL,
    quantity numeric NOT NULL,
    raw_quantity jsonb NOT NULL,
    received_quantity numeric DEFAULT 0 NOT NULL,
    raw_received_quantity jsonb NOT NULL,
    note text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    damaged_quantity numeric DEFAULT 0 NOT NULL,
    raw_damaged_quantity jsonb NOT NULL
);


ALTER TABLE public.return_item OWNER TO postgres;

--
-- Name: return_reason; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return_reason (
    id character varying NOT NULL,
    value character varying NOT NULL,
    label character varying NOT NULL,
    description character varying,
    metadata jsonb,
    parent_return_reason_id character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.return_reason OWNER TO postgres;

--
-- Name: sales_channel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_channel (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    is_disabled boolean DEFAULT false NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sales_channel OWNER TO postgres;

--
-- Name: sales_channel_stock_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_channel_stock_location (
    sales_channel_id character varying(255) NOT NULL,
    stock_location_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.sales_channel_stock_location OWNER TO postgres;

--
-- Name: script_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.script_migrations (
    id integer NOT NULL,
    script_name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    finished_at timestamp with time zone
);


ALTER TABLE public.script_migrations OWNER TO postgres;

--
-- Name: script_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.script_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.script_migrations_id_seq OWNER TO postgres;

--
-- Name: script_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.script_migrations_id_seq OWNED BY public.script_migrations.id;


--
-- Name: service_zone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_zone (
    id text NOT NULL,
    name text NOT NULL,
    metadata jsonb,
    fulfillment_set_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.service_zone OWNER TO postgres;

--
-- Name: shipping_option; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_option (
    id text NOT NULL,
    name text NOT NULL,
    price_type text DEFAULT 'flat'::text NOT NULL,
    service_zone_id text NOT NULL,
    shipping_profile_id text,
    provider_id text,
    data jsonb,
    metadata jsonb,
    shipping_option_type_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT shipping_option_price_type_check CHECK ((price_type = ANY (ARRAY['calculated'::text, 'flat'::text])))
);


ALTER TABLE public.shipping_option OWNER TO postgres;

--
-- Name: shipping_option_price_set; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_option_price_set (
    shipping_option_id character varying(255) NOT NULL,
    price_set_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.shipping_option_price_set OWNER TO postgres;

--
-- Name: shipping_option_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_option_rule (
    id text NOT NULL,
    attribute text NOT NULL,
    operator text NOT NULL,
    value jsonb,
    shipping_option_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT shipping_option_rule_operator_check CHECK ((operator = ANY (ARRAY['in'::text, 'eq'::text, 'ne'::text, 'gt'::text, 'gte'::text, 'lt'::text, 'lte'::text, 'nin'::text])))
);


ALTER TABLE public.shipping_option_rule OWNER TO postgres;

--
-- Name: shipping_option_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_option_type (
    id text NOT NULL,
    label text NOT NULL,
    description text,
    code text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.shipping_option_type OWNER TO postgres;

--
-- Name: shipping_profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_profile (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.shipping_profile OWNER TO postgres;

--
-- Name: stock_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_location (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    name text NOT NULL,
    address_id text,
    metadata jsonb
);


ALTER TABLE public.stock_location OWNER TO postgres;

--
-- Name: stock_location_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_location_address (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    address_1 text NOT NULL,
    address_2 text,
    company text,
    city text,
    country_code text NOT NULL,
    phone text,
    province text,
    postal_code text,
    metadata jsonb
);


ALTER TABLE public.stock_location_address OWNER TO postgres;

--
-- Name: store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store (
    id text NOT NULL,
    name text DEFAULT 'Medusa Store'::text NOT NULL,
    default_sales_channel_id text,
    default_region_id text,
    default_location_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.store OWNER TO postgres;

--
-- Name: store_currency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_currency (
    id text NOT NULL,
    currency_code text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    store_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.store_currency OWNER TO postgres;

--
-- Name: tax_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_provider (
    id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.tax_provider OWNER TO postgres;

--
-- Name: tax_rate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_rate (
    id text NOT NULL,
    rate real,
    code text NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    is_combinable boolean DEFAULT false NOT NULL,
    tax_region_id text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone
);


ALTER TABLE public.tax_rate OWNER TO postgres;

--
-- Name: tax_rate_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_rate_rule (
    id text NOT NULL,
    tax_rate_id text NOT NULL,
    reference_id text NOT NULL,
    reference text NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone
);


ALTER TABLE public.tax_rate_rule OWNER TO postgres;

--
-- Name: tax_region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_region (
    id text NOT NULL,
    provider_id text,
    country_code text NOT NULL,
    province_code text,
    parent_id text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by text,
    deleted_at timestamp with time zone,
    CONSTRAINT "CK_tax_region_country_top_level" CHECK (((parent_id IS NULL) OR (province_code IS NOT NULL))),
    CONSTRAINT "CK_tax_region_provider_top_level" CHECK (((parent_id IS NULL) OR (provider_id IS NULL)))
);


ALTER TABLE public.tax_region OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id text NOT NULL,
    first_name text,
    last_name text,
    email text NOT NULL,
    avatar_url text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: workflow_execution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_execution (
    id character varying NOT NULL,
    workflow_id character varying NOT NULL,
    transaction_id character varying NOT NULL,
    execution jsonb,
    context jsonb,
    state character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    deleted_at timestamp without time zone,
    retention_time integer,
    run_id text DEFAULT '01K27T4P5QSQD1Z114DHN4WSYA'::text NOT NULL
);


ALTER TABLE public.workflow_execution OWNER TO postgres;

--
-- Name: link_module_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.link_module_migrations ALTER COLUMN id SET DEFAULT nextval('public.link_module_migrations_id_seq'::regclass);


--
-- Name: mikro_orm_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mikro_orm_migrations ALTER COLUMN id SET DEFAULT nextval('public.mikro_orm_migrations_id_seq'::regclass);


--
-- Name: order display_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order" ALTER COLUMN display_id SET DEFAULT nextval('public.order_display_id_seq'::regclass);


--
-- Name: order_change_action ordering; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_change_action ALTER COLUMN ordering SET DEFAULT nextval('public.order_change_action_ordering_seq'::regclass);


--
-- Name: order_claim display_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_claim ALTER COLUMN display_id SET DEFAULT nextval('public.order_claim_display_id_seq'::regclass);


--
-- Name: order_exchange display_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_exchange ALTER COLUMN display_id SET DEFAULT nextval('public.order_exchange_display_id_seq'::regclass);


--
-- Name: return display_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return ALTER COLUMN display_id SET DEFAULT nextval('public.return_display_id_seq'::regclass);


--
-- Name: script_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.script_migrations ALTER COLUMN id SET DEFAULT nextval('public.script_migrations_id_seq'::regclass);


--
-- Data for Name: account_holder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_holder (id, provider_id, external_id, email, data, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_key (id, token, salt, redacted, title, type, last_used_at, created_by, created_at, revoked_by, revoked_at, updated_at, deleted_at) FROM stdin;
apk_01K38QHGS8NSABW09ZF273XPKW	pk_c3621bf8218f2a41edaf9f214bac663152eb47ef06f5111ffad7fd877af07bdb		pk_c36***bdb	Webshop	publishable	\N		2025-08-22 11:10:09.193+00	\N	\N	2025-08-22 11:10:09.193+00	\N
\.


--
-- Data for Name: application_method_buy_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_method_buy_rules (application_method_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: application_method_target_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_method_target_rules (application_method_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: auth_identity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_identity (id, app_metadata, created_at, updated_at, deleted_at) FROM stdin;
authid_01K27V4FXYQF7W5TPGGESNWANY	{"user_id": "user_01K27V4FV6AXTXHH3DB727SCX7"}	2025-08-09 16:38:00.383+00	2025-08-09 16:38:00.389+00	\N
\.


--
-- Data for Name: capture; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.capture (id, amount, raw_amount, payment_id, created_at, updated_at, deleted_at, created_by, metadata) FROM stdin;
\.


--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart (id, region_id, customer_id, sales_channel_id, email, currency_code, shipping_address_id, billing_address_id, metadata, created_at, updated_at, deleted_at, completed_at) FROM stdin;
cart_01K4MEHRZGD0FFASA64GDC9YPR	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	\N	sc_01K38QHGFZCEZW38YRKKMXN51C	\N	inr	\N	\N	\N	2025-09-08 10:39:35.409+00	2025-09-08 10:39:35.409+00	\N	\N
\.


--
-- Data for Name: cart_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_address (id, customer_id, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_line_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_line_item (id, cart_id, title, subtitle, thumbnail, quantity, variant_id, product_id, product_title, product_description, product_subtitle, product_type, product_collection, product_handle, variant_sku, variant_barcode, variant_title, variant_option_values, requires_shipping, is_discountable, is_tax_inclusive, compare_at_unit_price, raw_compare_at_unit_price, unit_price, raw_unit_price, metadata, created_at, updated_at, deleted_at, product_type_id, is_custom_price, is_giftcard) FROM stdin;
cali_01K4MEHS4JWKKFHB4M0TKC1GD3	cart_01K4MEHRZGD0FFASA64GDC9YPR	Premium Cordyceps Militaris Ultra-Fine Powder - Rapid Energy & ATP Boost	Powder Extract Pack of 3	http://localhost:9000/static/1757251232174-Morel.jpeg	10	variant_01K3VPE6P185HB2AZR6CKXAWV7	prod_01K3VPE6KPYPFJ0893VJAV152B	Premium Cordyceps Militaris Ultra-Fine Powder - Rapid Energy & ATP Boost	Unlock Natural Energy Excellence with Premium Cordyceps Militaris Ultra-Fine Powder\n\nExperience the pinnacle of functional mushroom supplementation with our Premium Cordyceps Militaris Ultra-Fine Powder—meticulously crafted to deliver rapid energy enhancement and ATP cellular support for peak performance and vitality.\n\nWhat Makes Our Cordyceps Special:\n🔬 Science-Backed Energy Support\nOur premium Cordyceps militaris contains high concentrations of cordycepin (3'-deoxyadenosine) and adenosine—bioactive nucleosides that directly support ATP production at the cellular level. These compounds enhance your body's natural energy-generating pathways, providing sustained vitality without crashes.\n\n⚡ Ultra-Fine Processing for Maximum Absorption\nUnlike standard mushroom powders, our ultra-fine milling process breaks down cell walls to create microscopic particles that significantly enhance bioavailability. This advanced processing ensures faster absorption and more efficient utilization of active compounds by your body.\n\n🏃‍♂️ Performance & Endurance Benefits\n\nEnhanced VO₂ Max: Studies show Cordyceps militaris supplementation at 4g daily improves oxygen consumption and exercise tolerance\n\nATP Production: Upregulates energy-producing pathways including AMPK, GLUT4, and phosphocreatine for sustained cellular energy\n\nOxygen Utilization: Improves blood oxygen saturation (95%) and reduces fatigue during high-intensity activities\n\nExercise Recovery: Supports faster recovery through enhanced metabolic efficiency\n\nPremium Quality & Purity:\n✅ 100% Pure Cordyceps Militaris Fruiting Bodies - No mycelium or fillers\n✅ Optimal Cordycepin Content: 325-377mg per 100g for maximum potency\n✅ Low-Temperature Dried at 60°C to preserve bioactive compounds\n✅ Third-Party Tested for purity and potency\n✅ Non-GMO & Pesticide-Free cultivation methods\n\nHow to Use:\nDaily Dosage: 1-2 teaspoons (2-4g) daily for optimal benefits\n\nEasy Integration:\n\nMorning Energy: Mix into coffee, tea, or warm water for natural awakening\n\nPre-Workout: Blend into smoothies 30 minutes before exercise for enhanced performance\n\nAnytime Boost: Stir into juices, protein shakes, or yogurt\n\nTaste Profile: Mild, earthy flavor with subtle nutty undertones—easily masked in beverages and foods\n\nStorage & Freshness:\nStore in a cool, dry place away from direct sunlight. Reseal tightly after use to maintain potency and freshness. Our powder maintains quality for 24 months when stored properly.\n\nSafety & Considerations:\nGenerally well-tolerated with daily use\n\nConsult healthcare provider if pregnant, nursing, or taking blood-thinning medications\n\nNot recommended for individuals with autoimmune conditions\n\nStart with smaller doses to assess individual tolerance\n\nThe CORDYCEPS Difference:\nHigher Bioactive Content: Our Cordyceps militaris contains significantly higher cordycepin levels compared to traditional Cordyceps sinensis, ensuring superior potency and effectiveness.\n\nSustainable Cultivation: Grown in controlled environments using organic substrates, ensuring consistent quality and eliminating contamination risks associated with wild-harvested varieties.\n\nATP-Focused Formula: Specifically processed to maximize compounds that support cellular energy production, making it ideal for athletes, professionals, and anyone seeking natural energy enhancement.\n\nExperience the transformative power of premium Cordyceps militaris—your natural pathway to sustained energy, enhanced performance, and optimal vitality.\n\nThese statements have not been evaluated by the FDA. This product is not intended to diagnose, treat, cure, or prevent any disease.	Cordyceps-militaris-powder	\N	Brain Boosting	premium-cordyceps-militaris-ultra-fine-powder-rapid-energy-and-atp-boost	\N	\N	Powder Extract Pack of 3	\N	t	t	f	\N	\N	2700	{"value": "2700", "precision": 20}	{}	2025-09-08 10:39:35.57+00	2025-09-08 10:39:57.551+00	2025-09-08 10:39:57.551+00	\N	f	f
\.


--
-- Data for Name: cart_line_item_adjustment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_line_item_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, metadata, created_at, updated_at, deleted_at, item_id, is_tax_inclusive) FROM stdin;
\.


--
-- Data for Name: cart_line_item_tax_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_line_item_tax_line (id, description, tax_rate_id, code, rate, provider_id, metadata, created_at, updated_at, deleted_at, item_id) FROM stdin;
\.


--
-- Data for Name: cart_payment_collection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_payment_collection (cart_id, payment_collection_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_promotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_promotion (cart_id, promotion_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_shipping_method; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_shipping_method (id, cart_id, name, description, amount, raw_amount, is_tax_inclusive, shipping_option_id, data, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: cart_shipping_method_adjustment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_shipping_method_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, metadata, created_at, updated_at, deleted_at, shipping_method_id) FROM stdin;
\.


--
-- Data for Name: cart_shipping_method_tax_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_shipping_method_tax_line (id, description, tax_rate_id, code, rate, provider_id, metadata, created_at, updated_at, deleted_at, shipping_method_id) FROM stdin;
\.


--
-- Data for Name: credit_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_line (id, cart_id, reference, reference_id, amount, raw_amount, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.currency (code, symbol, symbol_native, decimal_digits, rounding, raw_rounding, name, created_at, updated_at, deleted_at) FROM stdin;
usd	$	$	2	0	{"value": "0", "precision": 20}	US Dollar	2025-08-09 16:20:40.042+00	2025-08-09 16:20:40.043+00	\N
cad	CA$	$	2	0	{"value": "0", "precision": 20}	Canadian Dollar	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
eur	€	€	2	0	{"value": "0", "precision": 20}	Euro	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
aed	AED	د.إ.‏	2	0	{"value": "0", "precision": 20}	United Arab Emirates Dirham	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
afn	Af	؋	0	0	{"value": "0", "precision": 20}	Afghan Afghani	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
all	ALL	Lek	0	0	{"value": "0", "precision": 20}	Albanian Lek	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
amd	AMD	դր.	0	0	{"value": "0", "precision": 20}	Armenian Dram	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
ars	AR$	$	2	0	{"value": "0", "precision": 20}	Argentine Peso	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
aud	AU$	$	2	0	{"value": "0", "precision": 20}	Australian Dollar	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
azn	man.	ман.	2	0	{"value": "0", "precision": 20}	Azerbaijani Manat	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
bam	KM	KM	2	0	{"value": "0", "precision": 20}	Bosnia-Herzegovina Convertible Mark	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
bdt	Tk	৳	2	0	{"value": "0", "precision": 20}	Bangladeshi Taka	2025-08-09 16:20:40.043+00	2025-08-09 16:20:40.043+00	\N
bgn	BGN	лв.	2	0	{"value": "0", "precision": 20}	Bulgarian Lev	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
bhd	BD	د.ب.‏	3	0	{"value": "0", "precision": 20}	Bahraini Dinar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
bif	FBu	FBu	0	0	{"value": "0", "precision": 20}	Burundian Franc	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
bnd	BN$	$	2	0	{"value": "0", "precision": 20}	Brunei Dollar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
bob	Bs	Bs	2	0	{"value": "0", "precision": 20}	Bolivian Boliviano	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
brl	R$	R$	2	0	{"value": "0", "precision": 20}	Brazilian Real	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
bwp	BWP	P	2	0	{"value": "0", "precision": 20}	Botswanan Pula	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
byn	Br	руб.	2	0	{"value": "0", "precision": 20}	Belarusian Ruble	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
bzd	BZ$	$	2	0	{"value": "0", "precision": 20}	Belize Dollar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
cdf	CDF	FrCD	2	0	{"value": "0", "precision": 20}	Congolese Franc	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
chf	CHF	CHF	2	0.05	{"value": "0.05", "precision": 20}	Swiss Franc	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
clp	CL$	$	0	0	{"value": "0", "precision": 20}	Chilean Peso	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
cny	CN¥	CN¥	2	0	{"value": "0", "precision": 20}	Chinese Yuan	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
cop	CO$	$	0	0	{"value": "0", "precision": 20}	Colombian Peso	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
crc	₡	₡	0	0	{"value": "0", "precision": 20}	Costa Rican Colón	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
cve	CV$	CV$	2	0	{"value": "0", "precision": 20}	Cape Verdean Escudo	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
czk	Kč	Kč	2	0	{"value": "0", "precision": 20}	Czech Republic Koruna	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
djf	Fdj	Fdj	0	0	{"value": "0", "precision": 20}	Djiboutian Franc	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
dkk	Dkr	kr	2	0	{"value": "0", "precision": 20}	Danish Krone	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
dop	RD$	RD$	2	0	{"value": "0", "precision": 20}	Dominican Peso	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
dzd	DA	د.ج.‏	2	0	{"value": "0", "precision": 20}	Algerian Dinar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
eek	Ekr	kr	2	0	{"value": "0", "precision": 20}	Estonian Kroon	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
egp	EGP	ج.م.‏	2	0	{"value": "0", "precision": 20}	Egyptian Pound	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
ern	Nfk	Nfk	2	0	{"value": "0", "precision": 20}	Eritrean Nakfa	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
etb	Br	Br	2	0	{"value": "0", "precision": 20}	Ethiopian Birr	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
gbp	£	£	2	0	{"value": "0", "precision": 20}	British Pound Sterling	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
gel	GEL	GEL	2	0	{"value": "0", "precision": 20}	Georgian Lari	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
ghs	GH₵	GH₵	2	0	{"value": "0", "precision": 20}	Ghanaian Cedi	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
gnf	FG	FG	0	0	{"value": "0", "precision": 20}	Guinean Franc	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
gtq	GTQ	Q	2	0	{"value": "0", "precision": 20}	Guatemalan Quetzal	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
hkd	HK$	$	2	0	{"value": "0", "precision": 20}	Hong Kong Dollar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
hnl	HNL	L	2	0	{"value": "0", "precision": 20}	Honduran Lempira	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
hrk	kn	kn	2	0	{"value": "0", "precision": 20}	Croatian Kuna	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
huf	Ft	Ft	0	0	{"value": "0", "precision": 20}	Hungarian Forint	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
idr	Rp	Rp	0	0	{"value": "0", "precision": 20}	Indonesian Rupiah	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
ils	₪	₪	2	0	{"value": "0", "precision": 20}	Israeli New Sheqel	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
inr	Rs	₹	2	0	{"value": "0", "precision": 20}	Indian Rupee	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
iqd	IQD	د.ع.‏	0	0	{"value": "0", "precision": 20}	Iraqi Dinar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
irr	IRR	﷼	0	0	{"value": "0", "precision": 20}	Iranian Rial	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
isk	Ikr	kr	0	0	{"value": "0", "precision": 20}	Icelandic Króna	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
jmd	J$	$	2	0	{"value": "0", "precision": 20}	Jamaican Dollar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
jod	JD	د.أ.‏	3	0	{"value": "0", "precision": 20}	Jordanian Dinar	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
jpy	¥	￥	0	0	{"value": "0", "precision": 20}	Japanese Yen	2025-08-09 16:20:40.044+00	2025-08-09 16:20:40.044+00	\N
kes	Ksh	Ksh	2	0	{"value": "0", "precision": 20}	Kenyan Shilling	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
khr	KHR	៛	2	0	{"value": "0", "precision": 20}	Cambodian Riel	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
kmf	CF	FC	0	0	{"value": "0", "precision": 20}	Comorian Franc	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
krw	₩	₩	0	0	{"value": "0", "precision": 20}	South Korean Won	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
kwd	KD	د.ك.‏	3	0	{"value": "0", "precision": 20}	Kuwaiti Dinar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
kzt	KZT	тңг.	2	0	{"value": "0", "precision": 20}	Kazakhstani Tenge	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
lbp	LB£	ل.ل.‏	0	0	{"value": "0", "precision": 20}	Lebanese Pound	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
lkr	SLRs	SL Re	2	0	{"value": "0", "precision": 20}	Sri Lankan Rupee	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
ltl	Lt	Lt	2	0	{"value": "0", "precision": 20}	Lithuanian Litas	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
lvl	Ls	Ls	2	0	{"value": "0", "precision": 20}	Latvian Lats	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
lyd	LD	د.ل.‏	3	0	{"value": "0", "precision": 20}	Libyan Dinar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mad	MAD	د.م.‏	2	0	{"value": "0", "precision": 20}	Moroccan Dirham	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mdl	MDL	MDL	2	0	{"value": "0", "precision": 20}	Moldovan Leu	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mga	MGA	MGA	0	0	{"value": "0", "precision": 20}	Malagasy Ariary	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mkd	MKD	MKD	2	0	{"value": "0", "precision": 20}	Macedonian Denar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mmk	MMK	K	0	0	{"value": "0", "precision": 20}	Myanma Kyat	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mnt	MNT	₮	0	0	{"value": "0", "precision": 20}	Mongolian Tugrig	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mop	MOP$	MOP$	2	0	{"value": "0", "precision": 20}	Macanese Pataca	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mur	MURs	MURs	0	0	{"value": "0", "precision": 20}	Mauritian Rupee	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mwk	K	K	2	0	{"value": "0", "precision": 20}	Malawian Kwacha	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mxn	MX$	$	2	0	{"value": "0", "precision": 20}	Mexican Peso	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
myr	RM	RM	2	0	{"value": "0", "precision": 20}	Malaysian Ringgit	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
mzn	MTn	MTn	2	0	{"value": "0", "precision": 20}	Mozambican Metical	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
nad	N$	N$	2	0	{"value": "0", "precision": 20}	Namibian Dollar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
ngn	₦	₦	2	0	{"value": "0", "precision": 20}	Nigerian Naira	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
nio	C$	C$	2	0	{"value": "0", "precision": 20}	Nicaraguan Córdoba	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
nok	Nkr	kr	2	0	{"value": "0", "precision": 20}	Norwegian Krone	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
npr	NPRs	नेरू	2	0	{"value": "0", "precision": 20}	Nepalese Rupee	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
nzd	NZ$	$	2	0	{"value": "0", "precision": 20}	New Zealand Dollar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
omr	OMR	ر.ع.‏	3	0	{"value": "0", "precision": 20}	Omani Rial	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
pab	B/.	B/.	2	0	{"value": "0", "precision": 20}	Panamanian Balboa	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
pen	S/.	S/.	2	0	{"value": "0", "precision": 20}	Peruvian Nuevo Sol	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
php	₱	₱	2	0	{"value": "0", "precision": 20}	Philippine Peso	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
pkr	PKRs	₨	0	0	{"value": "0", "precision": 20}	Pakistani Rupee	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
pln	zł	zł	2	0	{"value": "0", "precision": 20}	Polish Zloty	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
pyg	₲	₲	0	0	{"value": "0", "precision": 20}	Paraguayan Guarani	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
qar	QR	ر.ق.‏	2	0	{"value": "0", "precision": 20}	Qatari Rial	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
ron	RON	RON	2	0	{"value": "0", "precision": 20}	Romanian Leu	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
rsd	din.	дин.	0	0	{"value": "0", "precision": 20}	Serbian Dinar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
rub	RUB	₽.	2	0	{"value": "0", "precision": 20}	Russian Ruble	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
rwf	RWF	FR	0	0	{"value": "0", "precision": 20}	Rwandan Franc	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
sar	SR	ر.س.‏	2	0	{"value": "0", "precision": 20}	Saudi Riyal	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
sdg	SDG	SDG	2	0	{"value": "0", "precision": 20}	Sudanese Pound	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
sek	Skr	kr	2	0	{"value": "0", "precision": 20}	Swedish Krona	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
sgd	S$	$	2	0	{"value": "0", "precision": 20}	Singapore Dollar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
sos	Ssh	Ssh	0	0	{"value": "0", "precision": 20}	Somali Shilling	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
syp	SY£	ل.س.‏	0	0	{"value": "0", "precision": 20}	Syrian Pound	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
thb	฿	฿	2	0	{"value": "0", "precision": 20}	Thai Baht	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
tnd	DT	د.ت.‏	3	0	{"value": "0", "precision": 20}	Tunisian Dinar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
top	T$	T$	2	0	{"value": "0", "precision": 20}	Tongan Paʻanga	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
try	₺	₺	2	0	{"value": "0", "precision": 20}	Turkish Lira	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
ttd	TT$	$	2	0	{"value": "0", "precision": 20}	Trinidad and Tobago Dollar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
twd	NT$	NT$	2	0	{"value": "0", "precision": 20}	New Taiwan Dollar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
tzs	TSh	TSh	0	0	{"value": "0", "precision": 20}	Tanzanian Shilling	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
uah	₴	₴	2	0	{"value": "0", "precision": 20}	Ukrainian Hryvnia	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
ugx	USh	USh	0	0	{"value": "0", "precision": 20}	Ugandan Shilling	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
uyu	$U	$	2	0	{"value": "0", "precision": 20}	Uruguayan Peso	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
uzs	UZS	UZS	0	0	{"value": "0", "precision": 20}	Uzbekistan Som	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
vef	Bs.F.	Bs.F.	2	0	{"value": "0", "precision": 20}	Venezuelan Bolívar	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
vnd	₫	₫	0	0	{"value": "0", "precision": 20}	Vietnamese Dong	2025-08-09 16:20:40.045+00	2025-08-09 16:20:40.045+00	\N
xaf	FCFA	FCFA	0	0	{"value": "0", "precision": 20}	CFA Franc BEAC	2025-08-09 16:20:40.046+00	2025-08-09 16:20:40.046+00	\N
xof	CFA	CFA	0	0	{"value": "0", "precision": 20}	CFA Franc BCEAO	2025-08-09 16:20:40.046+00	2025-08-09 16:20:40.046+00	\N
yer	YR	ر.ي.‏	0	0	{"value": "0", "precision": 20}	Yemeni Rial	2025-08-09 16:20:40.046+00	2025-08-09 16:20:40.046+00	\N
zar	R	R	2	0	{"value": "0", "precision": 20}	South African Rand	2025-08-09 16:20:40.046+00	2025-08-09 16:20:40.046+00	\N
zmk	ZK	ZK	0	0	{"value": "0", "precision": 20}	Zambian Kwacha	2025-08-09 16:20:40.046+00	2025-08-09 16:20:40.046+00	\N
zwl	ZWL$	ZWL$	0	0	{"value": "0", "precision": 20}	Zimbabwean Dollar	2025-08-09 16:20:40.046+00	2025-08-09 16:20:40.046+00	\N
xpf	₣	₣	0	0	{"value": "0", "precision": 20}	CFP Franc	2025-08-15 06:47:27.158+00	2025-08-15 06:47:27.158+00	\N
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, company_name, first_name, last_name, email, phone, has_account, metadata, created_at, updated_at, deleted_at, created_by) FROM stdin;
\.


--
-- Data for Name: customer_account_holder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_account_holder (customer_id, account_holder_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: customer_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_address (id, customer_id, address_name, is_default_shipping, is_default_billing, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: customer_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_group (id, name, metadata, created_by, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: customer_group_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_group_customer (id, customer_id, customer_group_id, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fulfillment (id, location_id, packed_at, shipped_at, delivered_at, canceled_at, data, provider_id, shipping_option_id, metadata, delivery_address_id, created_at, updated_at, deleted_at, marked_shipped_by, created_by, requires_shipping) FROM stdin;
\.


--
-- Data for Name: fulfillment_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fulfillment_address (id, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fulfillment_item (id, title, sku, barcode, quantity, raw_quantity, line_item_id, inventory_item_id, fulfillment_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fulfillment_label (id, tracking_number, tracking_url, label_url, fulfillment_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: fulfillment_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fulfillment_provider (id, is_enabled, created_at, updated_at, deleted_at) FROM stdin;
manual_manual	t	2025-08-09 16:20:40.106+00	2025-08-09 16:20:40.106+00	\N
\.


--
-- Data for Name: fulfillment_set; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fulfillment_set (id, name, type, metadata, created_at, updated_at, deleted_at) FROM stdin;
fuset_01K27T4TFSTKJT6YXD3JEHNA4R	European Warehouse delivery	shipping	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.188+00	2025-08-18 18:01:28.187+00
fuset_01K38QHGK537HYCDV6VQY2A2KX	European Warehouse delivery	shipping	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.5+00	2025-08-22 12:10:55.499+00
\.


--
-- Data for Name: geo_zone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_zone (id, type, country_code, province_code, city, service_zone_id, postal_expression, metadata, created_at, updated_at, deleted_at) FROM stdin;
fgz_01K27T4TFRC9H9CQ0H3DS875WG	country	gb	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.205+00	2025-08-18 18:01:28.187+00
fgz_01K27T4TFRXBTRKXH0PS9BWH5E	country	de	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
fgz_01K27T4TFRRHY5RY9CWRPH54AV	country	dk	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
fgz_01K27T4TFRZQ1Q5M3FKMDPSRY0	country	se	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
fgz_01K27T4TFRG1YG42YD0T9QBZ3Q	country	fr	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
fgz_01K27T4TFR0CCQYCNFNAX2K7KC	country	es	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
fgz_01K27T4TFRFM79YC79HS1XH65X	country	it	\N	\N	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	\N	\N	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
fgz_01K38QHGK5QY8D4EW43ERFDZQP	country	gb	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
fgz_01K38QHGK5N4X9CZBV74WPQNSE	country	de	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
fgz_01K38QHGK57ES29FNYSQFHHGEF	country	dk	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
fgz_01K38QHGK5EA1ZBWR8QKB4ZK9N	country	se	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
fgz_01K38QHGK5E6K81JDFHQ4AC5CD	country	fr	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
fgz_01K38QHGK5MFHGK3S5PAN6XX1G	country	es	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
fgz_01K38QHGK52W9H2PQP17XEE0Q2	country	it	\N	\N	serzo_01K38QHGK5FE3HZZA64GQXRHMS	\N	\N	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.52+00	2025-08-22 12:10:55.499+00
\.


--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.image (id, url, metadata, created_at, updated_at, deleted_at, rank, product_id) FROM stdin;
img_01K4J5ACFJ4F05EMX1XJAV8SHS	http://localhost:9000/static/1757251187106-Turkey%20Tail.png	\N	2025-09-07 13:19:47.186+00	2025-09-07 13:19:47.186+00	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5
img_01K4J5BRFS68N9P9CPVV05J1QG	http://localhost:9000/static/1757251232174-Morel.jpeg	\N	2025-09-07 13:20:32.25+00	2025-09-07 13:20:32.25+00	\N	0	prod_01K3VPE6KPYPFJ0893VJAV152B
img_01K4J5CZ4QMZYMDDSDYA7WF09V	http://localhost:9000/static/1757251271783-Cordyceps-senesis.png	\N	2025-09-07 13:21:11.831+00	2025-09-07 13:21:11.831+00	\N	0	prod_01K3X8E8Q6311HVXSSH879A5A1
\.


--
-- Data for Name: inventory_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_item (id, created_at, updated_at, deleted_at, sku, origin_country, hs_code, mid_code, material, weight, length, height, width, requires_shipping, description, title, thumbnail, metadata) FROM stdin;
iitem_01K3C0EX0F9KTDTAPTP5526AMV	2025-08-23 17:43:43.888+00	2025-08-23 19:01:15.273+00	2025-08-23 19:01:15.272+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	60 Grams Pack 	60 Grams Pack 	\N	\N
iitem_01K3C6E17GM11CHQ2W4KKBKNSR	2025-08-23 19:28:06.897+00	2025-08-23 19:28:06.897+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Dried Fruiting Body	Dried Fruiting Body	\N	\N
iitem_01K3C6FN7GM3JFEQHGEWW44CHT	2025-08-23 19:29:00.145+00	2025-08-23 19:29:00.145+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Dried Fruiting Body Pack of 2	Dried Fruiting Body Pack of 2	\N	\N
iitem_01K3C6HRD39E77M0793SW4VK1Z	2025-08-23 19:30:08.931+00	2025-08-23 19:30:08.931+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Dried Fruiting Body Pack of 3	Dried Fruiting Body Pack of 3	\N	\N
iitem_01K3C6MEN719BCAS12N6SCRM26	2025-08-23 19:31:37.256+00	2025-08-29 19:40:15.773+00	2025-08-29 19:40:15.773+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Liquid Extract	Liquid Extract	\N	\N
iitem_01K3C6NJZ9GEKA190ERS3DGRFK	2025-08-23 19:32:14.441+00	2025-08-29 19:40:20.607+00	2025-08-29 19:40:20.607+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Liquid Extract Pack of 2	Liquid Extract Pack of 2	\N	\N
iitem_01K3C6PPHKN9S3GDQARRBZVSJX	2025-08-23 19:32:50.867+00	2025-08-29 19:40:24.505+00	2025-08-29 19:40:24.505+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Liquid Extract Pack of 3	Liquid Extract Pack of 3	\N	\N
iitem_01K3C6QVF54G051CQH5DJYP26W	2025-08-23 19:33:28.677+00	2025-08-29 19:40:28.019+00	2025-08-29 19:40:28.019+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Powdered Extract	Powdered Extract	\N	\N
iitem_01K3C6S8F1GEVMW4Y7AWQJ2533	2025-08-23 19:34:14.754+00	2025-08-29 19:40:31.527+00	2025-08-29 19:40:31.527+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Powdered Extract Pack of 2	Powdered Extract Pack of 2	\N	\N
iitem_01K3C6YYAKS5S8YQ0AGFMTJJ6Y	2025-08-23 19:37:20.98+00	2025-08-29 19:40:35.971+00	2025-08-29 19:40:35.971+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Powderd Extract Pack of 3	Powderd Extract Pack of 3	\N	\N
iitem_01K3VPE6PRCD1J9JXSEEACMCZA	2025-08-29 19:56:26.201+00	2025-08-29 19:56:26.201+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Powder Extract	Powder Extract	\N	\N
iitem_01K3VPE6PRWTREC7V5R3WN4KKJ	2025-08-29 19:56:26.201+00	2025-08-29 19:56:26.201+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Powder Extract Pack of 2	Powder Extract Pack of 2	\N	\N
iitem_01K3VPE6PRQHNN26Y3NVQT20G3	2025-08-29 19:56:26.201+00	2025-08-29 19:56:26.201+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Powder Extract Pack of 3	Powder Extract Pack of 3	\N	\N
iitem_01K3X8E8TENK0PSCJVEWN64KJ4	2025-08-30 10:30:17.167+00	2025-08-30 10:30:17.167+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Liquid Extract	Liquid Extract	\N	\N
iitem_01K3X8E8TE8YK7HC90Y9QSQTPX	2025-08-30 10:30:17.167+00	2025-08-30 10:30:17.167+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Liquid Extract Pack of 2	Liquid Extract Pack of 2	\N	\N
iitem_01K3X8E8TFAKTE13GD3VVCXDNK	2025-08-30 10:30:17.167+00	2025-08-30 10:30:17.167+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	Liquid Extract Pack of 3	Liquid Extract Pack of 3	\N	\N
\.


--
-- Data for Name: inventory_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_level (id, created_at, updated_at, deleted_at, inventory_item_id, location_id, stocked_quantity, reserved_quantity, incoming_quantity, metadata, raw_stocked_quantity, raw_reserved_quantity, raw_incoming_quantity) FROM stdin;
\.


--
-- Data for Name: invite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invite (id, email, accepted, token, expires_at, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: link_module_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.link_module_migrations (id, table_name, link_descriptor, created_at) FROM stdin;
1	cart_promotion	{"toModel": "promotions", "toModule": "promotion", "fromModel": "cart", "fromModule": "cart"}	2025-08-09 16:20:38.525602
2	location_fulfillment_provider	{"toModel": "fulfillment_provider", "toModule": "fulfillment", "fromModel": "location", "fromModule": "stock_location"}	2025-08-09 16:20:38.525885
3	location_fulfillment_set	{"toModel": "fulfillment_set", "toModule": "fulfillment", "fromModel": "location", "fromModule": "stock_location"}	2025-08-09 16:20:38.526029
4	order_promotion	{"toModel": "promotions", "toModule": "promotion", "fromModel": "order", "fromModule": "order"}	2025-08-09 16:20:38.526559
6	order_fulfillment	{"toModel": "fulfillments", "toModule": "fulfillment", "fromModel": "order", "fromModule": "order"}	2025-08-09 16:20:38.526401
5	order_cart	{"toModel": "cart", "toModule": "cart", "fromModel": "order", "fromModule": "order"}	2025-08-09 16:20:38.52629
8	return_fulfillment	{"toModel": "fulfillments", "toModule": "fulfillment", "fromModel": "return", "fromModule": "order"}	2025-08-09 16:20:38.526668
7	order_payment_collection	{"toModel": "payment_collection", "toModule": "payment", "fromModel": "order", "fromModule": "order"}	2025-08-09 16:20:38.526483
9	product_sales_channel	{"toModel": "sales_channel", "toModule": "sales_channel", "fromModel": "product", "fromModule": "product"}	2025-08-09 16:20:38.52963
10	product_variant_inventory_item	{"toModel": "inventory", "toModule": "inventory", "fromModel": "variant", "fromModule": "product"}	2025-08-09 16:20:38.529775
11	product_variant_price_set	{"toModel": "price_set", "toModule": "pricing", "fromModel": "variant", "fromModule": "product"}	2025-08-09 16:20:38.542145
12	publishable_api_key_sales_channel	{"toModel": "sales_channel", "toModule": "sales_channel", "fromModel": "api_key", "fromModule": "api_key"}	2025-08-09 16:20:38.54309
13	region_payment_provider	{"toModel": "payment_provider", "toModule": "payment", "fromModel": "region", "fromModule": "region"}	2025-08-09 16:20:38.54346
14	sales_channel_stock_location	{"toModel": "location", "toModule": "stock_location", "fromModel": "sales_channel", "fromModule": "sales_channel"}	2025-08-09 16:20:38.543578
15	shipping_option_price_set	{"toModel": "price_set", "toModule": "pricing", "fromModel": "shipping_option", "fromModule": "fulfillment"}	2025-08-09 16:20:38.543731
16	product_shipping_profile	{"toModel": "shipping_profile", "toModule": "fulfillment", "fromModel": "product", "fromModule": "product"}	2025-08-09 16:20:38.543786
17	customer_account_holder	{"toModel": "account_holder", "toModule": "payment", "fromModel": "customer", "fromModule": "customer"}	2025-08-09 16:20:38.543925
18	cart_payment_collection	{"toModel": "payment_collection", "toModule": "payment", "fromModel": "cart", "fromModule": "cart"}	2025-08-09 16:20:38.543989
\.


--
-- Data for Name: location_fulfillment_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location_fulfillment_provider (stock_location_id, fulfillment_provider_id, id, created_at, updated_at, deleted_at) FROM stdin;
sloc_01K27T4TFFAZ3896MP60BEWGD6	manual_manual	locfp_01K27T4TFKE6BPWS9MG00XH0FP	2025-08-09 16:20:42.611269+00	2025-08-18 18:01:28.179+00	2025-08-18 18:01:28.178+00
sloc_01K38QHGJF0Z7BZ1CV0JN6PFP4	manual_manual	locfp_01K38QHGJSCQQ6BYQ4H8S6AV3T	2025-08-22 11:10:08.985059+00	2025-08-22 12:10:55.491+00	2025-08-22 12:10:55.49+00
\.


--
-- Data for Name: location_fulfillment_set; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location_fulfillment_set (stock_location_id, fulfillment_set_id, id, created_at, updated_at, deleted_at) FROM stdin;
sloc_01K27T4TFFAZ3896MP60BEWGD6	fuset_01K27T4TFSTKJT6YXD3JEHNA4R	locfs_01K27T4TFZ9QYRS5SDMPCRKARE	2025-08-09 16:20:42.623401+00	2025-08-18 18:01:28.177+00	2025-08-18 18:01:28.176+00
sloc_01K38QHGJF0Z7BZ1CV0JN6PFP4	fuset_01K38QHGK537HYCDV6VQY2A2KX	locfs_01K38QHGKH4M4WMQHCDSEDNDHT	2025-08-22 11:10:09.009546+00	2025-08-22 12:10:55.492+00	2025-08-22 12:10:55.492+00
\.


--
-- Data for Name: mikro_orm_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mikro_orm_migrations (id, name, executed_at) FROM stdin;
1	Migration20240307161216	2025-08-09 16:20:36.678902+00
2	Migration20241210073813	2025-08-09 16:20:36.678902+00
3	Migration20250106142624	2025-08-09 16:20:36.678902+00
4	Migration20250120110820	2025-08-09 16:20:36.678902+00
5	Migration20240307132720	2025-08-09 16:20:36.730139+00
6	Migration20240719123015	2025-08-09 16:20:36.730139+00
7	Migration20241213063611	2025-08-09 16:20:36.730139+00
8	InitialSetup20240401153642	2025-08-09 16:20:36.802609+00
9	Migration20240601111544	2025-08-09 16:20:36.802609+00
10	Migration202408271511	2025-08-09 16:20:36.802609+00
11	Migration20241122120331	2025-08-09 16:20:36.802609+00
12	Migration20241125090957	2025-08-09 16:20:36.802609+00
13	Migration20250411073236	2025-08-09 16:20:36.802609+00
14	Migration20250516081326	2025-08-09 16:20:36.802609+00
15	Migration20230929122253	2025-08-09 16:20:36.950892+00
16	Migration20240322094407	2025-08-09 16:20:36.950892+00
17	Migration20240322113359	2025-08-09 16:20:36.950892+00
18	Migration20240322120125	2025-08-09 16:20:36.950892+00
19	Migration20240626133555	2025-08-09 16:20:36.950892+00
20	Migration20240704094505	2025-08-09 16:20:36.950892+00
21	Migration20241127114534	2025-08-09 16:20:36.950892+00
22	Migration20241127223829	2025-08-09 16:20:36.950892+00
23	Migration20241128055359	2025-08-09 16:20:36.950892+00
24	Migration20241212190401	2025-08-09 16:20:36.950892+00
25	Migration20250408145122	2025-08-09 16:20:36.950892+00
26	Migration20250409122219	2025-08-09 16:20:36.950892+00
27	Migration20240227120221	2025-08-09 16:20:37.081685+00
28	Migration20240617102917	2025-08-09 16:20:37.081685+00
29	Migration20240624153824	2025-08-09 16:20:37.081685+00
30	Migration20241211061114	2025-08-09 16:20:37.081685+00
31	Migration20250113094144	2025-08-09 16:20:37.081685+00
32	Migration20250120110700	2025-08-09 16:20:37.081685+00
33	Migration20250226130616	2025-08-09 16:20:37.081685+00
34	Migration20250508081510	2025-08-09 16:20:37.081685+00
35	Migration20240124154000	2025-08-09 16:20:37.190006+00
36	Migration20240524123112	2025-08-09 16:20:37.190006+00
37	Migration20240602110946	2025-08-09 16:20:37.190006+00
38	Migration20241211074630	2025-08-09 16:20:37.190006+00
39	Migration20240115152146	2025-08-09 16:20:37.240367+00
40	Migration20240222170223	2025-08-09 16:20:37.262432+00
41	Migration20240831125857	2025-08-09 16:20:37.262432+00
42	Migration20241106085918	2025-08-09 16:20:37.262432+00
43	Migration20241205095237	2025-08-09 16:20:37.262432+00
44	Migration20241216183049	2025-08-09 16:20:37.262432+00
45	Migration20241218091938	2025-08-09 16:20:37.262432+00
46	Migration20250120115059	2025-08-09 16:20:37.262432+00
47	Migration20250212131240	2025-08-09 16:20:37.262432+00
48	Migration20250326151602	2025-08-09 16:20:37.262432+00
49	Migration20250508081553	2025-08-09 16:20:37.262432+00
50	Migration20240205173216	2025-08-09 16:20:37.359363+00
51	Migration20240624200006	2025-08-09 16:20:37.359363+00
52	Migration20250120110744	2025-08-09 16:20:37.359363+00
53	InitialSetup20240221144943	2025-08-09 16:20:37.398023+00
54	Migration20240604080145	2025-08-09 16:20:37.398023+00
55	Migration20241205122700	2025-08-09 16:20:37.398023+00
56	InitialSetup20240227075933	2025-08-09 16:20:37.423471+00
57	Migration20240621145944	2025-08-09 16:20:37.423471+00
58	Migration20241206083313	2025-08-09 16:20:37.423471+00
59	Migration20240227090331	2025-08-09 16:20:37.451396+00
60	Migration20240710135844	2025-08-09 16:20:37.451396+00
61	Migration20240924114005	2025-08-09 16:20:37.451396+00
62	Migration20241212052837	2025-08-09 16:20:37.451396+00
63	InitialSetup20240228133303	2025-08-09 16:20:37.503387+00
64	Migration20240624082354	2025-08-09 16:20:37.503387+00
65	Migration20240225134525	2025-08-09 16:20:37.524962+00
66	Migration20240806072619	2025-08-09 16:20:37.524962+00
67	Migration20241211151053	2025-08-09 16:20:37.524962+00
68	Migration20250115160517	2025-08-09 16:20:37.524962+00
69	Migration20250120110552	2025-08-09 16:20:37.524962+00
70	Migration20250123122334	2025-08-09 16:20:37.524962+00
71	Migration20250206105639	2025-08-09 16:20:37.524962+00
72	Migration20250207132723	2025-08-09 16:20:37.524962+00
73	Migration20250625084134	2025-08-09 16:20:37.524962+00
74	Migration20240219102530	2025-08-09 16:20:37.635766+00
75	Migration20240604100512	2025-08-09 16:20:37.635766+00
76	Migration20240715102100	2025-08-09 16:20:37.635766+00
77	Migration20240715174100	2025-08-09 16:20:37.635766+00
78	Migration20240716081800	2025-08-09 16:20:37.635766+00
79	Migration20240801085921	2025-08-09 16:20:37.635766+00
80	Migration20240821164505	2025-08-09 16:20:37.635766+00
81	Migration20240821170920	2025-08-09 16:20:37.635766+00
82	Migration20240827133639	2025-08-09 16:20:37.635766+00
83	Migration20240902195921	2025-08-09 16:20:37.635766+00
84	Migration20240913092514	2025-08-09 16:20:37.635766+00
85	Migration20240930122627	2025-08-09 16:20:37.635766+00
86	Migration20241014142943	2025-08-09 16:20:37.635766+00
87	Migration20241106085223	2025-08-09 16:20:37.635766+00
88	Migration20241129124827	2025-08-09 16:20:37.635766+00
89	Migration20241217162224	2025-08-09 16:20:37.635766+00
90	Migration20250326151554	2025-08-09 16:20:37.635766+00
91	Migration20250522181137	2025-08-09 16:20:37.635766+00
92	Migration20250702095353	2025-08-09 16:20:37.635766+00
93	Migration20250704120229	2025-08-09 16:20:37.635766+00
94	Migration20240205025928	2025-08-09 16:20:37.835058+00
95	Migration20240529080336	2025-08-09 16:20:37.835058+00
96	Migration20241202100304	2025-08-09 16:20:37.835058+00
97	Migration20240214033943	2025-08-09 16:20:37.901813+00
98	Migration20240703095850	2025-08-09 16:20:37.901813+00
99	Migration20241202103352	2025-08-09 16:20:37.901813+00
100	Migration20240311145700_InitialSetupMigration	2025-08-09 16:20:37.941822+00
101	Migration20240821170957	2025-08-09 16:20:37.941822+00
102	Migration20240917161003	2025-08-09 16:20:37.941822+00
103	Migration20241217110416	2025-08-09 16:20:37.941822+00
104	Migration20250113122235	2025-08-09 16:20:37.941822+00
105	Migration20250120115002	2025-08-09 16:20:37.941822+00
106	Migration20240509083918_InitialSetupMigration	2025-08-09 16:20:38.084138+00
107	Migration20240628075401	2025-08-09 16:20:38.084138+00
108	Migration20240830094712	2025-08-09 16:20:38.084138+00
109	Migration20250120110514	2025-08-09 16:20:38.084138+00
110	Migration20231228143900	2025-08-09 16:20:38.180842+00
111	Migration20241206101446	2025-08-09 16:20:38.180842+00
112	Migration20250128174331	2025-08-09 16:20:38.180842+00
113	Migration20250505092459	2025-08-09 16:20:38.180842+00
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, "to", channel, template, data, trigger_type, resource_id, resource_type, receiver_id, original_notification_id, idempotency_key, external_id, provider_id, created_at, updated_at, deleted_at, status) FROM stdin;
\.


--
-- Data for Name: notification_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_provider (id, handle, name, is_enabled, channels, created_at, updated_at, deleted_at) FROM stdin;
local	local	local	t	{feed}	2025-08-09 16:20:40.113+00	2025-08-09 16:20:40.113+00	\N
\.


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."order" (id, region_id, display_id, customer_id, version, sales_channel_id, status, is_draft_order, email, currency_code, shipping_address_id, billing_address_id, no_notification, metadata, created_at, updated_at, deleted_at, canceled_at) FROM stdin;
\.


--
-- Data for Name: order_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_address (id, customer_id, company, first_name, last_name, address_1, address_2, city, country_code, province, postal_code, phone, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_cart; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_cart (order_id, cart_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_change; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_change (id, order_id, version, description, status, internal_note, created_by, requested_by, requested_at, confirmed_by, confirmed_at, declined_by, declined_reason, metadata, declined_at, canceled_by, canceled_at, created_at, updated_at, change_type, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: order_change_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_change_action (id, order_id, version, ordering, order_change_id, reference, reference_id, action, details, amount, raw_amount, internal_note, applied, created_at, updated_at, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: order_claim; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_claim (id, order_id, return_id, order_version, display_id, type, no_notification, refund_amount, raw_refund_amount, metadata, created_at, updated_at, deleted_at, canceled_at, created_by) FROM stdin;
\.


--
-- Data for Name: order_claim_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_claim_item (id, claim_id, item_id, is_additional_item, reason, quantity, raw_quantity, note, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_claim_item_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_claim_item_image (id, claim_item_id, url, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_credit_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_credit_line (id, order_id, reference, reference_id, amount, raw_amount, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_exchange; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_exchange (id, order_id, return_id, order_version, display_id, no_notification, allow_backorder, difference_due, raw_difference_due, metadata, created_at, updated_at, deleted_at, canceled_at, created_by) FROM stdin;
\.


--
-- Data for Name: order_exchange_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_exchange_item (id, exchange_id, item_id, quantity, raw_quantity, note, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_fulfillment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_fulfillment (order_id, fulfillment_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_item (id, order_id, version, item_id, quantity, raw_quantity, fulfilled_quantity, raw_fulfilled_quantity, shipped_quantity, raw_shipped_quantity, return_requested_quantity, raw_return_requested_quantity, return_received_quantity, raw_return_received_quantity, return_dismissed_quantity, raw_return_dismissed_quantity, written_off_quantity, raw_written_off_quantity, metadata, created_at, updated_at, deleted_at, delivered_quantity, raw_delivered_quantity, unit_price, raw_unit_price, compare_at_unit_price, raw_compare_at_unit_price) FROM stdin;
\.


--
-- Data for Name: order_line_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_line_item (id, totals_id, title, subtitle, thumbnail, variant_id, product_id, product_title, product_description, product_subtitle, product_type, product_collection, product_handle, variant_sku, variant_barcode, variant_title, variant_option_values, requires_shipping, is_discountable, is_tax_inclusive, compare_at_unit_price, raw_compare_at_unit_price, unit_price, raw_unit_price, metadata, created_at, updated_at, deleted_at, is_custom_price, product_type_id, is_giftcard) FROM stdin;
\.


--
-- Data for Name: order_line_item_adjustment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_line_item_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, created_at, updated_at, item_id, deleted_at, is_tax_inclusive) FROM stdin;
\.


--
-- Data for Name: order_line_item_tax_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_line_item_tax_line (id, description, tax_rate_id, code, rate, raw_rate, provider_id, created_at, updated_at, item_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_payment_collection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_payment_collection (order_id, payment_collection_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_promotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_promotion (order_id, promotion_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_shipping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_shipping (id, order_id, version, shipping_method_id, created_at, updated_at, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: order_shipping_method; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_shipping_method (id, name, description, amount, raw_amount, is_tax_inclusive, shipping_option_id, data, metadata, created_at, updated_at, deleted_at, is_custom_amount) FROM stdin;
\.


--
-- Data for Name: order_shipping_method_adjustment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_shipping_method_adjustment (id, description, promotion_id, code, amount, raw_amount, provider_id, created_at, updated_at, shipping_method_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_shipping_method_tax_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_shipping_method_tax_line (id, description, tax_rate_id, code, rate, raw_rate, provider_id, created_at, updated_at, shipping_method_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_summary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_summary (id, order_id, version, totals, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: order_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_transaction (id, order_id, version, amount, raw_amount, currency_code, reference, reference_id, created_at, updated_at, deleted_at, return_id, claim_id, exchange_id) FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (id, amount, raw_amount, currency_code, provider_id, data, created_at, updated_at, deleted_at, captured_at, canceled_at, payment_collection_id, payment_session_id, metadata) FROM stdin;
\.


--
-- Data for Name: payment_collection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_collection (id, currency_code, amount, raw_amount, authorized_amount, raw_authorized_amount, captured_amount, raw_captured_amount, refunded_amount, raw_refunded_amount, created_at, updated_at, deleted_at, completed_at, status, metadata) FROM stdin;
\.


--
-- Data for Name: payment_collection_payment_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_collection_payment_providers (payment_collection_id, payment_provider_id) FROM stdin;
\.


--
-- Data for Name: payment_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_provider (id, is_enabled, created_at, updated_at, deleted_at) FROM stdin;
pp_system_default	t	2025-08-09 16:20:40.109+00	2025-08-09 16:20:40.109+00	\N
\.


--
-- Data for Name: payment_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_session (id, currency_code, amount, raw_amount, provider_id, data, context, status, authorized_at, payment_collection_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price (id, title, price_set_id, currency_code, raw_amount, rules_count, created_at, updated_at, deleted_at, price_list_id, amount, min_quantity, max_quantity) FROM stdin;
price_01K27T4TN4V2HN907W1GJDA759	\N	pset_01K27T4TN5N7TCS6PHX3RPDDD9	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.448+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN5SHDT25GQSNK4CAES	\N	pset_01K27T4TN5N7TCS6PHX3RPDDD9	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.448+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN547HT7K0DR56MA311	\N	pset_01K27T4TN5T5WJYG5WYWV3ZHBE	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.454+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN51ARTPGCFBWBHS204	\N	pset_01K27T4TN5T5WJYG5WYWV3ZHBE	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.454+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN5RDMXQ05VRBY9W1T1	\N	pset_01K27T4TN57XJHK52JSSW1DDN0	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.459+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN50Z97AVHDFNMMC3MY	\N	pset_01K27T4TN57XJHK52JSSW1DDN0	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.459+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN7WQKX4WX1T3EZFPNC	\N	pset_01K27T4TN7FG4YXMWYEK2EYAVT	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.898+00	2025-08-18 17:51:00.893+00	\N	10	\N	\N
price_01K27T4TN7DWW5NTXFM087VFQ6	\N	pset_01K27T4TN7FG4YXMWYEK2EYAVT	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.898+00	2025-08-18 17:51:00.893+00	\N	15	\N	\N
price_01K27T4TN8QXHVAC4V31JYW9F8	\N	pset_01K27T4TN8EMDCA0S7AP4C5JTT	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.908+00	2025-08-18 17:51:00.893+00	\N	10	\N	\N
price_01K27T4TN8MGTQQYM4QV049J4A	\N	pset_01K27T4TN8EMDCA0S7AP4C5JTT	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.908+00	2025-08-18 17:51:00.893+00	\N	15	\N	\N
price_01K27T4TN8QJMWS8BRWF6W7YAN	\N	pset_01K27T4TN8F0H5WSJKQQ0RSMW2	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.914+00	2025-08-18 17:51:00.893+00	\N	10	\N	\N
price_01K27T4TN8FZEP0ERZWMCM2DJ6	\N	pset_01K27T4TN8F0H5WSJKQQ0RSMW2	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.914+00	2025-08-18 17:51:00.893+00	\N	15	\N	\N
price_01K27T4TN8GPA97MMJYR8HWYWS	\N	pset_01K27T4TN8WAKYNMGWHHGAJ9CV	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.919+00	2025-08-18 17:51:00.893+00	\N	10	\N	\N
price_01K27T4TN8H4Z4HT2PHRC7YCRC	\N	pset_01K27T4TN8WAKYNMGWHHGAJ9CV	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:00.919+00	2025-08-18 17:51:00.893+00	\N	15	\N	\N
price_01K27T4TN6V0QP24XZ0A7EB7FB	\N	pset_01K27T4TN7M50BGJ71Z92ZSXAN	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.037+00	2025-08-18 17:51:05.033+00	\N	10	\N	\N
price_01K27T4TN7QHNH0E2QW5T8WC6E	\N	pset_01K27T4TN7M50BGJ71Z92ZSXAN	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.037+00	2025-08-18 17:51:05.033+00	\N	15	\N	\N
price_01K27T4TN7W0290V2JECE9EMY5	\N	pset_01K27T4TN7VT24P3E4FPDHDTE0	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.043+00	2025-08-18 17:51:05.033+00	\N	10	\N	\N
price_01K27T4TN76T7MQ909RDW7HQ7N	\N	pset_01K27T4TN7VT24P3E4FPDHDTE0	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.043+00	2025-08-18 17:51:05.033+00	\N	15	\N	\N
price_01K27T4TN75DXAN3BQBHZEFST2	\N	pset_01K27T4TN7HPE7K6GQRVC0KTWR	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.049+00	2025-08-18 17:51:05.033+00	\N	10	\N	\N
price_01K27T4TN7HMD0GA9659KEARDB	\N	pset_01K27T4TN7HPE7K6GQRVC0KTWR	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.049+00	2025-08-18 17:51:05.033+00	\N	15	\N	\N
price_01K27T4TN76XXH3KCTVES1SBEY	\N	pset_01K27T4TN7R913W8WRJVW59NQ9	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.053+00	2025-08-18 17:51:05.033+00	\N	10	\N	\N
price_01K27T4TN70CZ44P34HN5XJKE7	\N	pset_01K27T4TN7R913W8WRJVW59NQ9	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:51:05.053+00	2025-08-18 17:51:05.033+00	\N	15	\N	\N
price_01K27T4TGS2J70Y6XEJV0W7NVR	\N	pset_01K27T4TGT2CRRZ18PXB1NQN6E	usd	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.255+00	2025-08-18 18:01:28.247+00	\N	10	\N	\N
price_01K27T4TGSHRRVC5X02J7BA626	\N	pset_01K27T4TGT2CRRZ18PXB1NQN6E	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.255+00	2025-08-18 18:01:28.247+00	\N	10	\N	\N
price_01K27T4TGTY5CKV980A5GM6V3Z	\N	pset_01K27T4TGT2CRRZ18PXB1NQN6E	eur	{"value": "10", "precision": 20}	1	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.255+00	2025-08-18 18:01:28.247+00	\N	10	\N	\N
price_01K27T4TGT4DK0X9H1D4VVRPGJ	\N	pset_01K27T4TGTDQEJESPY8BSR349W	usd	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.273+00	2025-08-18 18:01:28.247+00	\N	10	\N	\N
price_01K27T4TGT59736Q7KQ1Q6MKG8	\N	pset_01K27T4TGTDQEJESPY8BSR349W	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.273+00	2025-08-18 18:01:28.247+00	\N	10	\N	\N
price_01K27T4TGT8H3137JKV937832A	\N	pset_01K27T4TGTDQEJESPY8BSR349W	eur	{"value": "10", "precision": 20}	1	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.273+00	2025-08-18 18:01:28.247+00	\N	10	\N	\N
price_01K27T4TN8XPFT94BSH4CV6TSH	\N	pset_01K27T4TN8FKAJB9023EHNSAG7	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.039+00	2025-08-18 17:50:54.024+00	\N	10	\N	\N
price_01K27T4TN8YC77J6D5MNH1CN2P	\N	pset_01K27T4TN8FKAJB9023EHNSAG7	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.039+00	2025-08-18 17:50:54.024+00	\N	15	\N	\N
price_01K27T4TN8NM995YXKC02014WQ	\N	pset_01K27T4TN87Q6RNVHWZT8Z6XRP	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.055+00	2025-08-18 17:50:54.024+00	\N	10	\N	\N
price_01K27T4TN84N5Y95DPBATMQCZK	\N	pset_01K27T4TN87Q6RNVHWZT8Z6XRP	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.055+00	2025-08-18 17:50:54.024+00	\N	15	\N	\N
price_01K27T4TN8Y2A12NTWH46301MY	\N	pset_01K27T4TN950VTZEHQM17VKDQF	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.065+00	2025-08-18 17:50:54.024+00	\N	10	\N	\N
price_01K27T4TN9XHEH8YBNKV6XARXH	\N	pset_01K27T4TN950VTZEHQM17VKDQF	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.065+00	2025-08-18 17:50:54.024+00	\N	15	\N	\N
price_01K27T4TN96ZJ7XT7NBFSJNB2D	\N	pset_01K27T4TN9VFWVMES3CG4M3EMR	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.071+00	2025-08-18 17:50:54.024+00	\N	10	\N	\N
price_01K27T4TN9SGZ97JW4P7WSVFZ2	\N	pset_01K27T4TN9VFWVMES3CG4M3EMR	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:54.071+00	2025-08-18 17:50:54.024+00	\N	15	\N	\N
price_01K27T4TN55ETHB9ZNJ6S2G8H4	\N	pset_01K27T4TN5T0QKSYXPMSAV7RTJ	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.466+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN5G6XQ3DKDKDJYQKMW	\N	pset_01K27T4TN5T0QKSYXPMSAV7RTJ	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.466+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN5VYR3S6KBW6JWK3E5	\N	pset_01K27T4TN6867T7AGGF9ENDHAT	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.474+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN6HMPN1RJYQ1XSFJ8N	\N	pset_01K27T4TN6867T7AGGF9ENDHAT	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.474+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN64227HTV7V0G4W9C8	\N	pset_01K27T4TN6YXZQTDGA80RJX0KG	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.484+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN6DZ2K58Z8X6H5ZG3K	\N	pset_01K27T4TN6YXZQTDGA80RJX0KG	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.484+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN6EDY9M2DKDHE018EA	\N	pset_01K27T4TN6T2ECQR6AB86DYGNG	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.491+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN6JGQNV1M48CEVY19C	\N	pset_01K27T4TN6T2ECQR6AB86DYGNG	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.491+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K27T4TN6TP7FN4HM07SP2YQX	\N	pset_01K27T4TN69K86XCF05DY4WA9A	eur	{"value": "10", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.502+00	2025-08-18 17:50:57.44+00	\N	10	\N	\N
price_01K27T4TN640EK31RGG10GZJQQ	\N	pset_01K27T4TN69K86XCF05DY4WA9A	usd	{"value": "15", "precision": 20}	0	2025-08-09 16:20:42.794+00	2025-08-18 17:50:57.502+00	2025-08-18 17:50:57.44+00	\N	15	\N	\N
price_01K38QHH1XC6Z47SNR7H37MDXR	\N	pset_01K38QHH1X19BZVAAAN2YAT2XN	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH1XVF3S6DMVA4RAP35R	\N	pset_01K38QHH1X19BZVAAAN2YAT2XN	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH1X0EZYHG1647M57KB7	\N	pset_01K38QHH1X7DDBK9HWYC0PSQFH	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH1X3VBSH10D35Z3ZGTT	\N	pset_01K38QHH1X7DDBK9HWYC0PSQFH	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH1YCY37QTXFXT2FSXCG	\N	pset_01K38QHH1YQHRT1P0H0QXG92GG	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH1YND1084Y9W94NYPYJ	\N	pset_01K38QHH1YQHRT1P0H0QXG92GG	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH1YBZNXN3Y2G11SYZNM	\N	pset_01K38QHH1ZC9FQCMEVAT7EFRGZ	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH1Y0AWG3E76AAWK3NR6	\N	pset_01K38QHH1ZC9FQCMEVAT7EFRGZ	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH1Z5JYS8XDM3MD7P6WA	\N	pset_01K38QHH1ZYV680A62WKRANRZK	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH1Z5JN32ZXRP398ATNA	\N	pset_01K38QHH1ZYV680A62WKRANRZK	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH1ZRAPDCAHCEF26RSVD	\N	pset_01K38QHH20PYP3RATDXDYC20KE	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH1ZYC8J2Z0ZJZECPJB7	\N	pset_01K38QHH20PYP3RATDXDYC20KE	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH20S0E18Q5BXCE3Y05G	\N	pset_01K38QHH202WGHNE42XVCEXWHH	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH20H5MXQRQRX2R64K4R	\N	pset_01K38QHH202WGHNE42XVCEXWHH	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH20CEQN1FB3X9DFQSCW	\N	pset_01K38QHH20XQVNJSA4128Z3A3D	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH202DEP8X9ZSDENFQV2	\N	pset_01K38QHH20XQVNJSA4128Z3A3D	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH202792QR2G68RN7QZG	\N	pset_01K38QHH20KMM3HAQX46FFDCY2	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH20F29XJNVXVF9EH938	\N	pset_01K38QHH20KMM3HAQX46FFDCY2	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH21HBJXYR7K65XPT9DZ	\N	pset_01K38QHH21V7330KX0YW32QXBD	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHGMT12WPZ3Y2JA3FGBBW	\N	pset_01K38QHGMVSTEV8NMMTH4MJ9MX	usd	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.565+00	2025-08-22 12:10:55.556+00	\N	10	\N	\N
price_01K38QHH217BVDW8C2F4HJBX5F	\N	pset_01K38QHH21V7330KX0YW32QXBD	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH21ZBJH34XT1ZWX750A	\N	pset_01K38QHH21B3Y4YV20NRGDPSCM	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH21XYED26P4FXC94THF	\N	pset_01K38QHH21B3Y4YV20NRGDPSCM	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH21WWTRGD74M7ADJ7BP	\N	pset_01K38QHH21CH7VX6F0MTV605R0	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH2195Q4GWTE1A2NFVAV	\N	pset_01K38QHH21CH7VX6F0MTV605R0	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH213NHMWANCG299YQE2	\N	pset_01K38QHH21CG7044V1C2DWJN2C	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH218NNB2KGB8AMXDG5J	\N	pset_01K38QHH21CG7044V1C2DWJN2C	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH217EXJ4F4383MQWG7F	\N	pset_01K38QHH220TTN06TJH7P8XHWQ	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH224G05FFH2BABXQKWW	\N	pset_01K38QHH220TTN06TJH7P8XHWQ	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH226707Q0NDEEY1CPRG	\N	pset_01K38QHH22DRGYRY6QMEZ0DVNC	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH22B62J1WQ23V8Z9FTE	\N	pset_01K38QHH22DRGYRY6QMEZ0DVNC	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH22V0C2VP90JZ9BJB44	\N	pset_01K38QHH22THZT6J8AM3R7H7Z0	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH22M8MZST2GANBAK2AH	\N	pset_01K38QHH22THZT6J8AM3R7H7Z0	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH223195738X3ZYBRBMX	\N	pset_01K38QHH22TDFFEPSS9FDZG7XM	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH22R61VZDCVHWCD6K3N	\N	pset_01K38QHH22TDFFEPSS9FDZG7XM	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH220R1VSVDWXP6XZ2AN	\N	pset_01K38QHH22R842CE4C1ABS31J4	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH22PRZWYQ369WSPBQG4	\N	pset_01K38QHH22R842CE4C1ABS31J4	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH22KMFTGQK93Z35RDM7	\N	pset_01K38QHH23Y6GE6KAS3K169ZAR	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH23VG8WM6CPQVCGGQND	\N	pset_01K38QHH23Y6GE6KAS3K169ZAR	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHH23AP02HYRWWCKX0SVJ	\N	pset_01K38QHH236WW1FK6X61D6SSHD	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	10	\N	\N
price_01K38QHH23666JJW81SMW8CG4H	\N	pset_01K38QHH236WW1FK6X61D6SSHD	usd	{"value": "15", "precision": 20}	0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N	\N	15	\N	\N
price_01K38QHGMT0JHDW83M2JKVWGTY	\N	pset_01K38QHGMVSTEV8NMMTH4MJ9MX	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.565+00	2025-08-22 12:10:55.556+00	\N	10	\N	\N
price_01K38QHGMVNCRCHDC6Y43663MK	\N	pset_01K38QHGMVSTEV8NMMTH4MJ9MX	eur	{"value": "10", "precision": 20}	1	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.565+00	2025-08-22 12:10:55.556+00	\N	10	\N	\N
price_01K38QHGMVWF7ZMR7GG4JJ0FKX	\N	pset_01K38QHGMVS7GZ3JXN14HQJRMD	usd	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.581+00	2025-08-22 12:10:55.556+00	\N	10	\N	\N
price_01K38QHGMVKE3WB300A8E0DDHH	\N	pset_01K38QHGMVS7GZ3JXN14HQJRMD	eur	{"value": "10", "precision": 20}	0	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.581+00	2025-08-22 12:10:55.556+00	\N	10	\N	\N
price_01K38QHGMVZEHS65AHGMCHYF21	\N	pset_01K38QHGMVS7GZ3JXN14HQJRMD	eur	{"value": "10", "precision": 20}	1	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.581+00	2025-08-22 12:10:55.556+00	\N	10	\N	\N
price_01K3BYYSH5PYMQXFJFMJKSTJDY	\N	pset_01K3BYYSH6CFS5365ZP55S4QDY	inr	{"value": "2700", "precision": 20}	0	2025-08-23 17:17:27.464+00	2025-08-23 19:01:11.56+00	2025-08-23 19:01:11.553+00	\N	2700	\N	\N
price_01K3BYYSH6K5HP1Y1CW0BMADR9	\N	pset_01K3BYYSH6CFS5365ZP55S4QDY	inr	{"value": "2700", "precision": 20}	1	2025-08-23 17:17:27.464+00	2025-08-23 19:01:11.56+00	2025-08-23 19:01:11.553+00	\N	2700	\N	\N
price_01K3C0EX3A0J1NSEDB37QET9GQ	\N	pset_01K3C0EX3A4EWVP50XFZ92D2VJ	inr	{"value": "1800", "precision": 20}	0	2025-08-23 17:43:43.979+00	2025-08-23 19:01:15.254+00	2025-08-23 19:01:15.251+00	\N	1800	\N	\N
price_01K3C0EX3A4ER6SHWVJ8SC7THN	\N	pset_01K3C0EX3A4EWVP50XFZ92D2VJ	inr	{"value": "1800", "precision": 20}	1	2025-08-23 17:43:43.98+00	2025-08-23 19:01:15.254+00	2025-08-23 19:01:15.251+00	\N	1800	\N	\N
price_01K3C6E18YQ7RJTHBXNJ3KR3J8	\N	pset_01K3C6E18Z53C9MRXFBNHCH7AP	inr	{"value": "900", "precision": 20}	0	2025-08-23 19:28:06.944+00	2025-08-23 19:28:06.944+00	\N	\N	900	\N	\N
price_01K3C6E18Z33PX9JQDN1QWHRTF	\N	pset_01K3C6E18Z53C9MRXFBNHCH7AP	inr	{"value": "900", "precision": 20}	1	2025-08-23 19:28:06.944+00	2025-08-23 19:28:06.944+00	\N	\N	900	\N	\N
price_01K3C6FN8D6EJE9TA2AFJZQA72	\N	pset_01K3C6FN8E1M56K054GRP53Z10	inr	{"value": "1800", "precision": 20}	0	2025-08-23 19:29:00.174+00	2025-08-23 19:29:00.174+00	\N	\N	1800	\N	\N
price_01K3C6FN8EA4WJDVD3DJGNQHD8	\N	pset_01K3C6FN8E1M56K054GRP53Z10	inr	{"value": "1800", "precision": 20}	1	2025-08-23 19:29:00.175+00	2025-08-23 19:29:00.175+00	\N	\N	1800	\N	\N
price_01K3C6HRDP4QC2RTBZDPVC973A	\N	pset_01K3C6HRDPM9TB53M9QG5FZM3P	inr	{"value": "2700", "precision": 20}	0	2025-08-23 19:30:08.951+00	2025-08-23 19:30:08.951+00	\N	\N	2700	\N	\N
price_01K3C6HRDPMGZ6ZAJXPDVK4XBP	\N	pset_01K3C6HRDPM9TB53M9QG5FZM3P	inr	{"value": "2700", "precision": 20}	1	2025-08-23 19:30:08.952+00	2025-08-23 19:30:08.952+00	\N	\N	2700	\N	\N
price_01K3C6MEQZTKVEHVCS240WS5K4	\N	pset_01K3C6MER2BR966QSQG71MDK6T	inr	{"value": "900", "precision": 20}	0	2025-08-23 19:31:37.348+00	2025-08-29 19:40:15.738+00	2025-08-29 19:40:15.717+00	\N	900	\N	\N
price_01K3C6MER02JS7G0GEWJZ51YRZ	\N	pset_01K3C6MER2BR966QSQG71MDK6T	inr	{"value": "900", "precision": 20}	1	2025-08-23 19:31:37.348+00	2025-08-29 19:40:15.738+00	2025-08-29 19:40:15.717+00	\N	900	\N	\N
price_01K3C6NK07ANHNVT6V8S3FAECG	\N	pset_01K3C6NK0828Z92ZTCPZF6XZTB	inr	{"value": "1800", "precision": 20}	0	2025-08-23 19:32:14.472+00	2025-08-29 19:40:20.586+00	2025-08-29 19:40:20.58+00	\N	1800	\N	\N
price_01K3C6NK08N39ZVMHZ3FSAEW1Z	\N	pset_01K3C6NK0828Z92ZTCPZF6XZTB	inr	{"value": "1800", "precision": 20}	1	2025-08-23 19:32:14.472+00	2025-08-29 19:40:20.586+00	2025-08-29 19:40:20.58+00	\N	1800	\N	\N
price_01K3C6PPJF0H1MJHPDN3A70Z88	\N	pset_01K3C6PPJGAW3Q4C79S9A8M3WP	inr	{"value": "2700", "precision": 20}	0	2025-08-23 19:32:50.896+00	2025-08-29 19:40:24.492+00	2025-08-29 19:40:24.488+00	\N	2700	\N	\N
price_01K3C6PPJFFCC4H7YCNBREC24C	\N	pset_01K3C6PPJGAW3Q4C79S9A8M3WP	inr	{"value": "2700", "precision": 20}	1	2025-08-23 19:32:50.896+00	2025-08-29 19:40:24.492+00	2025-08-29 19:40:24.488+00	\N	2700	\N	\N
price_01K3C6QVGQQV4N7WQ7QZMEBYEQ	\N	pset_01K3C6QVGS3530JVG3R8NRDYE9	inr	{"value": "900", "precision": 20}	0	2025-08-23 19:33:28.729+00	2025-08-29 19:40:27.996+00	2025-08-29 19:40:27.977+00	\N	900	\N	\N
price_01K3C6QVGR6253A79K1AB5AYZW	\N	pset_01K3C6QVGS3530JVG3R8NRDYE9	inr	{"value": "900", "precision": 20}	1	2025-08-23 19:33:28.729+00	2025-08-29 19:40:27.996+00	2025-08-29 19:40:27.977+00	\N	900	\N	\N
price_01K3C6S8FYV324174KX36TEY5D	\N	pset_01K3C6S8FYNB84A5GXWQ7S3PP9	inr	{"value": "1800", "precision": 20}	0	2025-08-23 19:34:14.783+00	2025-08-29 19:40:31.501+00	2025-08-29 19:40:31.496+00	\N	1800	\N	\N
price_01K3C6S8FY7VF9R03WNMBW8ZDS	\N	pset_01K3C6S8FYNB84A5GXWQ7S3PP9	inr	{"value": "1800", "precision": 20}	1	2025-08-23 19:34:14.783+00	2025-08-29 19:40:31.501+00	2025-08-29 19:40:31.496+00	\N	1800	\N	\N
price_01K3C6YYBDMAAMKKJGG0TKRA5E	\N	pset_01K3C6YYBEV42QCQH0CM7T0QZA	inr	{"value": "2700", "precision": 20}	0	2025-08-23 19:37:21.006+00	2025-08-29 19:40:35.956+00	2025-08-29 19:40:35.951+00	\N	2700	\N	\N
price_01K3C6YYBDEJE0ZZ3AGAS6VT20	\N	pset_01K3C6YYBEV42QCQH0CM7T0QZA	inr	{"value": "2700", "precision": 20}	1	2025-08-23 19:37:21.006+00	2025-08-29 19:40:35.956+00	2025-08-29 19:40:35.951+00	\N	2700	\N	\N
price_01K3VPE6QFYJ7H12DEJ838MBZH	\N	pset_01K3VPE6QGANE2CRC9J008MFFV	inr	{"value": "900", "precision": 20}	0	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	\N	900	\N	\N
price_01K3VPE6QGCV9WVY81CQPEJ55Q	\N	pset_01K3VPE6QGANE2CRC9J008MFFV	inr	{"value": "900", "precision": 20}	1	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	\N	900	\N	\N
price_01K3VPE6QG12P0T142HYH4YKK5	\N	pset_01K3VPE6QG5SGDZ92A2T8SY568	inr	{"value": "1800", "precision": 20}	0	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	\N	1800	\N	\N
price_01K3VPE6QGT7WWTQPKH01Q294Y	\N	pset_01K3VPE6QG5SGDZ92A2T8SY568	inr	{"value": "1800", "precision": 20}	1	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	\N	1800	\N	\N
price_01K3VPE6QH80V4C0DM4PC20X5W	\N	pset_01K3VPE6QH1N6PA2FJPC5BQMQD	inr	{"value": "2700", "precision": 20}	0	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	\N	2700	\N	\N
price_01K3VPE6QHZ143RNVW6GYZADPV	\N	pset_01K3VPE6QH1N6PA2FJPC5BQMQD	inr	{"value": "2700", "precision": 20}	1	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	\N	2700	\N	\N
price_01K3X8E8VQWJDBXY29HKCB9HCW	\N	pset_01K3X8E8VR8P1QTZDW408MN3S2	inr	{"value": "1500", "precision": 20}	0	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	\N	1500	\N	\N
price_01K3X8E8VRJMKYS9HJAHWJGVM5	\N	pset_01K3X8E8VR8P1QTZDW408MN3S2	inr	{"value": "1500", "precision": 20}	1	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	\N	1500	\N	\N
price_01K3X8E8VRTEDC1V24Y9P4NZQZ	\N	pset_01K3X8E8VRFG2G36CSWQ9M3Q3Z	inr	{"value": "3000", "precision": 20}	0	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	\N	3000	\N	\N
price_01K3X8E8VRPZ9GEB5JRAF5XRR1	\N	pset_01K3X8E8VRFG2G36CSWQ9M3Q3Z	inr	{"value": "3000", "precision": 20}	1	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	\N	3000	\N	\N
price_01K3X8E8VRX7EV3FRWR7K4TG5P	\N	pset_01K3X8E8VS75WSMCETHA77RW2Y	inr	{"value": "4500", "precision": 20}	0	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	\N	4500	\N	\N
price_01K3X8E8VSXNRXJXQWCG8ZRJV5	\N	pset_01K3X8E8VS75WSMCETHA77RW2Y	inr	{"value": "4500", "precision": 20}	1	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	\N	4500	\N	\N
\.


--
-- Data for Name: price_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_list (id, status, starts_at, ends_at, rules_count, title, description, type, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: price_list_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_list_rule (id, price_list_id, created_at, updated_at, deleted_at, value, attribute) FROM stdin;
\.


--
-- Data for Name: price_preference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_preference (id, attribute, value, is_tax_inclusive, created_at, updated_at, deleted_at) FROM stdin;
prpref_01K27T4TDQS0JGKD7CW2E2BJ18	currency_code	eur	f	2025-08-09 16:20:42.552+00	2025-08-09 16:20:42.552+00	\N
prpref_01K27T4TF1TE96AVNZJNC330N2	region_id	reg_01K27T4TEJAKE14P075FWZVXKA	f	2025-08-09 16:20:42.593+00	2025-08-09 16:20:42.593+00	\N
prpref_01K2VK6A7FRGZGBQ4SSE9XD3SA	currency_code	inr	f	2025-08-17 08:44:00.111+00	2025-08-17 08:44:00.111+00	\N
prpref_01K27T4TECH34XF4AZVPW8YE0T	currency_code	usd	t	2025-08-09 16:20:42.572+00	2025-08-17 08:44:29.362+00	\N
prpref_01K2Z5PA7QZSRY5G1J5HXJZERW	region_id	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	f	2025-08-18 18:05:02.071+00	2025-08-18 18:05:02.071+00	\N
prpref_01K38QHGHHXP4JENFTAZP73XGD	region_id	reg_01K38QHGH1DNXQV6P26FYQKAF0	f	2025-08-22 11:10:08.945+00	2025-08-22 11:10:08.945+00	\N
\.


--
-- Data for Name: price_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_rule (id, value, priority, price_id, created_at, updated_at, deleted_at, attribute, operator) FROM stdin;
prule_01K27T4TGTN120BC8AFY389CRS	reg_01K27T4TEJAKE14P075FWZVXKA	0	price_01K27T4TGTY5CKV980A5GM6V3Z	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.265+00	2025-08-18 18:01:28.247+00	region_id	eq
prule_01K27T4TGTC4HVNSB1HH8Z0RBD	reg_01K27T4TEJAKE14P075FWZVXKA	0	price_01K27T4TGT8H3137JKV937832A	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.278+00	2025-08-18 18:01:28.247+00	region_id	eq
prule_01K38QHGMTPHZ0QWAFE113ADSZ	reg_01K38QHGH1DNXQV6P26FYQKAF0	0	price_01K38QHGMVNCRCHDC6Y43663MK	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.575+00	2025-08-22 12:10:55.556+00	region_id	eq
prule_01K38QHGMVF615T5DK5VBTNE1N	reg_01K38QHGH1DNXQV6P26FYQKAF0	0	price_01K38QHGMVZEHS65AHGMCHYF21	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.587+00	2025-08-22 12:10:55.556+00	region_id	eq
prule_01K3BYYSH6E6WGGDHS3FDZDF1D	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3BYYSH6K5HP1Y1CW0BMADR9	2025-08-23 17:17:27.464+00	2025-08-23 19:01:11.567+00	2025-08-23 19:01:11.553+00	region_id	eq
prule_01K3C0EX3AYAGNGD2225W1WE8M	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C0EX3A4ER6SHWVJ8SC7THN	2025-08-23 17:43:43.98+00	2025-08-23 19:01:15.257+00	2025-08-23 19:01:15.251+00	region_id	eq
prule_01K3C6E18Z0D4WW3ENE6CB5462	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6E18Z33PX9JQDN1QWHRTF	2025-08-23 19:28:06.944+00	2025-08-23 19:28:06.944+00	\N	region_id	eq
prule_01K3C6FN8DPTEADN2ZCXSQVFMH	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6FN8EA4WJDVD3DJGNQHD8	2025-08-23 19:29:00.175+00	2025-08-23 19:29:00.175+00	\N	region_id	eq
prule_01K3C6HRDPD82PVQXE532PDP3H	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6HRDPMGZ6ZAJXPDVK4XBP	2025-08-23 19:30:08.952+00	2025-08-23 19:30:08.952+00	\N	region_id	eq
prule_01K3C6MEQZKF8FX37AYJVX0TB1	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6MER02JS7G0GEWJZ51YRZ	2025-08-23 19:31:37.348+00	2025-08-29 19:40:15.747+00	2025-08-29 19:40:15.717+00	region_id	eq
prule_01K3C6NK08GKAN7WS5F7WCRJGZ	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6NK08N39ZVMHZ3FSAEW1Z	2025-08-23 19:32:14.472+00	2025-08-29 19:40:20.596+00	2025-08-29 19:40:20.58+00	region_id	eq
prule_01K3C6PPJF765WMYZ5YFGFC2W8	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6PPJFFCC4H7YCNBREC24C	2025-08-23 19:32:50.896+00	2025-08-29 19:40:24.496+00	2025-08-29 19:40:24.488+00	region_id	eq
prule_01K3C6QVGRR020XAPCMYK0CXWH	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6QVGR6253A79K1AB5AYZW	2025-08-23 19:33:28.729+00	2025-08-29 19:40:28.004+00	2025-08-29 19:40:27.977+00	region_id	eq
prule_01K3C6S8FY172V1HH6QJZ1BFP6	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6S8FY7VF9R03WNMBW8ZDS	2025-08-23 19:34:14.783+00	2025-08-29 19:40:31.509+00	2025-08-29 19:40:31.496+00	region_id	eq
prule_01K3C6YYBD5XER4FP9K90PEP07	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3C6YYBDEJE0ZZ3AGAS6VT20	2025-08-23 19:37:21.006+00	2025-08-29 19:40:35.96+00	2025-08-29 19:40:35.951+00	region_id	eq
prule_01K3VPE6QFG1QJG6VZ629TXP43	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3VPE6QGCV9WVY81CQPEJ55Q	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	region_id	eq
prule_01K3VPE6QGDQ71Q3AB1RD10YGK	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3VPE6QGT7WWTQPKH01Q294Y	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	region_id	eq
prule_01K3VPE6QH18CH700CHT90E25Z	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3VPE6QHZ143RNVW6GYZADPV	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N	region_id	eq
prule_01K3X8E8VQ2J93F1TXVHX8B8T5	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3X8E8VRJMKYS9HJAHWJGVM5	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	region_id	eq
prule_01K3X8E8VR2M9RPV7S953VAT7V	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3X8E8VRPZ9GEB5JRAF5XRR1	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	region_id	eq
prule_01K3X8E8VSG3XHT57CDY2QXZGX	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	0	price_01K3X8E8VSXNRXJXQWCG8ZRJV5	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N	region_id	eq
\.


--
-- Data for Name: price_set; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_set (id, created_at, updated_at, deleted_at) FROM stdin;
pset_01K27T4TN8FKAJB9023EHNSAG7	2025-08-09 16:20:42.793+00	2025-08-18 17:50:54.025+00	2025-08-18 17:50:54.024+00
pset_01K27T4TN87Q6RNVHWZT8Z6XRP	2025-08-09 16:20:42.793+00	2025-08-18 17:50:54.052+00	2025-08-18 17:50:54.024+00
pset_01K27T4TN950VTZEHQM17VKDQF	2025-08-09 16:20:42.793+00	2025-08-18 17:50:54.059+00	2025-08-18 17:50:54.024+00
pset_01K27T4TN9VFWVMES3CG4M3EMR	2025-08-09 16:20:42.793+00	2025-08-18 17:50:54.068+00	2025-08-18 17:50:54.024+00
pset_01K27T4TN5N7TCS6PHX3RPDDD9	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.44+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN5T5WJYG5WYWV3ZHBE	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.451+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN57XJHK52JSSW1DDN0	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.458+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN5T0QKSYXPMSAV7RTJ	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.462+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN6867T7AGGF9ENDHAT	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.469+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN6YXZQTDGA80RJX0KG	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.48+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN6T2ECQR6AB86DYGNG	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.487+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN69K86XCF05DY4WA9A	2025-08-09 16:20:42.793+00	2025-08-18 17:50:57.499+00	2025-08-18 17:50:57.44+00
pset_01K27T4TN7FG4YXMWYEK2EYAVT	2025-08-09 16:20:42.793+00	2025-08-18 17:51:00.893+00	2025-08-18 17:51:00.893+00
pset_01K27T4TN8EMDCA0S7AP4C5JTT	2025-08-09 16:20:42.793+00	2025-08-18 17:51:00.906+00	2025-08-18 17:51:00.893+00
pset_01K27T4TN8F0H5WSJKQQ0RSMW2	2025-08-09 16:20:42.793+00	2025-08-18 17:51:00.91+00	2025-08-18 17:51:00.893+00
pset_01K27T4TN8WAKYNMGWHHGAJ9CV	2025-08-09 16:20:42.793+00	2025-08-18 17:51:00.917+00	2025-08-18 17:51:00.893+00
pset_01K27T4TN7M50BGJ71Z92ZSXAN	2025-08-09 16:20:42.793+00	2025-08-18 17:51:05.033+00	2025-08-18 17:51:05.033+00
pset_01K27T4TN7VT24P3E4FPDHDTE0	2025-08-09 16:20:42.793+00	2025-08-18 17:51:05.041+00	2025-08-18 17:51:05.033+00
pset_01K27T4TN7HPE7K6GQRVC0KTWR	2025-08-09 16:20:42.793+00	2025-08-18 17:51:05.047+00	2025-08-18 17:51:05.033+00
pset_01K27T4TN7R913W8WRJVW59NQ9	2025-08-09 16:20:42.793+00	2025-08-18 17:51:05.051+00	2025-08-18 17:51:05.033+00
pset_01K27T4TGT2CRRZ18PXB1NQN6E	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.248+00	2025-08-18 18:01:28.247+00
pset_01K27T4TGTDQEJESPY8BSR349W	2025-08-09 16:20:42.651+00	2025-08-18 18:01:28.265+00	2025-08-18 18:01:28.247+00
pset_01K2Z994K1D6WVDB2QJ480RZJE	2025-08-18 19:07:44.61+00	2025-08-18 19:07:44.61+00	\N
pset_01K38QHH1X19BZVAAAN2YAT2XN	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH1X7DDBK9HWYC0PSQFH	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH1YQHRT1P0H0QXG92GG	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH1ZC9FQCMEVAT7EFRGZ	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH1ZYV680A62WKRANRZK	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH20PYP3RATDXDYC20KE	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH202WGHNE42XVCEXWHH	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH20XQVNJSA4128Z3A3D	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH20KMM3HAQX46FFDCY2	2025-08-22 11:10:09.475+00	2025-08-22 11:10:09.475+00	\N
pset_01K38QHH21V7330KX0YW32QXBD	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH21B3Y4YV20NRGDPSCM	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH21CH7VX6F0MTV605R0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH21CG7044V1C2DWJN2C	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH220TTN06TJH7P8XHWQ	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH22DRGYRY6QMEZ0DVNC	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH22THZT6J8AM3R7H7Z0	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH22TDFFEPSS9FDZG7XM	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH22R842CE4C1ABS31J4	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH23Y6GE6KAS3K169ZAR	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHH236WW1FK6X61D6SSHD	2025-08-22 11:10:09.476+00	2025-08-22 11:10:09.476+00	\N
pset_01K38QHGMVSTEV8NMMTH4MJ9MX	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.556+00	2025-08-22 12:10:55.556+00
pset_01K38QHGMVS7GZ3JXN14HQJRMD	2025-08-22 11:10:09.052+00	2025-08-22 12:10:55.575+00	2025-08-22 12:10:55.556+00
pset_01K3BYYSH6CFS5365ZP55S4QDY	2025-08-23 17:17:27.464+00	2025-08-23 19:01:11.553+00	2025-08-23 19:01:11.553+00
pset_01K3C0EX3A4EWVP50XFZ92D2VJ	2025-08-23 17:43:43.979+00	2025-08-23 19:01:15.251+00	2025-08-23 19:01:15.251+00
pset_01K3C6E18Z53C9MRXFBNHCH7AP	2025-08-23 19:28:06.944+00	2025-08-23 19:28:06.944+00	\N
pset_01K3C6FN8E1M56K054GRP53Z10	2025-08-23 19:29:00.174+00	2025-08-23 19:29:00.174+00	\N
pset_01K3C6HRDPM9TB53M9QG5FZM3P	2025-08-23 19:30:08.951+00	2025-08-23 19:30:08.951+00	\N
pset_01K3C6MER2BR966QSQG71MDK6T	2025-08-23 19:31:37.347+00	2025-08-29 19:40:15.718+00	2025-08-29 19:40:15.717+00
pset_01K3C6NK0828Z92ZTCPZF6XZTB	2025-08-23 19:32:14.472+00	2025-08-29 19:40:20.581+00	2025-08-29 19:40:20.58+00
pset_01K3C6PPJGAW3Q4C79S9A8M3WP	2025-08-23 19:32:50.896+00	2025-08-29 19:40:24.488+00	2025-08-29 19:40:24.488+00
pset_01K3C6QVGS3530JVG3R8NRDYE9	2025-08-23 19:33:28.729+00	2025-08-29 19:40:27.978+00	2025-08-29 19:40:27.977+00
pset_01K3C6S8FYNB84A5GXWQ7S3PP9	2025-08-23 19:34:14.783+00	2025-08-29 19:40:31.496+00	2025-08-29 19:40:31.496+00
pset_01K3C6YYBEV42QCQH0CM7T0QZA	2025-08-23 19:37:21.006+00	2025-08-29 19:40:35.951+00	2025-08-29 19:40:35.951+00
pset_01K3VPE6QGANE2CRC9J008MFFV	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N
pset_01K3VPE6QG5SGDZ92A2T8SY568	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N
pset_01K3VPE6QH1N6PA2FJPC5BQMQD	2025-08-29 19:56:26.225+00	2025-08-29 19:56:26.225+00	\N
pset_01K3X8E8VR8P1QTZDW408MN3S2	2025-08-30 10:30:17.209+00	2025-08-30 10:30:17.21+00	\N
pset_01K3X8E8VRFG2G36CSWQ9M3Q3Z	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N
pset_01K3X8E8VS75WSMCETHA77RW2Y	2025-08-30 10:30:17.21+00	2025-08-30 10:30:17.21+00	\N
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (id, title, handle, subtitle, description, is_giftcard, status, thumbnail, weight, length, height, width, origin_country, hs_code, mid_code, material, collection_id, type_id, discountable, external_id, created_at, updated_at, deleted_at, metadata) FROM stdin;
prod_01K3VPE6KPYPFJ0893VJAV152B	Premium Cordyceps Militaris Ultra-Fine Powder - Rapid Energy & ATP Boost	premium-cordyceps-militaris-ultra-fine-powder-rapid-energy-and-atp-boost	Cordyceps-militaris-powder	Unlock Natural Energy Excellence with Premium Cordyceps Militaris Ultra-Fine Powder\n\nExperience the pinnacle of functional mushroom supplementation with our Premium Cordyceps Militaris Ultra-Fine Powder—meticulously crafted to deliver rapid energy enhancement and ATP cellular support for peak performance and vitality.\n\nWhat Makes Our Cordyceps Special:\n🔬 Science-Backed Energy Support\nOur premium Cordyceps militaris contains high concentrations of cordycepin (3'-deoxyadenosine) and adenosine—bioactive nucleosides that directly support ATP production at the cellular level. These compounds enhance your body's natural energy-generating pathways, providing sustained vitality without crashes.\n\n⚡ Ultra-Fine Processing for Maximum Absorption\nUnlike standard mushroom powders, our ultra-fine milling process breaks down cell walls to create microscopic particles that significantly enhance bioavailability. This advanced processing ensures faster absorption and more efficient utilization of active compounds by your body.\n\n🏃‍♂️ Performance & Endurance Benefits\n\nEnhanced VO₂ Max: Studies show Cordyceps militaris supplementation at 4g daily improves oxygen consumption and exercise tolerance\n\nATP Production: Upregulates energy-producing pathways including AMPK, GLUT4, and phosphocreatine for sustained cellular energy\n\nOxygen Utilization: Improves blood oxygen saturation (95%) and reduces fatigue during high-intensity activities\n\nExercise Recovery: Supports faster recovery through enhanced metabolic efficiency\n\nPremium Quality & Purity:\n✅ 100% Pure Cordyceps Militaris Fruiting Bodies - No mycelium or fillers\n✅ Optimal Cordycepin Content: 325-377mg per 100g for maximum potency\n✅ Low-Temperature Dried at 60°C to preserve bioactive compounds\n✅ Third-Party Tested for purity and potency\n✅ Non-GMO & Pesticide-Free cultivation methods\n\nHow to Use:\nDaily Dosage: 1-2 teaspoons (2-4g) daily for optimal benefits\n\nEasy Integration:\n\nMorning Energy: Mix into coffee, tea, or warm water for natural awakening\n\nPre-Workout: Blend into smoothies 30 minutes before exercise for enhanced performance\n\nAnytime Boost: Stir into juices, protein shakes, or yogurt\n\nTaste Profile: Mild, earthy flavor with subtle nutty undertones—easily masked in beverages and foods\n\nStorage & Freshness:\nStore in a cool, dry place away from direct sunlight. Reseal tightly after use to maintain potency and freshness. Our powder maintains quality for 24 months when stored properly.\n\nSafety & Considerations:\nGenerally well-tolerated with daily use\n\nConsult healthcare provider if pregnant, nursing, or taking blood-thinning medications\n\nNot recommended for individuals with autoimmune conditions\n\nStart with smaller doses to assess individual tolerance\n\nThe CORDYCEPS Difference:\nHigher Bioactive Content: Our Cordyceps militaris contains significantly higher cordycepin levels compared to traditional Cordyceps sinensis, ensuring superior potency and effectiveness.\n\nSustainable Cultivation: Grown in controlled environments using organic substrates, ensuring consistent quality and eliminating contamination risks associated with wild-harvested varieties.\n\nATP-Focused Formula: Specifically processed to maximize compounds that support cellular energy production, making it ideal for athletes, professionals, and anyone seeking natural energy enhancement.\n\nExperience the transformative power of premium Cordyceps militaris—your natural pathway to sustained energy, enhanced performance, and optimal vitality.\n\nThese statements have not been evaluated by the FDA. This product is not intended to diagnose, treat, cure, or prevent any disease.	f	published	http://localhost:9000/static/1757251232174-Morel.jpeg	\N	\N	\N	\N	\N	\N	\N	\N	pcol_01K4G0MWWP5NB5M5BSGTN57AVX	\N	t	\N	2025-08-29 19:56:26.106+00	2025-09-07 13:20:32.25+00	\N	\N
prod_01K3X8E8Q6311HVXSSH879A5A1	Cordyceps Militaris Double-Extracted Tincture - Superior Absorption Formula	cordyceps-militaris-double-extracted-tincture-superior-absorption-formula	Cordyceps Militaris Tincture	Experience the Ultimate in Cordyceps Bioavailability with Our Premium Double-Extracted Tincture\n\nDiscover the pinnacle of functional mushroom supplementation with our Cordyceps Militaris Double-Extracted Tincture—meticulously crafted using advanced dual-extraction technology to deliver maximum bioavailability and rapid absorption for unparalleled energy, endurance, and vitality support.\n\nWhat Makes Our Double-Extraction Superior:\n🔬 Advanced Dual-Extraction Process\nOur proprietary double-extraction method combines both water and alcohol extraction to capture the complete spectrum of bioactive compounds. This sophisticated process extracts both water-soluble polysaccharides and alcohol-soluble triterpenes, delivering a full-spectrum formula that single extractions cannot achieve.\n\n⚡ Superior Absorption Technology\n\n10x Higher Bioavailability than powder forms\n\nRapid Sublingual Absorption - enters bloodstream within minutes\n\nEnhanced Cellular Uptake through liquid delivery system\n\nNo Digestive Breakdown Required - bypasses stomach for immediate absorption\n\n🏆 Premium Potency & Purity\n\n200mg Active Compounds per 1ml serving\n\nHigh Cordycepin Content: 13.02mg/g concentration for maximum efficacy\n\n100% Fruiting Body Extract - no mycelium fillers\n\n5-Month Extraction Process ensures optimal compound concentration\n\nScience-Backed Performance Benefits:\n🚀 Cellular Energy Enhancement\n\nATP Production Boost: Increases cellular energy by up to 32% through enhanced mitochondrial function\n\nAdenosine & Cordycepin: High concentrations of energy-supporting nucleosides\n\nSustained Energy: Clean, jitter-free vitality without crashes\n\n💪 Athletic Performance Support\n\nEndurance Enhancement: Studies show 20-24 minute increase in exercise duration\n\nOxygen Utilization: Improves VO₂ max and respiratory efficiency\n\nRecovery Acceleration: Supports faster post-exercise recovery\n\nAnti-Fatigue Effects: Reduces chronic fatigue and enhances stamina\n\n🛡️ Comprehensive Health Benefits\n\nImmune System Modulation: Beta-glucans activate NK cells, T-cells, and macrophages\n\nCardiovascular Support: Helps regulate blood pressure and cholesterol levels\n\nRespiratory Health: Traditional use for lung function and oxygen uptake\n\nAnti-Aging Properties: Rich antioxidants combat oxidative stress\n\nPremium Quality Assurance:\n✅ Dual-Extraction Method: Water + 70% grain alcohol for complete compound profile\n✅ Laboratory-Grown Fruiting Bodies: Controlled cultivation ensures purity and consistency\n✅ Third-Party Tested: Verified for potency, purity, and safety\n✅ GMP Certified: Pharmaceutical-grade manufacturing standards\n✅ Pesticide-Free & Non-GMO: Clean, sustainable cultivation practices\n\nUsage Instructions:\nOptimal Dosage: 1-2ml (20-40 drops) daily for maximum benefits\n\nAdministration Methods:\n\nSublingual (Recommended): Hold under tongue for 20-30 seconds for fastest absorption\n\nDirect Consumption: Take straight from dropper for immediate effects\n\nBeverage Addition: Mix into coffee, tea, smoothies, or water\n\nTiming for Best Results:\n\nMorning Energy: Take upon waking for all-day vitality\n\nPre-Workout: Consume 30 minutes before exercise for enhanced performance\n\nConsistent Daily Use: Take regularly for 2-4 weeks for sustained benefits\n\nTaste & Experience:\nOur tincture features a mild, earthy flavor with subtle alcohol notes (20-24% alcohol content). The natural taste blends seamlessly into beverages or can be taken directly for those who appreciate the authentic mushroom essence.\n\nStorage & Shelf Life:\nShelf Stable: Maintains potency for 3+ years when stored properly\n\nStorage: Keep in cool, dry place away from direct sunlight\n\nRefrigeration: Optional after opening to extend freshness\n\nShake Before Use: Natural settling may occur - shake well before each use\n\nSafety & Considerations:\nGenerally Well-Tolerated: Safe for daily long-term use\n\nStart Gradually: Begin with smaller doses (3-4 drops) and increase to full dose\n\nContraindications: Consult healthcare provider if taking blood-thinning medications\n\nNot Recommended: During pregnancy or for autoimmune conditions\n\nWhy Choose Double-Extraction?\nComplete Compound Profile: Single extractions miss up to 50% of beneficial compounds. Our dual method captures both water-soluble polysaccharides AND alcohol-soluble triterpenes for comprehensive benefits.\n\nEnhanced Bioavailability: Liquid extracts deliver superior absorption rates compared to powders or capsules, ensuring you receive maximum benefit from every drop.\n\nRapid Action: Experience effects within days rather than weeks thanks to our fast-absorbing liquid delivery system.\n\nProfessional Quality: Our 5-month extraction process and pharmaceutical-grade standards ensure consistent, potent results you can trust.\n\nTransform your energy, performance, and vitality with the most bioavailable Cordyceps supplement available. Experience the difference that superior extraction and absorption can make.\n\nThese statements have not been evaluated by the FDA. This product is not intended to diagnose, treat, cure, or prevent any disease.	f	published	http://localhost:9000/static/1757251271783-Cordyceps-senesis.png	\N	\N	\N	\N	\N	\N	\N	\N	pcol_01K4G0PM19P61P0EN98V0P1GN6	\N	t	\N	2025-08-30 10:30:17.07+00	2025-09-07 13:21:11.832+00	\N	\N
prod_01K3BYYS4TQETWPF96CNF4ZBZ5	Premium Cordyceps Militaris Dried Fruiting Body - Natural Energy & Vitality Support	premium-cordyceps-militaris-dried-fruiting-body-for-natural-energy-and-vitality	Militaris	Cordyceps militaris is a nutrient-dense nutraceutical mushroom renowned for its exceptional health-promoting properties and bioactive compounds. This premium superfood contains high-quality protein (23-60%), essential B-vitamins (B1, B2, B12), vitamin E and K, plus vital minerals including potassium, magnesium, iron, zinc, and selenium.\n\nKey Bioactive Nutrients:\n\nCordycepin - Enhances cellular energy production and ATP synthesis\n\nAdenosine - Supports cardiovascular health and blood flow\n\nPolysaccharides - Powerful immune system modulators\n\nErgosterol and Beta-sitosterol - Natural sterol compounds\n\nEssential amino acids including lysine and glutamic acid\n\nBenefits of Regular Consumption:\n\nEnergy & Performance: Regular intake significantly improves exercise tolerance, oxygen utilization, and endurance capacity. Studies show 10.9% improvement in maximal oxygen consumption and enhanced ATP production for sustained energy.\n\nImmune Support: Daily consumption activates natural killer cells, increases beneficial immune markers (IL-2, IFN-γ), and provides immunomodulatory effects without side effects.\n\nAntioxidant Protection: Powerful anti-inflammatory and antioxidant compounds help combat oxidative stress and support healthy aging processes.\n\nMetabolic Health: Regular use supports blood sugar regulation, cholesterol management, and cardiovascular function.\n\nDosage: Optimal benefits achieved with 3-4 grams daily with consistent long-term use showing enhanced results.\nSafe for daily consumption with no major side effects reported in clinical studies.	f	published	http://localhost:9000/static/1757251187106-Turkey%20Tail.png	\N	\N	\N	\N	\N	\N	\N	\N	pcol_01K4G0MWWP5NB5M5BSGTN57AVX	\N	t	\N	2025-08-23 17:17:27.11+00	2025-09-07 13:19:47.188+00	\N	\N
\.


--
-- Data for Name: product_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_category (id, name, description, handle, mpath, is_active, is_internal, rank, parent_category_id, created_at, updated_at, deleted_at, metadata) FROM stdin;
pcat_01K27T4THX1XR6D2CE8HYWE09V	Sweatshirts		sweatshirts	pcat_01K27T4THX1XR6D2CE8HYWE09V	t	f	1	\N	2025-08-09 16:20:42.685+00	2025-08-18 17:50:27.451+00	2025-08-18 17:50:27.45+00	\N
pcat_01K27T4THXMECH66QKEA0ANHH2	Merch		merch	pcat_01K27T4THXMECH66QKEA0ANHH2	t	f	2	\N	2025-08-09 16:20:42.685+00	2025-08-18 17:50:31.134+00	2025-08-18 17:50:31.134+00	\N
pcat_01K27T4THXP8N7Y1VX6QXHVTHB	Pants		pants	pcat_01K27T4THXP8N7Y1VX6QXHVTHB	t	f	1	\N	2025-08-09 16:20:42.685+00	2025-08-18 17:50:34.44+00	2025-08-18 17:50:34.44+00	\N
pcat_01K27T4THXY7EFP5HAW2FR3DSP	Shirts		shirts	pcat_01K27T4THXY7EFP5HAW2FR3DSP	t	f	0	\N	2025-08-09 16:20:42.685+00	2025-08-18 17:50:38.856+00	2025-08-18 17:50:38.856+00	\N
pcat_01K2Z8VQ8ARQWTDPHQFV90XWYG	Endurance and Energy		Endurance	pcat_01K2Z8VQ8ARQWTDPHQFV90XWYG	t	f	0	\N	2025-08-18 19:00:24.974+00	2025-08-22 11:11:18.388+00	2025-08-22 11:11:18.387+00	\N
pcat_01K38QHGV98STDB4AMA2T4QHXS	Shirts		shirts	pcat_01K38QHGV98STDB4AMA2T4QHXS	t	f	0	\N	2025-08-22 11:10:09.259+00	2025-08-22 11:11:27.616+00	2025-08-22 11:11:27.616+00	\N
pcat_01K38QHGVAAHZBCSDRBW65RRKA	Pants		pants	pcat_01K38QHGVAAHZBCSDRBW65RRKA	t	f	1	\N	2025-08-22 11:10:09.259+00	2025-08-22 11:11:32.028+00	2025-08-22 11:11:32.027+00	\N
pcat_01K38QHGVAJHSNJVBQ4FGZ6917	Sweatshirts		sweatshirts	pcat_01K38QHGVAJHSNJVBQ4FGZ6917	t	f	0	\N	2025-08-22 11:10:09.259+00	2025-08-22 11:11:35.459+00	2025-08-22 11:11:35.459+00	\N
pcat_01K38QHGVBDG60NWH7CA5S987W	Merch		merch	pcat_01K38QHGVBDG60NWH7CA5S987W	t	f	0	\N	2025-08-22 11:10:09.259+00	2025-08-22 11:11:39.29+00	2025-08-22 11:11:39.29+00	\N
pcat_01K4G6EN9Q5W1NGFNFTX6MTBMN	Brain Boosting		brain-booster	pcat_01K4G6EN9Q5W1NGFNFTX6MTBMN	t	f	0	\N	2025-09-06 19:01:07+00	2025-09-06 19:01:07+00	\N	\N
\.


--
-- Data for Name: product_category_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_category_product (product_id, product_category_id) FROM stdin;
prod_01K3BYYS4TQETWPF96CNF4ZBZ5	pcat_01K4G6EN9Q5W1NGFNFTX6MTBMN
prod_01K3VPE6KPYPFJ0893VJAV152B	pcat_01K4G6EN9Q5W1NGFNFTX6MTBMN
prod_01K3X8E8Q6311HVXSSH879A5A1	pcat_01K4G6EN9Q5W1NGFNFTX6MTBMN
\.


--
-- Data for Name: product_collection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_collection (id, title, handle, metadata, created_at, updated_at, deleted_at) FROM stdin;
pcol_01K4G0MWWP5NB5M5BSGTN57AVX	Brain Boosting	brain-boosting	\N	2025-09-06 17:19:39.919554+00	2025-09-06 17:19:39.919554+00	\N
pcol_01K4G0PM19P61P0EN98V0P1GN6	Heart & Gut health	heart-gut-health	\N	2025-09-06 17:20:36.391583+00	2025-09-06 17:20:36.391583+00	\N
pcol_01K4GBJXBMJPPFYJ6CVJWW6M8P	Strength & Endurance	strength-boosting	\N	2025-09-06 20:30:49.202218+00	2025-09-06 20:30:49.202218+00	\N
\.


--
-- Data for Name: product_option; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_option (id, title, product_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
opt_01K3BYYS5MQNF84EDX0A223ZRV	60 Grams Pack	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:26:42.338+00	2025-08-23 17:26:42.335+00
opt_01K3BYYS5KXHADMH9WSV60TPVZ	30 Grams Pack	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:26:47.561+00	2025-08-23 17:26:47.56+00
opt_01K3BYYS5MJDSBNMN4F9J367KS	90 Grams Pack	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:26:58.241+00	2025-08-23 17:26:58.239+00
opt_01K3BYYS5NG4340KRXHB5Y283X	90 Grams Pack of 2	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:27:01.063+00	2025-08-23 17:27:01.063+00
opt_01K3BYYS5N4M2XNGSGRNFWD86M	90 Grams Pack of 3	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:27:04.288+00	2025-08-23 17:27:04.287+00
opt_01K3C0CT6C5E8Y631AWYQW3Q0X	60 Grams Pack	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:42:35.469+00	2025-08-23 17:55:39.727+00	2025-08-23 17:55:39.725+00
opt_01K3C0HKPJB3HK94DEJ2MYSDXN	90 Grams Pack	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:45:12.659+00	2025-08-23 17:55:43.167+00	2025-08-23 17:55:43.167+00
opt_01K3C092BX424T0JSPKZ1RYN7F	Per Gram Price	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:40:32.766+00	2025-08-23 19:01:04.103+00	2025-08-23 19:01:04.097+00
opt_01K3C1BJ3JAGWNBDS6FZTB66HA	per gram price	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 17:59:22.999+00	2025-08-23 19:01:07.188+00	2025-08-23 19:01:07.188+00
opt_01K3C4X7PV4R37GGA6J8NGBNQX	Order Size	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	\N	2025-08-23 19:01:27.9+00	2025-08-23 19:01:27.9+00	\N
opt_01K3VPE6KSQ1P9VB67AVRAQ4XG	Order Size	prod_01K3VPE6KPYPFJ0893VJAV152B	\N	2025-08-29 19:56:26.107+00	2025-08-29 19:56:26.107+00	\N
opt_01K3X8E8QBTTG8GMPGYMPCJR61	Order Size	prod_01K3X8E8Q6311HVXSSH879A5A1	\N	2025-08-30 10:30:17.071+00	2025-08-30 10:30:17.071+00	\N
\.


--
-- Data for Name: product_option_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_option_value (id, value, option_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
optval_01K3BYYS5MR5X6TDNWMBHRRZ3V	60 Grams Pack	opt_01K3BYYS5MQNF84EDX0A223ZRV	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:26:42.353+00	2025-08-23 17:26:42.335+00
optval_01K3BYYS5DN1JJA1Q6VH7RCD8H	30 Grams Pack	opt_01K3BYYS5KXHADMH9WSV60TPVZ	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:26:47.565+00	2025-08-23 17:26:47.56+00
optval_01K3BYYS5MA6M081NGJGW87FSZ	90 Grams Pack	opt_01K3BYYS5MJDSBNMN4F9J367KS	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:26:58.25+00	2025-08-23 17:26:58.239+00
optval_01K3BYYS5M73BB4FHKW7N6GKVD	90 Grams Pack of 2	opt_01K3BYYS5NG4340KRXHB5Y283X	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:27:01.067+00	2025-08-23 17:27:01.063+00
optval_01K3BYYS5NCMZT6T5NQMD6NJ9T	90 Grams Pack of 3	opt_01K3BYYS5N4M2XNGSGRNFWD86M	\N	2025-08-23 17:17:27.119+00	2025-08-23 17:27:04.293+00	2025-08-23 17:27:04.287+00
optval_01K3C0CT6AE2JHSNZ3W1DTFBJH	1800	opt_01K3C0CT6C5E8Y631AWYQW3Q0X	\N	2025-08-23 17:42:35.469+00	2025-08-23 17:55:39.742+00	2025-08-23 17:55:39.725+00
optval_01K3C0HKPH77WVWNQH0WKCP8SJ	2700	opt_01K3C0HKPJB3HK94DEJ2MYSDXN	\N	2025-08-23 17:45:12.66+00	2025-08-23 17:55:43.174+00	2025-08-23 17:55:43.167+00
optval_01K3C15SM4P3Q81EMA2E4TXTQ2	30	opt_01K3C092BX424T0JSPKZ1RYN7F	\N	2025-08-23 17:56:14.071505+00	2025-08-23 19:01:04.128+00	2025-08-23 19:01:04.097+00
optval_01K3C1BJ3GP1RXC48N99WW7RKM	27.78	opt_01K3C1BJ3JAGWNBDS6FZTB66HA	\N	2025-08-23 17:59:23+00	2025-08-23 19:01:07.2+00	2025-08-23 19:01:07.188+00
optval_01K3C6BK7NWZQM665RZFT6XBNM	Dried Fruiting Body	opt_01K3C4X7PV4R37GGA6J8NGBNQX	\N	2025-08-23 19:26:46.978611+00	2025-08-23 19:26:46.978611+00	\N
optval_01K3C6BK7NS8FT1A88ZQCCC1P2	Dried Fruiting Body Pack of 2	opt_01K3C4X7PV4R37GGA6J8NGBNQX	\N	2025-08-23 19:26:46.978611+00	2025-08-23 19:26:46.978611+00	\N
optval_01K3C6BK7NBVZS52WSDD6EHD0E	Dried Fruiting Body Pack of 3	opt_01K3C4X7PV4R37GGA6J8NGBNQX	\N	2025-08-23 19:26:46.978611+00	2025-08-23 19:26:46.978611+00	\N
optval_01K3VPE6KR4MBP1GNC5D53X9AN	Powder Extract	opt_01K3VPE6KSQ1P9VB67AVRAQ4XG	\N	2025-08-29 19:56:26.107+00	2025-08-29 19:56:26.107+00	\N
optval_01K3VPE6KR1QV9TZ288DEC1BK4	Powder Extract Pack of 2	opt_01K3VPE6KSQ1P9VB67AVRAQ4XG	\N	2025-08-29 19:56:26.107+00	2025-08-29 19:56:26.107+00	\N
optval_01K3VPE6KRNE26S2RPM17EFW3T	Powder Extract Pack of 3	opt_01K3VPE6KSQ1P9VB67AVRAQ4XG	\N	2025-08-29 19:56:26.107+00	2025-08-29 19:56:26.107+00	\N
optval_01K3X8E8Q8K2Z8W1JW1TF3PVXK	Liquid Extract	opt_01K3X8E8QBTTG8GMPGYMPCJR61	\N	2025-08-30 10:30:17.071+00	2025-08-30 10:30:17.071+00	\N
optval_01K3X8E8Q9NFXNA3APBRZ4F3QG	Liquid Extract Pack of 2	opt_01K3X8E8QBTTG8GMPGYMPCJR61	\N	2025-08-30 10:30:17.071+00	2025-08-30 10:30:17.071+00	\N
optval_01K3X8E8Q9ED0VFEY829JZD1XS	Liquid Extract Pack of 3	opt_01K3X8E8QBTTG8GMPGYMPCJR61	\N	2025-08-30 10:30:17.071+00	2025-08-30 10:30:17.071+00	\N
\.


--
-- Data for Name: product_sales_channel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_sales_channel (product_id, sales_channel_id, id, created_at, updated_at, deleted_at) FROM stdin;
prod_01K27T4TJ623WRG9MTDCMRY3KM	sc_01K27T4TD2684AR8098EEYSPXP	prodsc_01K27T4TJTPBAPRTBA6N03X6F0	2025-08-09 16:20:42.713745+00	2025-08-18 17:50:53.996+00	2025-08-18 17:50:53.994+00
prod_01K27T4TJ6FMAVAYBNDM56Y2H6	sc_01K27T4TD2684AR8098EEYSPXP	prodsc_01K27T4TJSYTCZQ3YB4FKXQR3B	2025-08-09 16:20:42.713745+00	2025-08-18 17:50:57.417+00	2025-08-18 17:50:57.416+00
prod_01K27T4TJ6K5AVRV4DKF0KYPYD	sc_01K27T4TD2684AR8098EEYSPXP	prodsc_01K27T4TJTBCE3X4AVQTGAQT6J	2025-08-09 16:20:42.713745+00	2025-08-18 17:51:00.881+00	2025-08-18 17:51:00.881+00
prod_01K27T4TJ6KMY70MBFN4VBG6SG	sc_01K27T4TD2684AR8098EEYSPXP	prodsc_01K27T4TJTVH0DVZY0C5PRJMPE	2025-08-09 16:20:42.713745+00	2025-08-18 17:51:05.016+00	2025-08-18 17:51:05.016+00
prod_01K2Z994EST8C7XJDETY9DW9BV	sc_01K27T4TD2684AR8098EEYSPXP	prodsc_01K2Z994G8SJXAQ4PW36STMYAR	2025-08-18 19:07:44.518867+00	2025-08-18 19:07:44.518867+00	\N
prod_01K38QHGW0SP8EZSGVBNQJ9C5R	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K38QHGY2H33MEFGQE6V0Z8QQ	2025-08-22 11:10:09.34612+00	2025-08-22 11:10:09.34612+00	\N
prod_01K38QHGW0PS220EJ343E4QWDV	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K38QHGY3FC6JKGQJ6TDZ8NWE	2025-08-22 11:10:09.34612+00	2025-08-22 11:10:09.34612+00	\N
prod_01K38QHGW0FBQNNM18Y3Z2YME2	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K38QHGY3Z4B36SBQTB7Q9VNY	2025-08-22 11:10:09.34612+00	2025-08-22 11:10:09.34612+00	\N
prod_01K38QHGW0CF2T25FXBXA2G2KR	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K38QHGY3FZ0YJ203EFHPPSF1	2025-08-22 11:10:09.34612+00	2025-08-22 11:10:09.34612+00	\N
prod_01K3BYYS4TQETWPF96CNF4ZBZ5	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K3BYYSB2GD3CPHR06MRX8C29	2025-08-23 17:17:27.260723+00	2025-08-23 17:17:27.260723+00	\N
prod_01K3VPE6KPYPFJ0893VJAV152B	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K3VPE6MV6CH2N032JE00Y6JR	2025-08-29 19:56:26.139222+00	2025-08-29 19:56:26.139222+00	\N
prod_01K3X8E8Q6311HVXSSH879A5A1	sc_01K38QHGFZCEZW38YRKKMXN51C	prodsc_01K3X8E8RH5NWYBZG21NZW1CFR	2025-08-30 10:30:17.105497+00	2025-08-30 10:30:17.105497+00	\N
\.


--
-- Data for Name: product_shipping_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_shipping_profile (product_id, shipping_profile_id, id, created_at, updated_at, deleted_at) FROM stdin;
prod_01K27T4TJ623WRG9MTDCMRY3KM	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K27T4TK1MN1HCZVCVFTC2TW2	2025-08-09 16:20:42.721351+00	2025-08-18 17:50:54.015+00	2025-08-18 17:50:54.014+00
prod_01K27T4TJ6FMAVAYBNDM56Y2H6	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K27T4TK1BVMMHXSYSQKYBWMR	2025-08-09 16:20:42.721351+00	2025-08-18 17:50:57.434+00	2025-08-18 17:50:57.434+00
prod_01K27T4TJ6K5AVRV4DKF0KYPYD	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K27T4TK11DP5YARFZN8024RM	2025-08-09 16:20:42.721351+00	2025-08-18 17:51:00.877+00	2025-08-18 17:51:00.877+00
prod_01K27T4TJ6KMY70MBFN4VBG6SG	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K27T4TK1RA6B3487TX91EE19	2025-08-09 16:20:42.721351+00	2025-08-18 17:51:05.025+00	2025-08-18 17:51:05.025+00
prod_01K38QHGW0SP8EZSGVBNQJ9C5R	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K38QHGYM56K0W7G0GGJHWV8J	2025-08-22 11:10:09.364088+00	2025-08-22 11:10:09.364088+00	\N
prod_01K38QHGW0PS220EJ343E4QWDV	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K38QHGYMDVGSBDJ3SG4YE2PP	2025-08-22 11:10:09.364088+00	2025-08-22 11:10:09.364088+00	\N
prod_01K38QHGW0FBQNNM18Y3Z2YME2	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K38QHGYMS4163YSRQAHN9KYP	2025-08-22 11:10:09.364088+00	2025-08-22 11:10:09.364088+00	\N
prod_01K38QHGW0CF2T25FXBXA2G2KR	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	prodsp_01K38QHGYNSP4DME248Z0R4XZS	2025-08-22 11:10:09.364088+00	2025-08-22 11:10:09.364088+00	\N
\.


--
-- Data for Name: product_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_tag (id, value, metadata, created_at, updated_at, deleted_at) FROM stdin;
ptag_01K3VPG34CS5GZP55G3BHGFEYK	Cordyceps Militaris	\N	2025-08-29 19:57:28.077+00	2025-09-13 11:31:36.931+00	2025-09-13 11:31:36.929+00
ptag_01K3VPJ0NX3WVPGJ9509W8HYWD	Cordyceps Sinensis	\N	2025-08-29 19:58:31.102+00	2025-09-13 11:31:45.914+00	2025-09-13 11:31:45.913+00
ptag_01K3VPJTR84XGYMQBSJVPH85V2	Shiitake	\N	2025-08-29 19:58:57.805+00	2025-09-13 11:31:50.307+00	2025-09-13 11:31:50.307+00
ptag_01K3VPKSYDCKM40PPSZ0E5G9PS	Morel/Gucchi	\N	2025-08-29 19:59:29.742+00	2025-09-13 11:31:53.645+00	2025-09-13 11:31:53.644+00
ptag_01K51Z6NKZNJ4JEJR1VEJJ7JNH	Focus & Concentration	{"slug": "focus_concentration", "mushrooms": ["Lions Mane", "Cordyceps"], "description": "Stay focused and productive"}	2025-09-13 16:40:44.927+00	2025-09-13 16:40:44.927+00	\N
ptag_01K51Z6PMFMTABVENP5VK0WW2A	Memory Support	{"slug": "memory_support", "mushrooms": ["Lions Mane"], "description": "Better memory and recall"}	2025-09-13 16:40:45.967+00	2025-09-13 16:40:45.967+00	\N
ptag_01K51Z6QMZ1HFEYZPKGPYQJ9M0	Brain Health	{"slug": "brain_health", "mushrooms": ["Lions Mane", "Reishi"], "description": "Support long-term brain wellness"}	2025-09-13 16:40:47.007+00	2025-09-13 16:40:47.007+00	\N
ptag_01K51Z6RN3GHS9QG8XTWP56CW3	Neuroprotection	{"slug": "neuroprotection", "mushrooms": ["Lions Mane"], "description": "Protect your brain cells naturally"}	2025-09-13 16:40:48.035+00	2025-09-13 16:40:48.035+00	\N
ptag_01K51Z6SN51GGH2A482H25EGFK	Cognitive Function	{"slug": "cognitive_function", "mushrooms": ["Lions Mane", "Cordyceps"], "description": "Enhance mental performance"}	2025-09-13 16:40:49.061+00	2025-09-13 16:40:49.061+00	\N
ptag_01K51Z6TNT47WQJPMVB389GQ52	Natural Energy	{"slug": "natural_energy", "mushrooms": ["Cordyceps", "Lions Mane"], "description": "Sustained energy without crash"}	2025-09-13 16:40:50.106+00	2025-09-13 16:40:50.106+00	\N
ptag_01K51Z6VP6Y4ZJ8JGFM4FQPQ90	Stamina & Endurance	{"slug": "stamina_endurance", "mushrooms": ["Cordyceps"], "description": "Go further and push harder"}	2025-09-13 16:40:51.142+00	2025-09-13 16:40:51.142+00	\N
ptag_01K51DZ17XTDHCH991DYSBYH53	Mental Clarity	{"mushrooms": "[\\"Lions Mane\\", \\"Reishi\\"]", "description": "Sharper thinking and clearer mind"}	2025-09-13 11:39:28.894+00	2025-09-13 15:54:21.4+00	2025-09-13 15:54:21.399+00
ptag_01K51E8BAY3G3EHQ8X2V93W5RA	Focus & Concentration	{"mushrooms": "[\\"Lions Mane\\", \\"Cordyceps\\"]", "description": "Stay focused and productive"}	2025-09-13 11:44:34.143+00	2025-09-13 15:54:24.409+00	2025-09-13 15:54:24.409+00
ptag_01K51EAGFAZS8WBN73BM92B3YE	Memory Support	{"mushrooms": "[\\"Lions Mane\\"]", "description": "Better memory and recall"}	2025-09-13 11:45:44.938+00	2025-09-13 15:54:28.218+00	2025-09-13 15:54:28.217+00
ptag_01K51EC8WH0CQ8KDKKTVEHYDYP	Natural Energy	{"mushrooms": "[\\"Cordyceps\\", \\"Lions Mane\\"]", "description": "Sustained energy without crash"}	2025-09-13 11:46:42.706+00	2025-09-13 15:54:31.095+00	2025-09-13 15:54:31.094+00
ptag_01K51EDTPCNBJ13R45G1NEH0XD	Stamina & Endurance	{"mushrooms": "[\\"Cordyceps\\"]", "description": "Go further and push harder"}	2025-09-13 11:47:33.709+00	2025-09-13 15:54:33.882+00	2025-09-13 15:54:33.882+00
ptag_01K51EFFPGFJCSYHQD6WNX23V8	Stress Relief	{"mushrooms": "[\\"Reishi\\", \\"Chaga\\"]", "descrioption": "Find your calm in chaos"}	2025-09-13 11:48:27.984+00	2025-09-13 15:54:40.543+00	2025-09-13 15:54:40.543+00
ptag_01K51EH49Z11KNZ6VH4GDH8CR1	Better Sleep	{"mushrooms": "[\\"Reishi\\"]", "description": "Rest deeper and wake refreshed"}	2025-09-13 11:49:21.856+00	2025-09-13 15:54:46.711+00	2025-09-13 15:54:46.711+00
ptag_01K51EJV9SS7Z08WVPBD3CVRYC	Immune Support	{"mushrooms": "[\\"Turkey Tail\\", \\"Reishi\\", \\"Chaga\\", \\"Shiitake\\", \\"Maitake\\"]", "description": "Strengthen your natural defenses"}	2025-09-13 11:50:18.17+00	2025-09-13 15:54:50.84+00	2025-09-13 15:54:50.84+00
ptag_01K51EMN1T9W77C64CW66EVFHD	Skin Health	{"mushrooms": "[\\"Chaga\\", \\"Tremella\\", \\"Turkey Tail\\"]", "description": "Glow from the inside out"}	2025-09-13 11:51:17.308+00	2025-09-13 15:54:54.052+00	2025-09-13 15:54:54.051+00
ptag_01K51EP6HNH8HJ255JMRK1GJCQ	Gut Health	{"mushrooms": "[\\"Turkey Tail\\", \\"Shiitake\\", \\"Maitake\\"]", "description": "Support your second brain"}	2025-09-13 11:52:07.989+00	2025-09-13 15:54:57.25+00	2025-09-13 15:54:57.249+00
ptag_01K51ES8E1RCQG1A6N4VVADSGQ	Heart Health	{"mushrooms": "[\\"Shiitake\\", \\"Maitake\\", \\"Oyster\\", \\"Reishi\\"]", "description": "Keep your heart strong and healthy"}	2025-09-13 11:53:48.226+00	2025-09-13 15:55:04.602+00	2025-09-13 15:55:04.601+00
ptag_01K51X90F2DKS9PE82AWEKF19M	ckjn;kjnkjnf	{"tags": ["dkjbkijdb", "dkjbkdjbd"], "desct": "dfkjbkfjbkfjbnf"}	2025-09-13 16:07:04.421+00	2025-09-13 16:07:17.034+00	2025-09-13 16:07:17.033+00
ptag_01K51Z6MEE17A102PGGWNYRWKJ	Mental Clarity	{"slug": "mental_clarity", "mushrooms": ["Lions Mane", "Reishi"], "description": "Sharper thinking and clearer mind"}	2025-09-13 16:40:43.726+00	2025-09-13 16:40:43.726+00	\N
ptag_01K51Z6WPFAENS2NYD29TXYRFR	Athletic Performance	{"slug": "athletic_performance", "mushrooms": ["Cordyceps", "Shiitake"], "description": "Enhance your workout performance"}	2025-09-13 16:40:52.175+00	2025-09-13 16:40:52.175+00	\N
ptag_01K51Z6XPP3VY7KK3VD9YY7SEQ	Vitality Boost	{"slug": "vitality_boost", "mushrooms": ["Cordyceps", "Reishi"], "description": "Feel more alive and energetic"}	2025-09-13 16:40:53.207+00	2025-09-13 16:40:53.207+00	\N
ptag_01K51Z6YQ32X7VSXTS01KRHM4P	Sustained Energy	{"slug": "sustained_energy", "mushrooms": ["Cordyceps"], "description": "Long-lasting energy throughout the day"}	2025-09-13 16:40:54.243+00	2025-09-13 16:40:54.243+00	\N
ptag_01K51X9GTS3ECDP443X0S1CTXV	ckjn;kjnkjnf	{"tags": ["dkjbkijdb", "dkjbkdjbd"], "desct": "dfkjbkfjbkfjbnf"}	2025-09-13 16:07:21.178+00	2025-09-13 16:41:52.25+00	2025-09-13 16:41:52.249+00
ptag_01K51Z6ZQCQ0PRWVJW6Y0QEH6A	Recovery Support	{"slug": "recovery_support", "mushrooms": ["Cordyceps", "Reishi"], "description": "Enhance physical and mental recovery"}	2025-09-13 16:40:55.276+00	2025-09-13 16:40:55.276+00	\N
ptag_01K51Z71R05M1CQVKZ6JR15N5W	Better Sleep	{"slug": "better_sleep", "mushrooms": ["Reishi"], "description": "Rest deeper and wake refreshed"}	2025-09-13 16:40:57.344+00	2025-09-13 16:40:57.344+00	\N
ptag_01K51Z73RFH5F22J5BZF0RN1HA	Relaxation	{"slug": "relaxation", "mushrooms": ["Reishi", "Chaga"], "description": "Unwind and let go of tension"}	2025-09-13 16:40:59.407+00	2025-09-13 16:40:59.407+00	\N
ptag_01K51Z74RSGYT0W55C4PR38BW1	Adaptogenic	{"slug": "adaptogenic", "mushrooms": ["Reishi", "Cordyceps", "Chaga"], "description": "Help your body adapt to stress naturally"}	2025-09-13 16:41:00.442+00	2025-09-13 16:41:00.442+00	\N
ptag_01K51Z77T42ZD0MJZ0Z9W3WBE7	Antioxidant Protection	{"slug": "antioxidant_protection", "mushrooms": ["Chaga", "Turkey Tail", "Reishi"], "description": "Fight free radicals naturally"}	2025-09-13 16:41:03.556+00	2025-09-13 16:41:03.556+00	\N
ptag_01K51Z79TTTQG3ECEX11YFKD0D	Seasonal Wellness	{"slug": "seasonal_wellness", "mushrooms": ["Turkey Tail", "Chaga", "Reishi"], "description": "Stay healthy year-round"}	2025-09-13 16:41:05.626+00	2025-09-13 16:41:05.626+00	\N
ptag_01K51Z7CVKG9CZSSK4E91NJVX0	Anti-Aging	{"slug": "anti_aging", "mushrooms": ["Chaga", "Reishi", "Tremella"], "description": "Age gracefully and naturally"}	2025-09-13 16:41:08.723+00	2025-09-13 16:41:08.723+00	\N
ptag_01K51Z7FWGDT2RYJ9TZQ3QCTE8	Gut Health	{"slug": "gut_health", "mushrooms": ["Turkey Tail", "Shiitake", "Maitake"], "description": "Support your second brain"}	2025-09-13 16:41:11.825+00	2025-09-13 16:41:11.825+00	\N
ptag_01K51Z7HX37TVAJA4YBWZ3G604	Microbiome Support	{"slug": "microbiome_support", "mushrooms": ["Turkey Tail"], "description": "Feed your good bacteria"}	2025-09-13 16:41:13.891+00	2025-09-13 16:41:13.891+00	\N
ptag_01K51Z7KY3VSVFW84C1E3SAPCN	Gut-Brain Connection	{"slug": "gut_brain_connection", "mushrooms": ["Turkey Tail"], "description": "Support the connection between gut and mind"}	2025-09-13 16:41:15.971+00	2025-09-13 16:41:15.971+00	\N
ptag_01K51Z7NYM5WDMS8T3PZE9C73T	Circulation Support	{"slug": "circulation_support", "mushrooms": ["Shiitake", "Cordyceps", "King Oyster"], "description": "Improve blood flow naturally"}	2025-09-13 16:41:18.037+00	2025-09-13 16:41:18.037+00	\N
ptag_01K51Z7QYYQC9BA7BS2H826AAV	Blood Pressure Support	{"slug": "blood_pressure_support", "mushrooms": ["Reishi", "Maitake"], "description": "Support healthy blood pressure"}	2025-09-13 16:41:20.095+00	2025-09-13 16:41:20.095+00	\N
ptag_01K51Z7SZPHJ8VKRP50XBSNQW7	Libido Support	{"slug": "libido_support", "mushrooms": ["Cordyceps"], "description": "Natural support for healthy intimacy"}	2025-09-13 16:41:22.166+00	2025-09-13 16:41:22.166+00	\N
ptag_01K51Z7W088JGRR0D5WWBY9KK2	Metabolism Support	{"slug": "metabolism_support", "mushrooms": ["Maitake"], "description": "Support healthy metabolic function"}	2025-09-13 16:41:24.233+00	2025-09-13 16:41:24.233+00	\N
ptag_01K51Z7X0KM4ZTCG1F7XSK5J0B	Blood Sugar Support	{"slug": "blood_sugar_support", "mushrooms": ["Maitake"], "description": "Support healthy blood sugar levels"}	2025-09-13 16:41:25.267+00	2025-09-13 16:41:25.267+00	\N
ptag_01K51Z75S4YP7RNKQCAKWSTN7W	Anxiety Support	{"slug": "anxiety_support", "mushrooms": ["Reishi"], "description": "Natural support for anxious feelings"}	2025-09-13 16:41:01.476+00	2025-09-13 16:41:01.476+00	\N
ptag_01K51Z76SPZE7BX0DF2A6V9GT7	Immune Support	{"slug": "immune_support", "mushrooms": ["Turkey Tail", "Reishi", "Chaga", "Shiitake", "Maitake"], "description": "Strengthen your natural defenses"}	2025-09-13 16:41:02.519+00	2025-09-13 16:41:02.519+00	\N
ptag_01K51Z78THYCWVPXEQWQCSZWEV	Anti-Inflammatory	{"slug": "anti_inflammatory", "mushrooms": ["Turkey Tail", "Chaga", "Shiitake", "Maitake"], "description": "Reduce inflammation naturally"}	2025-09-13 16:41:04.593+00	2025-09-13 16:41:04.593+00	\N
ptag_01K51Z7AV2D5FDPQHQYBY995RG	Overall Wellness	{"slug": "overall_wellness", "mushrooms": ["Turkey Tail", "Reishi", "Chaga"], "description": "Support your total well-being"}	2025-09-13 16:41:06.658+00	2025-09-13 16:41:06.658+00	\N
ptag_01K51Z7BVCFWATNYN5N20T55NP	Skin Health	{"slug": "skin_health", "mushrooms": ["Chaga", "Tremella", "Turkey Tail"], "description": "Glow from the inside out"}	2025-09-13 16:41:07.692+00	2025-09-13 16:41:07.692+00	\N
ptag_01K51Z7DVXNEMXPZ7VE8M7ABBD	Natural Beauty	{"slug": "natural_beauty", "mushrooms": ["Chaga", "Tremella"], "description": "Enhance your natural radiance"}	2025-09-13 16:41:09.758+00	2025-09-13 16:41:09.758+00	\N
ptag_01K51Z7EWG3PS2599G9Q6YQEW0	Collagen Support	{"slug": "collagen_support", "mushrooms": ["Tremella", "Chaga"], "description": "Support your skin's structure naturally"}	2025-09-13 16:41:10.8+00	2025-09-13 16:41:10.8+00	\N
ptag_01K51Z7GWRQ4GW6PXQR2N89ZSB	Digestive Comfort	{"slug": "digestive_comfort", "mushrooms": ["Turkey Tail", "Shiitake"], "description": "Feel comfortable after meals"}	2025-09-13 16:41:12.856+00	2025-09-13 16:41:12.856+00	\N
ptag_01K51Z7JXEKSVAFW6RS9PHEMF7	Prebiotic Benefits	{"slug": "prebiotic_benefits", "mushrooms": ["Turkey Tail", "Shiitake"], "description": "Nourish your beneficial gut bacteria"}	2025-09-13 16:41:14.926+00	2025-09-13 16:41:14.926+00	\N
ptag_01K51Z7MYBN01VQNQGZGG8V3K8	Heart Health	{"slug": "heart_health", "mushrooms": ["Shiitake", "Maitake", "Oyster", "Reishi"], "description": "Keep your heart strong and healthy"}	2025-09-13 16:41:17.003+00	2025-09-13 16:41:17.003+00	\N
ptag_01K51Z7PYN8W3JC6K8W4WSYG7P	Cholesterol Support	{"slug": "cholesterol_support", "mushrooms": ["Shiitake", "Maitake"], "description": "Support healthy cholesterol levels"}	2025-09-13 16:41:19.061+00	2025-09-13 16:41:19.061+00	\N
ptag_01K51Z7RZB7RCTQS3BH1GPPMG0	Lung Health	{"slug": "lung_health", "mushrooms": ["Cordyceps"], "description": "Support respiratory wellness"}	2025-09-13 16:41:21.131+00	2025-09-13 16:41:21.131+00	\N
ptag_01K51Z7TZZ5M7J1VNSQGASQXQP	Weight Management	{"slug": "weight_management", "mushrooms": ["Maitake"], "description": "Support healthy weight goals"}	2025-09-13 16:41:23.2+00	2025-09-13 16:41:23.2+00	\N
ptag_01K51Z70QN252W5CX7PSZTN3H8	Stress Relief	{"slug": "stress_relief", "mushrooms": ["Reishi", "Chaga"], "description": "Find your calm in chaos"}	2025-09-13 16:40:56.309+00	2025-09-13 16:40:56.309+00	\N
ptag_01K51Z72R7XNHBPFNSAKKCBTE1	Emotional Balance	{"slug": "emotional_balance", "mushrooms": ["Reishi"], "description": "Feel more balanced and centered"}	2025-09-13 16:40:58.375+00	2025-09-13 16:40:58.375+00	\N
\.


--
-- Data for Name: product_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_tags (product_id, product_tag_id) FROM stdin;
prod_01K3BYYS4TQETWPF96CNF4ZBZ5	ptag_01K3VPG34CS5GZP55G3BHGFEYK
prod_01K3VPE6KPYPFJ0893VJAV152B	ptag_01K3VPG34CS5GZP55G3BHGFEYK
prod_01K3X8E8Q6311HVXSSH879A5A1	ptag_01K3VPG34CS5GZP55G3BHGFEYK
\.


--
-- Data for Name: product_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_type (id, value, metadata, created_at, updated_at, deleted_at) FROM stdin;
ptyp_01K546Y1WEY30V74535GHQWAY3	dlokjd	{}	2025-09-14 13:34:20.047+00	2025-09-14 13:43:37.641+00	2025-09-14 13:43:37.64+00
ptyp_01K54A6VN3W3XPBDW4GNTTQQJ5	Mind	{"slug":"mind","description":"Cognitive support, memory, focus & mental clarity","tags":["mental_clarity","focus_concentration","memory_support","brain_health","neuroprotection","cognitive_function"]}	2025-09-14 14:31:34.309+00	2025-09-14 14:32:13.061+00	2025-09-14 14:32:13.06+00
ptyp_01K54A6WP7WM0GXYG88J790XRA	Energy	{"slug":"energy","description":"Natural energy, stamina & vitality boost","tags":["natural_energy","stamina_endurance","athletic_performance","vitality_boost","sustained_energy","recovery_support"]}	2025-09-14 14:31:35.367+00	2025-09-14 14:32:16.805+00	2025-09-14 14:32:16.805+00
ptyp_01K54A6XPJ7STB6HPARNJGBJKN	Calm & Relaxation	{"slug":"calm_relaxation","description":"Stress relief, better sleep & emotional balance","tags":["stress_relief","better_sleep","emotional_balance","relaxation","adaptogenic","anxiety_support"]}	2025-09-14 14:31:36.403+00	2025-09-14 14:32:20.187+00	2025-09-14 14:32:20.186+00
ptyp_01K54A6YPXMSV2R4SCB1PHW1C7	Immunity	{"slug":"immunity","description":"Immune system support & overall wellness","tags":["immune_support","antioxidant_protection","anti_inflammatory","seasonal_wellness","overall_wellness"]}	2025-09-14 14:31:37.438+00	2025-09-14 14:32:23.54+00	2025-09-14 14:32:23.54+00
ptyp_01K54A6ZQ969CX9Q6N7G0KCM9N	Beauty	{"slug":"beauty","description":"Skin health, anti-aging & natural radiance","tags":["skin_health","anti_aging","natural_beauty","collagen_support"]}	2025-09-14 14:31:38.474+00	2025-09-14 14:32:26.661+00	2025-09-14 14:32:26.66+00
ptyp_01K54A70QNRT35508JR2RPXB64	Gut	{"slug":"gut","description":"Digestive health & gut microbiome support","tags":["gut_health","digestive_comfort","microbiome_support","prebiotic_benefits","gut_brain_connection"]}	2025-09-14 14:31:39.509+00	2025-09-14 14:32:30.236+00	2025-09-14 14:32:30.236+00
ptyp_01K54A71QXFSB0MQWJ3Y3B541X	Heart	{"slug":"heart","description":"Cardiovascular health & circulation support","tags":["heart_health","circulation_support","cholesterol_support","blood_pressure_support"]}	2025-09-14 14:31:40.542+00	2025-09-14 14:32:33.196+00	2025-09-14 14:32:33.195+00
ptyp_01K54A72R34GWWW079HMJKKBRG	Wellness	{"slug":"wellness","description":"Specialized health benefits & metabolic support","tags":["lung_health","libido_support","weight_management","metabolism_support","blood_sugar_support"]}	2025-09-14 14:31:41.571+00	2025-09-14 14:32:36.404+00	2025-09-14 14:32:36.404+00
ptyp_01K54AAQ2PERGB0S3PHKFMCSCS	Mind	{"slug":"mind","description":"Cognitive support, memory, focus & mental clarity","tags":["mental_clarity","focus_concentration","memory_support","brain_health","neuroprotection","cognitive_function"],"color":"#4A90E2","icon":"brain"}	2025-09-14 14:33:40.695+00	2025-09-14 14:33:40.695+00	\N
ptyp_01K54AAR392G1FSEQ1030HXFJ8	Energy	{"slug":"energy","description":"Natural energy, stamina & vitality boost","tags":["natural_energy","stamina_endurance","athletic_performance","vitality_boost","sustained_energy","recovery_support"],"color":"#F5A623","icon":"energy"}	2025-09-14 14:33:41.737+00	2025-09-14 14:33:41.737+00	\N
ptyp_01K54AAS3SXN9B0RRY61C7VGTM	Calm & Relaxation	{"slug":"calm_relaxation","description":"Stress relief, better sleep & emotional balance","tags":["stress_relief","better_sleep","emotional_balance","relaxation","adaptogenic","anxiety_support"],"color":"#7ED321","icon":"zen"}	2025-09-14 14:33:42.777+00	2025-09-14 14:33:42.777+00	\N
ptyp_01K54AAT3TY2E5TMK4AH29CKDS	Immunity	{"slug":"immunity","description":"Immune system support & overall wellness","tags":["immune_support","antioxidant_protection","anti_inflammatory","seasonal_wellness","overall_wellness"],"color":"#BD10E0","icon":"shield"}	2025-09-14 14:33:43.802+00	2025-09-14 14:33:43.802+00	\N
ptyp_01K54AAV446TE0XSS0JZ541KM1	Beauty	{"slug":"beauty","description":"Skin health, anti-aging & natural radiance","tags":["skin_health","anti_aging","natural_beauty","collagen_support"],"color":"#F8E71C","icon":"sparkles"}	2025-09-14 14:33:44.837+00	2025-09-14 14:33:44.837+00	\N
ptyp_01K54AAW4FFC57NVWZZFJN9EQG	Gut	{"slug":"gut","description":"Digestive health & gut microbiome support","tags":["gut_health","digestive_comfort","microbiome_support","prebiotic_benefits","gut_brain_connection"],"color":"#50E3C2","icon":"gut"}	2025-09-14 14:33:45.872+00	2025-09-14 14:33:45.872+00	\N
ptyp_01K54AAX4S0A2845NZ0QPP0H0S	Heart	{"slug":"heart","description":"Cardiovascular health & circulation support","tags":["heart_health","circulation_support","cholesterol_support","blood_pressure_support"],"color":"#D0021B","icon":"heart"}	2025-09-14 14:33:46.906+00	2025-09-14 14:33:46.906+00	\N
ptyp_01K54AAY52NV2KN39JD1MPBDX5	Wellness	{"slug":"wellness","description":"Specialized health benefits & metabolic support","tags":["lung_health","libido_support","weight_management","metabolism_support","blood_sugar_support"],"color":"#9013FE","icon":"wellness"}	2025-09-14 14:33:47.938+00	2025-09-14 14:33:47.938+00	\N
\.


--
-- Data for Name: product_variant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variant (id, title, sku, barcode, ean, upc, allow_backorder, manage_inventory, hs_code, origin_country, mid_code, material, weight, length, height, width, metadata, variant_rank, product_id, created_at, updated_at, deleted_at) FROM stdin;
variant_01K3BYYSDZCVEMMPWQA50VJT55	30 Grams Pack	\N	\N	\N	\N	t	t	\N	in	\N	\N	30	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 17:17:27.36+00	2025-08-23 19:01:11.609+00	2025-08-23 19:01:11.608+00
variant_01K3C0EWZFCRP5TE9PWERD5J5Y	60 Grams Pack 	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 17:43:43.856+00	2025-08-23 19:01:15.286+00	2025-08-23 19:01:15.286+00
variant_01K3C6E1682SFSYE7THEZ6NRBT	Dried Fruiting Body	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:28:06.858+00	2025-08-23 19:28:06.858+00	\N
variant_01K3C6FN6P45FT6GFE5V23DQGA	Dried Fruiting Body Pack of 2	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:29:00.119+00	2025-08-23 19:29:00.119+00	\N
variant_01K3C6HRCF4R1SKY06S9WS6527	Dried Fruiting Body Pack of 3	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:30:08.912+00	2025-08-23 19:30:08.912+00	\N
variant_01K3C6MEKH3H03B43K72A30XHQ	Liquid Extract	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:31:37.202+00	2025-08-29 19:40:15.787+00	2025-08-29 19:40:15.786+00
variant_01K3C6NJYT7SQAPSENE7B2VYSG	Liquid Extract Pack of 2	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:32:14.427+00	2025-08-29 19:40:20.617+00	2025-08-29 19:40:20.617+00
variant_01K3C6PPGMJKA7CMY32TCTM3SV	Liquid Extract Pack of 3	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:32:50.84+00	2025-08-29 19:40:24.519+00	2025-08-29 19:40:24.519+00
variant_01K3C6QVE2GC2ER6H2P4Q5582K	Powdered Extract	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:33:28.643+00	2025-08-29 19:40:28.036+00	2025-08-29 19:40:28.036+00
variant_01K3C6S8EMB77T3DDT83DW4TJ8	Powdered Extract Pack of 2	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:34:14.74+00	2025-08-29 19:40:31.544+00	2025-08-29 19:40:31.544+00
variant_01K3C6YY9VGE99H0KQQ24K4QN4	Powderd Extract Pack of 3	\N	\N	\N	\N	f	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3BYYS4TQETWPF96CNF4ZBZ5	2025-08-23 19:37:20.955+00	2025-08-29 19:40:35.982+00	2025-08-29 19:40:35.982+00
variant_01K3VPE6P1X6Y4ZJJK2GZJHXZA	Powder Extract	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3VPE6KPYPFJ0893VJAV152B	2025-08-29 19:56:26.177+00	2025-08-29 19:56:26.177+00	\N
variant_01K3VPE6P1JA636PJYB5C3S498	Powder Extract Pack of 2	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	prod_01K3VPE6KPYPFJ0893VJAV152B	2025-08-29 19:56:26.178+00	2025-08-29 19:56:26.178+00	\N
variant_01K3VPE6P185HB2AZR6CKXAWV7	Powder Extract Pack of 3	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	prod_01K3VPE6KPYPFJ0893VJAV152B	2025-08-29 19:56:26.178+00	2025-08-29 19:56:26.178+00	\N
variant_01K3X8E8SPW123NBF8F7W8Y1Z0	Liquid Extract	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	prod_01K3X8E8Q6311HVXSSH879A5A1	2025-08-30 10:30:17.143+00	2025-08-30 10:30:17.143+00	\N
variant_01K3X8E8SPY8JK4E8SYPP8VJ3P	Liquid Extract Pack of 2	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	prod_01K3X8E8Q6311HVXSSH879A5A1	2025-08-30 10:30:17.143+00	2025-08-30 10:30:17.143+00	\N
variant_01K3X8E8SPSMMBKSWNJQ4SNGH6	Liquid Extract Pack of 3	\N	\N	\N	\N	t	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	prod_01K3X8E8Q6311HVXSSH879A5A1	2025-08-30 10:30:17.143+00	2025-08-30 10:30:17.143+00	\N
\.


--
-- Data for Name: product_variant_inventory_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variant_inventory_item (variant_id, inventory_item_id, id, required_quantity, created_at, updated_at, deleted_at) FROM stdin;
variant_01K27T4TKM2QJFFE9PBBX6AKR6	iitem_01K27T4TMAX139PQFCHYPN4TH8	pvitem_01K27T4TMXWD2B8EV4XM841PGJ	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:53.959+00	2025-08-18 17:50:53.956+00
variant_01K27T4TKMGEC09PF2M88G72FK	iitem_01K27T4TMA955R958J4VNWHFWX	pvitem_01K27T4TMXZ7C2VZQGV3QD54N7	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:53.959+00	2025-08-18 17:50:53.956+00
variant_01K27T4TKMQM9AZWF1EFTBCT3K	iitem_01K27T4TMA0CNK32TFYXEZZ2G3	pvitem_01K27T4TMXTA6G0ZYE4381N7TK	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:53.959+00	2025-08-18 17:50:53.956+00
variant_01K27T4TKMZZJ86DQTW1P02A4Z	iitem_01K27T4TMAAZR8C595XC56B2T2	pvitem_01K27T4TMX9Z41TV89Z34M4C3M	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:53.959+00	2025-08-18 17:50:53.956+00
variant_01K27T4TKJV7KGJEWHCXBSGV8W	iitem_01K27T4TM8BRWK4VN20VHX4SX3	pvitem_01K27T4TMV9D6NGC9YC38FGHVV	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKJ02WE697MYK92DR62	iitem_01K27T4TM9Q8G0B62N1E3EAF0P	pvitem_01K27T4TMVB1J7S9DE8NZK6R2F	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKJJYFQX26FZGTCYTHH	iitem_01K27T4TM9503PMP2M0B0P8D0C	pvitem_01K27T4TMW2ANJ00R3EHJBPWDN	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKKGG0MP8XD81V060Q5	iitem_01K27T4TM9KBZ4165DMMCZK4CP	pvitem_01K27T4TMW1CQSVBXQ25DQAKBF	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKK15S3R1T1F51HGYXQ	iitem_01K27T4TM96RMTD0QKARW3AJ1P	pvitem_01K27T4TMWH4753RCYNW2G3CV8	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKKMVZ5NTS3JV0P1MV7	iitem_01K27T4TM9SRW00YCAXTNRBDB2	pvitem_01K27T4TMWAN25CSQ46V9AKYBK	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKK1KH6SKYGRQABTMMR	iitem_01K27T4TM97VVJF458NBRGAG57	pvitem_01K27T4TMWRYK5R2NS9A4TYFAR	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKK259JN75PNJJY21QH	iitem_01K27T4TM9F3NPQDBGWPQ0TRA6	pvitem_01K27T4TMWQ8YSXAKV7JZW7NV6	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:50:57.401+00	2025-08-18 17:50:57.4+00
variant_01K27T4TKKHWSH2GFWM5K7X31Y	iitem_01K27T4TM9TWF8AN1SF8YWX88C	pvitem_01K27T4TMWZ4G1XSN698QYPG2D	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:00.868+00	2025-08-18 17:51:00.868+00
variant_01K27T4TKMWTKPSB9BEZNKCCSN	iitem_01K27T4TM9HA5JERK0FWX6CRHN	pvitem_01K27T4TMWYGC4CXGPAWM2BTHV	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:00.868+00	2025-08-18 17:51:00.868+00
variant_01K27T4TKMNY2ZSW43H80QTTTK	iitem_01K27T4TM966F1YJD842192WN1	pvitem_01K27T4TMWZ9ASAHNQ8X2DJ0NS	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:00.868+00	2025-08-18 17:51:00.868+00
variant_01K27T4TKMVYP68YJCSQ8STX6T	iitem_01K27T4TMADX66C6Y08WRVXFSW	pvitem_01K27T4TMXZ26T2DMAZEREW69W	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:00.868+00	2025-08-18 17:51:00.868+00
variant_01K27T4TKKACQ02YVC962NVCWF	iitem_01K27T4TM9KBZBMY2SWHGKK775	pvitem_01K27T4TMWC23GNF12Q161ZN34	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:04.999+00	2025-08-18 17:51:04.999+00
variant_01K27T4TKKT5PYD9AK7JSAK01W	iitem_01K27T4TM9RTVHWXBZH0W63KRD	pvitem_01K27T4TMWR48RQFPVQTXYD3J2	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:04.999+00	2025-08-18 17:51:04.999+00
variant_01K27T4TKKX36PDTMCK89FYES0	iitem_01K27T4TM9QJFXVA2JCPXG4AX2	pvitem_01K27T4TMW9DK8FJB8RNGED7HK	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:04.999+00	2025-08-18 17:51:04.999+00
variant_01K27T4TKK6B35N98YCE5JCESF	iitem_01K27T4TM97D32T4E4P1WNPB20	pvitem_01K27T4TMWZ9REYYYZENXTAHQ3	1	2025-08-09 16:20:42.779294+00	2025-08-18 17:51:04.999+00	2025-08-18 17:51:04.999+00
variant_01K38QHGZMHE83HH5XJSRBS4PT	iitem_01K38QHH0PV9HRQE2K5PRCGQRG	pvitem_01K38QHH1GNBT20BW7YH9N937D	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZMFB69P6EENPZN6JRY	iitem_01K38QHH0PE8NV9MQFV2SP0SZS	pvitem_01K38QHH1GTST0QT00HB66F2RE	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZMTC4JS70YWC0CA3PJ	iitem_01K38QHH0PNT9NB1H9N2R3GEQR	pvitem_01K38QHH1HY9KSRYBCH88C55AZ	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZMQEM58685MV1EGVBY	iitem_01K38QHH0P2VXF921VSDJ87Z6F	pvitem_01K38QHH1HBMZA3SH8VCNJFT5E	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZME8GGEYNNPTSRVKEW	iitem_01K38QHH0PJ84ASKC68EDD2TJ3	pvitem_01K38QHH1HHPPZYTHZ8WE7SBSS	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZN4WZNMKF2B6C74XF7	iitem_01K38QHH0Q85EHYY3SQ49QP6AB	pvitem_01K38QHH1HQ4WXQQ19CTQEB2JS	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZNQJAGYGNKTN84RAYX	iitem_01K38QHH0QF393QPA67MJAWB7H	pvitem_01K38QHH1HTC2Q07SZWQB0M33Y	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZNTAQ158HE66CDEER3	iitem_01K38QHH0QJ3PECSG5J8GAAHJ4	pvitem_01K38QHH1HRF2G41AKBQF62GD9	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZNM03X74761MZ9KZ46	iitem_01K38QHH0QR5A8X9KR2PNY9YS9	pvitem_01K38QHH1HXQHW2HXX3XJE211P	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZN5WFSMF6Z8C8GM24N	iitem_01K38QHH0QJQQQETMPCM938Z5Y	pvitem_01K38QHH1HZ7Q06NRJZTA45ANR	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZNFFP8C2YPBBQ9E32G	iitem_01K38QHH0QGQPKJG1J2MWB0GF1	pvitem_01K38QHH1H3HHTBDBT5QTG3VEJ	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZNE42MSMSA481SW63K	iitem_01K38QHH0QKR212ST0ABX8Q8FN	pvitem_01K38QHH1HK0CVPDMWNMWS3GJR	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZNRVK9BRKC93PCYN9Z	iitem_01K38QHH0QTTMTHJGWK2GZNST9	pvitem_01K38QHH1HG83TBPYEPDS32WAS	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZPN2CP8XXSPFV68E83	iitem_01K38QHH0Q0F0MY4DASZ8K42AE	pvitem_01K38QHH1H469P3XQEHFEXZ770	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZP4G5WKEXBX15KJMRX	iitem_01K38QHH0QK30Z721KDVKQN4MV	pvitem_01K38QHH1HBQD680A97GTRA5XE	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZP5YSCFBJKFHRQ2E6K	iitem_01K38QHH0QZCFBCNBKEBC5J98G	pvitem_01K38QHH1HM4NHSNCB0083XP90	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZP0RDKDX6DH33PYR7B	iitem_01K38QHH0QKM4AV53CFC9WTCW4	pvitem_01K38QHH1HDD372CK5ZG6R3H5P	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZPT63J9R1DBY15V8NX	iitem_01K38QHH0Q6BBWKP9RSNQS7VAA	pvitem_01K38QHH1JZTQV2CQKXKBZECC1	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZPGG9RPX8KH4GZ38X5	iitem_01K38QHH0Q45TTZ69G5Q7Y63T6	pvitem_01K38QHH1JWXGMRGFHG0AYMCK3	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K38QHGZP4J4N4SZ1VT4BFJ4E	iitem_01K38QHH0QHSGVE8P0MH3MFAAD	pvitem_01K38QHH1J8Y238W75HXAXZF1G	1	2025-08-22 11:10:09.45618+00	2025-08-22 11:10:09.45618+00	\N
variant_01K3C0EWZFCRP5TE9PWERD5J5Y	iitem_01K3C0EX0F9KTDTAPTP5526AMV	pvitem_01K3C0EX2JC87FXHYAXNHR5DFP	1	2025-08-23 17:43:43.953514+00	2025-08-23 19:01:15.245+00	2025-08-23 19:01:15.244+00
variant_01K3C6E1682SFSYE7THEZ6NRBT	iitem_01K3C6E17GM11CHQ2W4KKBKNSR	pvitem_01K3C6E18EMPNN0SCM2WG9M55X	1	2025-08-23 19:28:06.925387+00	2025-08-23 19:28:06.925387+00	\N
variant_01K3C6FN6P45FT6GFE5V23DQGA	iitem_01K3C6FN7GM3JFEQHGEWW44CHT	pvitem_01K3C6FN835W7JM73WPCGC0C9T	1	2025-08-23 19:29:00.163+00	2025-08-23 19:29:00.163+00	\N
variant_01K3C6HRCF4R1SKY06S9WS6527	iitem_01K3C6HRD39E77M0793SW4VK1Z	pvitem_01K3C6HRDFC12BAMT2QFQA0P7X	1	2025-08-23 19:30:08.943091+00	2025-08-23 19:30:08.943091+00	\N
variant_01K3C6MEKH3H03B43K72A30XHQ	iitem_01K3C6MEN719BCAS12N6SCRM26	pvitem_01K3C6MEQBJRBQ40QFG1P564XF	1	2025-08-23 19:31:37.318999+00	2025-08-29 19:40:15.709+00	2025-08-29 19:40:15.706+00
variant_01K3C6NJYT7SQAPSENE7B2VYSG	iitem_01K3C6NJZ9GEKA190ERS3DGRFK	pvitem_01K3C6NJZZXKXAZAK6JJZYRTES	1	2025-08-23 19:32:14.463278+00	2025-08-29 19:40:20.571+00	2025-08-29 19:40:20.57+00
variant_01K3C6PPGMJKA7CMY32TCTM3SV	iitem_01K3C6PPHKN9S3GDQARRBZVSJX	pvitem_01K3C6PPJ5P83B5CPKV0SVMCGY	1	2025-08-23 19:32:50.884536+00	2025-08-29 19:40:24.483+00	2025-08-29 19:40:24.482+00
variant_01K3C6QVE2GC2ER6H2P4Q5582K	iitem_01K3C6QVF54G051CQH5DJYP26W	pvitem_01K3C6QVG33C5YTRPYEP60NBSG	1	2025-08-23 19:33:28.707304+00	2025-08-29 19:40:27.97+00	2025-08-29 19:40:27.969+00
variant_01K3C6YY9VGE99H0KQQ24K4QN4	iitem_01K3C6YYAKS5S8YQ0AGFMTJJ6Y	pvitem_01K3C6YYB55Z02S6M3B16CSHG2	1	2025-08-23 19:37:20.997241+00	2025-08-29 19:40:35.945+00	2025-08-29 19:40:35.943+00
variant_01K3C6S8EMB77T3DDT83DW4TJ8	iitem_01K3C6S8F1GEVMW4Y7AWQJ2533	pvitem_01K3C6S8FQ6JVV51V1DBPFJXNX	1	2025-08-23 19:34:14.775382+00	2025-08-29 19:40:31.487+00	2025-08-29 19:40:31.486+00
variant_01K3VPE6P1X6Y4ZJJK2GZJHXZA	iitem_01K3VPE6PRCD1J9JXSEEACMCZA	pvitem_01K3VPE6Q98B9EG7CZ359VYV66	1	2025-08-29 19:56:26.21693+00	2025-08-29 19:56:26.21693+00	\N
variant_01K3VPE6P1JA636PJYB5C3S498	iitem_01K3VPE6PRWTREC7V5R3WN4KKJ	pvitem_01K3VPE6Q9JVPGKE60NZ5RTQTZ	1	2025-08-29 19:56:26.21693+00	2025-08-29 19:56:26.21693+00	\N
variant_01K3VPE6P185HB2AZR6CKXAWV7	iitem_01K3VPE6PRQHNN26Y3NVQT20G3	pvitem_01K3VPE6Q9SGWC76521HQWSES7	1	2025-08-29 19:56:26.21693+00	2025-08-29 19:56:26.21693+00	\N
variant_01K3X8E8SPW123NBF8F7W8Y1Z0	iitem_01K3X8E8TENK0PSCJVEWN64KJ4	pvitem_01K3X8E8V8C9259NY7TGE0PT9W	1	2025-08-30 10:30:17.19259+00	2025-08-30 10:30:17.19259+00	\N
variant_01K3X8E8SPY8JK4E8SYPP8VJ3P	iitem_01K3X8E8TE8YK7HC90Y9QSQTPX	pvitem_01K3X8E8VAYGHWCGK3FVAHGGKP	1	2025-08-30 10:30:17.19259+00	2025-08-30 10:30:17.19259+00	\N
variant_01K3X8E8SPSMMBKSWNJQ4SNGH6	iitem_01K3X8E8TFAKTE13GD3VVCXDNK	pvitem_01K3X8E8VBBHK14EJ0FJ1NEKGM	1	2025-08-30 10:30:17.19259+00	2025-08-30 10:30:17.19259+00	\N
\.


--
-- Data for Name: product_variant_option; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variant_option (variant_id, option_value_id) FROM stdin;
variant_01K3C0EWZFCRP5TE9PWERD5J5Y	optval_01K3C0CT6AE2JHSNZ3W1DTFBJH
variant_01K3BYYSDZCVEMMPWQA50VJT55	optval_01K3C15SM4P3Q81EMA2E4TXTQ2
variant_01K3C6E1682SFSYE7THEZ6NRBT	optval_01K3C6BK7NWZQM665RZFT6XBNM
variant_01K3C6FN6P45FT6GFE5V23DQGA	optval_01K3C6BK7NS8FT1A88ZQCCC1P2
variant_01K3C6HRCF4R1SKY06S9WS6527	optval_01K3C6BK7NBVZS52WSDD6EHD0E
variant_01K3VPE6P1X6Y4ZJJK2GZJHXZA	optval_01K3VPE6KR4MBP1GNC5D53X9AN
variant_01K3VPE6P1JA636PJYB5C3S498	optval_01K3VPE6KR1QV9TZ288DEC1BK4
variant_01K3VPE6P185HB2AZR6CKXAWV7	optval_01K3VPE6KRNE26S2RPM17EFW3T
variant_01K3X8E8SPW123NBF8F7W8Y1Z0	optval_01K3X8E8Q8K2Z8W1JW1TF3PVXK
variant_01K3X8E8SPY8JK4E8SYPP8VJ3P	optval_01K3X8E8Q9NFXNA3APBRZ4F3QG
variant_01K3X8E8SPSMMBKSWNJQ4SNGH6	optval_01K3X8E8Q9ED0VFEY829JZD1XS
\.


--
-- Data for Name: product_variant_price_set; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_variant_price_set (variant_id, price_set_id, id, created_at, updated_at, deleted_at) FROM stdin;
variant_01K27T4TKM2QJFFE9PBBX6AKR6	pset_01K27T4TN8FKAJB9023EHNSAG7	pvps_01K27T4TP5ZZEPYCE1SZNKM665	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:54.001+00	2025-08-18 17:50:53.999+00
variant_01K27T4TKMGEC09PF2M88G72FK	pset_01K27T4TN87Q6RNVHWZT8Z6XRP	pvps_01K27T4TP57DPCGDA003E1JS6Z	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:54.001+00	2025-08-18 17:50:53.999+00
variant_01K27T4TKMQM9AZWF1EFTBCT3K	pset_01K27T4TN950VTZEHQM17VKDQF	pvps_01K27T4TP577VVM64548B2R3VS	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:54.001+00	2025-08-18 17:50:53.999+00
variant_01K27T4TKMZZJ86DQTW1P02A4Z	pset_01K27T4TN9VFWVMES3CG4M3EMR	pvps_01K27T4TP52P3CEQGXTJQZMZ49	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:54.001+00	2025-08-18 17:50:53.999+00
variant_01K27T4TKJV7KGJEWHCXBSGV8W	pset_01K27T4TN5N7TCS6PHX3RPDDD9	pvps_01K27T4TP4TY3KBAQ736MXV3HN	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKJ02WE697MYK92DR62	pset_01K27T4TN5T5WJYG5WYWV3ZHBE	pvps_01K27T4TP40R1NTVAQ4EP2Z2YG	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKJJYFQX26FZGTCYTHH	pset_01K27T4TN57XJHK52JSSW1DDN0	pvps_01K27T4TP4977253291DY2C1HF	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKKGG0MP8XD81V060Q5	pset_01K27T4TN5T0QKSYXPMSAV7RTJ	pvps_01K27T4TP4NDD3HPV3VD005W19	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKK15S3R1T1F51HGYXQ	pset_01K27T4TN6867T7AGGF9ENDHAT	pvps_01K27T4TP5KTXRT55CVSTEWED6	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKKMVZ5NTS3JV0P1MV7	pset_01K27T4TN6YXZQTDGA80RJX0KG	pvps_01K27T4TP5Y7ZV9CHSBA1XP9PN	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKK1KH6SKYGRQABTMMR	pset_01K27T4TN6T2ECQR6AB86DYGNG	pvps_01K27T4TP52AC69GH3WSJN5SWN	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKK259JN75PNJJY21QH	pset_01K27T4TN69K86XCF05DY4WA9A	pvps_01K27T4TP5S06553BNB5EX3SW8	2025-08-09 16:20:42.820271+00	2025-08-18 17:50:57.411+00	2025-08-18 17:50:57.411+00
variant_01K27T4TKKHWSH2GFWM5K7X31Y	pset_01K27T4TN7FG4YXMWYEK2EYAVT	pvps_01K27T4TP5R45Q7DW0T2841BNE	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:00.885+00	2025-08-18 17:51:00.885+00
variant_01K27T4TKMWTKPSB9BEZNKCCSN	pset_01K27T4TN8EMDCA0S7AP4C5JTT	pvps_01K27T4TP5T22T228DG6F9YPQ4	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:00.885+00	2025-08-18 17:51:00.885+00
variant_01K27T4TKMNY2ZSW43H80QTTTK	pset_01K27T4TN8F0H5WSJKQQ0RSMW2	pvps_01K27T4TP5SFV40EMGEZVZB2BG	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:00.885+00	2025-08-18 17:51:00.885+00
variant_01K27T4TKMVYP68YJCSQ8STX6T	pset_01K27T4TN8WAKYNMGWHHGAJ9CV	pvps_01K27T4TP5MD028DM0AG2Y9VEG	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:00.885+00	2025-08-18 17:51:00.885+00
variant_01K27T4TKKACQ02YVC962NVCWF	pset_01K27T4TN7M50BGJ71Z92ZSXAN	pvps_01K27T4TP5T3X0T8NBMBDTRTGZ	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:05.017+00	2025-08-18 17:51:05.017+00
variant_01K27T4TKKT5PYD9AK7JSAK01W	pset_01K27T4TN7VT24P3E4FPDHDTE0	pvps_01K27T4TP5EKJ2VWSRV178XRWE	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:05.018+00	2025-08-18 17:51:05.017+00
variant_01K27T4TKKX36PDTMCK89FYES0	pset_01K27T4TN7HPE7K6GQRVC0KTWR	pvps_01K27T4TP5JDNAN5KNAP8KJ47Z	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:05.018+00	2025-08-18 17:51:05.017+00
variant_01K27T4TKK6B35N98YCE5JCESF	pset_01K27T4TN7R913W8WRJVW59NQ9	pvps_01K27T4TP5J1PV1Y8VFJ6RKV4J	2025-08-09 16:20:42.820271+00	2025-08-18 17:51:05.018+00	2025-08-18 17:51:05.017+00
variant_01K2Z994HTJ3FKBY0MJ89AX76T	pset_01K2Z994K1D6WVDB2QJ480RZJE	pvps_01K2Z994KJ0ACFN931RV4TYMVH	2025-08-18 19:07:44.626267+00	2025-08-18 19:07:44.626267+00	\N
variant_01K38QHGZMHE83HH5XJSRBS4PT	pset_01K38QHH1X19BZVAAAN2YAT2XN	pvps_01K38QHH3AYJA66VGDB0WA3PTW	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZMFB69P6EENPZN6JRY	pset_01K38QHH1X7DDBK9HWYC0PSQFH	pvps_01K38QHH3BTPTEANJ37W4VSTKW	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZMTC4JS70YWC0CA3PJ	pset_01K38QHH1YQHRT1P0H0QXG92GG	pvps_01K38QHH3BMDD2P0BZY8D6BBRD	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZMQEM58685MV1EGVBY	pset_01K38QHH1ZC9FQCMEVAT7EFRGZ	pvps_01K38QHH3BJW0TKK8BX9NBEWNY	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZME8GGEYNNPTSRVKEW	pset_01K38QHH1ZYV680A62WKRANRZK	pvps_01K38QHH3B8BQBSXDTHS0CBBAX	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZN4WZNMKF2B6C74XF7	pset_01K38QHH20PYP3RATDXDYC20KE	pvps_01K38QHH3BQ0WNBF92284209VC	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZNQJAGYGNKTN84RAYX	pset_01K38QHH202WGHNE42XVCEXWHH	pvps_01K38QHH3BD91J3PQNB1QRKR52	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZNTAQ158HE66CDEER3	pset_01K38QHH20XQVNJSA4128Z3A3D	pvps_01K38QHH3BHNRNMTF4GP6ANYFY	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZNM03X74761MZ9KZ46	pset_01K38QHH20KMM3HAQX46FFDCY2	pvps_01K38QHH3BVK0PZWZQ6AX0MAD9	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZN5WFSMF6Z8C8GM24N	pset_01K38QHH21V7330KX0YW32QXBD	pvps_01K38QHH3CP4JGTEVKJZBRZAGX	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZNFFP8C2YPBBQ9E32G	pset_01K38QHH21B3Y4YV20NRGDPSCM	pvps_01K38QHH3CTF2YECF9K0B0NE8Q	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZNE42MSMSA481SW63K	pset_01K38QHH21CH7VX6F0MTV605R0	pvps_01K38QHH3CWYD2CX86AA9Y7C6Y	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZNRVK9BRKC93PCYN9Z	pset_01K38QHH21CG7044V1C2DWJN2C	pvps_01K38QHH3C7R6PZ2K3YTM1AE27	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZPN2CP8XXSPFV68E83	pset_01K38QHH220TTN06TJH7P8XHWQ	pvps_01K38QHH3CVGQ44W8SKP6282JW	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZP4G5WKEXBX15KJMRX	pset_01K38QHH22DRGYRY6QMEZ0DVNC	pvps_01K38QHH3CXHPD8XV5SBS9NYQ4	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZP5YSCFBJKFHRQ2E6K	pset_01K38QHH22THZT6J8AM3R7H7Z0	pvps_01K38QHH3CDRHDSQHH44S9AZAE	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZP0RDKDX6DH33PYR7B	pset_01K38QHH22TDFFEPSS9FDZG7XM	pvps_01K38QHH3CP1A511K3K8373TWE	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZPT63J9R1DBY15V8NX	pset_01K38QHH22R842CE4C1ABS31J4	pvps_01K38QHH3CTQ05PPJB8HT56J4G	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZPGG9RPX8KH4GZ38X5	pset_01K38QHH23Y6GE6KAS3K169ZAR	pvps_01K38QHH3CEDBC9X2RMMHWXWA5	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K38QHGZP4J4N4SZ1VT4BFJ4E	pset_01K38QHH236WW1FK6X61D6SSHD	pvps_01K38QHH3CTQN0DE1DBCBX783H	2025-08-22 11:10:09.51461+00	2025-08-22 11:10:09.51461+00	\N
variant_01K3BYYSDZCVEMMPWQA50VJT55	pset_01K3BYYSH6CFS5365ZP55S4QDY	pvps_01K3BYYSKFCAQ2G955E2957YXF	2025-08-23 17:17:27.534725+00	2025-08-23 19:01:11.536+00	2025-08-23 19:01:11.534+00
variant_01K3C0EWZFCRP5TE9PWERD5J5Y	pset_01K3C0EX3A4EWVP50XFZ92D2VJ	pvps_01K3C0EX4BJS0HBR4C60V5EQ8G	2025-08-23 17:43:44.010481+00	2025-08-23 19:01:15.246+00	2025-08-23 19:01:15.246+00
variant_01K3C6E1682SFSYE7THEZ6NRBT	pset_01K3C6E18Z53C9MRXFBNHCH7AP	pvps_01K3C6E1A00WT95R9H0VDZ9M08	2025-08-23 19:28:06.976038+00	2025-08-23 19:28:06.976038+00	\N
variant_01K3C6FN6P45FT6GFE5V23DQGA	pset_01K3C6FN8E1M56K054GRP53Z10	pvps_01K3C6FN908D0QSJTMAXRJ5A1V	2025-08-23 19:29:00.192663+00	2025-08-23 19:29:00.192663+00	\N
variant_01K3C6HRCF4R1SKY06S9WS6527	pset_01K3C6HRDPM9TB53M9QG5FZM3P	pvps_01K3C6HRETCQFV5SAGRDD8GQT4	2025-08-23 19:30:08.986414+00	2025-08-23 19:30:08.986414+00	\N
variant_01K3C6MEKH3H03B43K72A30XHQ	pset_01K3C6MER2BR966QSQG71MDK6T	pvps_01K3C6MES9V8WE7T73QPB5KZSW	2025-08-23 19:31:37.384855+00	2025-08-29 19:40:15.711+00	2025-08-29 19:40:15.711+00
variant_01K3C6NJYT7SQAPSENE7B2VYSG	pset_01K3C6NK0828Z92ZTCPZF6XZTB	pvps_01K3C6NK0PWFNQ7KB532A2H964	2025-08-23 19:32:14.485981+00	2025-08-29 19:40:20.574+00	2025-08-29 19:40:20.573+00
variant_01K3C6PPGMJKA7CMY32TCTM3SV	pset_01K3C6PPJGAW3Q4C79S9A8M3WP	pvps_01K3C6PPK2C3VYAMW0F50NWAPZ	2025-08-23 19:32:50.914352+00	2025-08-29 19:40:24.484+00	2025-08-29 19:40:24.484+00
variant_01K3C6QVE2GC2ER6H2P4Q5582K	pset_01K3C6QVGS3530JVG3R8NRDYE9	pvps_01K3C6QVHCSRV6VSMCY4333EXB	2025-08-23 19:33:28.747981+00	2025-08-29 19:40:27.972+00	2025-08-29 19:40:27.971+00
variant_01K3C6S8EMB77T3DDT83DW4TJ8	pset_01K3C6S8FYNB84A5GXWQ7S3PP9	pvps_01K3C6S8GDB8G29PSJDGKWMCGK	2025-08-23 19:34:14.796872+00	2025-08-29 19:40:31.489+00	2025-08-29 19:40:31.489+00
variant_01K3C6YY9VGE99H0KQQ24K4QN4	pset_01K3C6YYBEV42QCQH0CM7T0QZA	pvps_01K3C6YYC8D1EGY43RZMYGRW6X	2025-08-23 19:37:21.031933+00	2025-08-29 19:40:35.947+00	2025-08-29 19:40:35.946+00
variant_01K3VPE6P1X6Y4ZJJK2GZJHXZA	pset_01K3VPE6QGANE2CRC9J008MFFV	pvps_01K3VPE6RBQYVSR416B2QXQKJ7	2025-08-29 19:56:26.250462+00	2025-08-29 19:56:26.250462+00	\N
variant_01K3VPE6P1JA636PJYB5C3S498	pset_01K3VPE6QG5SGDZ92A2T8SY568	pvps_01K3VPE6RBH0NC1AR5QSRZBJR9	2025-08-29 19:56:26.250462+00	2025-08-29 19:56:26.250462+00	\N
variant_01K3VPE6P185HB2AZR6CKXAWV7	pset_01K3VPE6QH1N6PA2FJPC5BQMQD	pvps_01K3VPE6RBBA6SRQ6RKYWAB2QZ	2025-08-29 19:56:26.250462+00	2025-08-29 19:56:26.250462+00	\N
variant_01K3X8E8SPW123NBF8F7W8Y1Z0	pset_01K3X8E8VR8P1QTZDW408MN3S2	pvps_01K3X8E8X03RRJ0KS2AZN76HTY	2025-08-30 10:30:17.248436+00	2025-08-30 10:30:17.248436+00	\N
variant_01K3X8E8SPY8JK4E8SYPP8VJ3P	pset_01K3X8E8VRFG2G36CSWQ9M3Q3Z	pvps_01K3X8E8X1JCQ34KWTRY70PXRP	2025-08-30 10:30:17.248436+00	2025-08-30 10:30:17.248436+00	\N
variant_01K3X8E8SPSMMBKSWNJQ4SNGH6	pset_01K3X8E8VS75WSMCETHA77RW2Y	pvps_01K3X8E8X17SM2065SYVP279AR	2025-08-30 10:30:17.248436+00	2025-08-30 10:30:17.248436+00	\N
\.


--
-- Data for Name: promotion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion (id, code, campaign_id, is_automatic, type, created_at, updated_at, deleted_at, status, is_tax_inclusive) FROM stdin;
\.


--
-- Data for Name: promotion_application_method; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion_application_method (id, value, raw_value, max_quantity, apply_to_quantity, buy_rules_min_quantity, type, target_type, allocation, promotion_id, created_at, updated_at, deleted_at, currency_code) FROM stdin;
\.


--
-- Data for Name: promotion_campaign; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion_campaign (id, name, description, campaign_identifier, starts_at, ends_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: promotion_campaign_budget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion_campaign_budget (id, type, campaign_id, "limit", raw_limit, used, raw_used, created_at, updated_at, deleted_at, currency_code) FROM stdin;
\.


--
-- Data for Name: promotion_promotion_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion_promotion_rule (promotion_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: promotion_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion_rule (id, description, attribute, operator, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: promotion_rule_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.promotion_rule_value (id, promotion_rule_id, value, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: provider_identity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provider_identity (id, entity_id, provider, auth_identity_id, user_metadata, provider_metadata, created_at, updated_at, deleted_at) FROM stdin;
01K27V4FXYER3YX2MSAQF02GF9	admin@sassyshrooms.com	emailpass	authid_01K27V4FXYQF7W5TPGGESNWANY	\N	{"password": "c2NyeXB0AA8AAAAIAAAAAffYZQeYPU7JSEIRotr0yEc49SMOFEcnlGp/sgBE49SZR0jY0uHHLy/opW5k34+DZ2NeX+aj/tOi/I0aBhNuY/Zbmw5IFmu2GptPFkNrnnvO"}	2025-08-09 16:38:00.383+00	2025-08-09 16:38:00.383+00	\N
\.


--
-- Data for Name: publishable_api_key_sales_channel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publishable_api_key_sales_channel (publishable_key_id, sales_channel_id, id, created_at, updated_at, deleted_at) FROM stdin;
apk_01K38QHGS8NSABW09ZF273XPKW	sc_01K38QHGFZCEZW38YRKKMXN51C	pksc_01K38QHGSZMEEEG8JEH460X9Y9	2025-08-22 11:10:09.214857+00	2025-08-22 11:10:09.214857+00	\N
apk_01K27T4THG6RD4XHFY01VXHWKB	sc_01K27T4TD2684AR8098EEYSPXP	pksc_01K27T4THMK7A1MWZ352SD1BWS	2025-08-09 16:20:42.676774+00	2025-09-06 16:00:25.327+00	2025-09-06 16:00:25.326+00
\.


--
-- Data for Name: refund; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refund (id, amount, raw_amount, payment_id, created_at, updated_at, deleted_at, created_by, metadata, refund_reason_id, note) FROM stdin;
\.


--
-- Data for Name: refund_reason; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refund_reason (id, label, description, metadata, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.region (id, name, currency_code, metadata, created_at, updated_at, deleted_at, automatic_taxes) FROM stdin;
reg_01K27T4TEJAKE14P075FWZVXKA	Europe	eur	\N	2025-08-09 16:20:42.583+00	2025-08-18 18:03:53.447+00	2025-08-18 18:03:53.446+00	t
reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	India	inr	\N	2025-08-18 18:05:02.046+00	2025-08-18 18:05:02.046+00	\N	t
reg_01K38QHGH1DNXQV6P26FYQKAF0	Europe	eur	\N	2025-08-22 11:10:08.935+00	2025-08-22 12:10:40.079+00	2025-08-22 12:10:40.077+00	t
\.


--
-- Data for Name: region_country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.region_country (iso_2, iso_3, num_code, name, display_name, region_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
af	afg	004	AFGHANISTAN	Afghanistan	\N	\N	2025-08-09 16:20:40.082+00	2025-08-09 16:20:40.082+00	\N
al	alb	008	ALBANIA	Albania	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
dz	dza	012	ALGERIA	Algeria	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
as	asm	016	AMERICAN SAMOA	American Samoa	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ad	and	020	ANDORRA	Andorra	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ao	ago	024	ANGOLA	Angola	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ai	aia	660	ANGUILLA	Anguilla	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
aq	ata	010	ANTARCTICA	Antarctica	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ag	atg	028	ANTIGUA AND BARBUDA	Antigua and Barbuda	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ar	arg	032	ARGENTINA	Argentina	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
am	arm	051	ARMENIA	Armenia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
aw	abw	533	ARUBA	Aruba	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
au	aus	036	AUSTRALIA	Australia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
at	aut	040	AUSTRIA	Austria	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
az	aze	031	AZERBAIJAN	Azerbaijan	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bs	bhs	044	BAHAMAS	Bahamas	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bh	bhr	048	BAHRAIN	Bahrain	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bd	bgd	050	BANGLADESH	Bangladesh	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bb	brb	052	BARBADOS	Barbados	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
by	blr	112	BELARUS	Belarus	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
be	bel	056	BELGIUM	Belgium	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bz	blz	084	BELIZE	Belize	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bj	ben	204	BENIN	Benin	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bm	bmu	060	BERMUDA	Bermuda	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bo	bol	068	BOLIVIA	Bolivia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bq	bes	535	BONAIRE, SINT EUSTATIUS AND SABA	Bonaire, Sint Eustatius and Saba	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ba	bih	070	BOSNIA AND HERZEGOVINA	Bosnia and Herzegovina	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bw	bwa	072	BOTSWANA	Botswana	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bv	bvd	074	BOUVET ISLAND	Bouvet Island	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
br	bra	076	BRAZIL	Brazil	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
io	iot	086	BRITISH INDIAN OCEAN TERRITORY	British Indian Ocean Territory	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bn	brn	096	BRUNEI DARUSSALAM	Brunei Darussalam	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bg	bgr	100	BULGARIA	Bulgaria	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bf	bfa	854	BURKINA FASO	Burkina Faso	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bi	bdi	108	BURUNDI	Burundi	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
kh	khm	116	CAMBODIA	Cambodia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cm	cmr	120	CAMEROON	Cameroon	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ca	can	124	CANADA	Canada	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cv	cpv	132	CAPE VERDE	Cape Verde	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ky	cym	136	CAYMAN ISLANDS	Cayman Islands	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cf	caf	140	CENTRAL AFRICAN REPUBLIC	Central African Republic	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
td	tcd	148	CHAD	Chad	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cl	chl	152	CHILE	Chile	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cn	chn	156	CHINA	China	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cx	cxr	162	CHRISTMAS ISLAND	Christmas Island	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cc	cck	166	COCOS (KEELING) ISLANDS	Cocos (Keeling) Islands	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
co	col	170	COLOMBIA	Colombia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
km	com	174	COMOROS	Comoros	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cg	cog	178	CONGO	Congo	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cd	cod	180	CONGO, THE DEMOCRATIC REPUBLIC OF THE	Congo, the Democratic Republic of the	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ck	cok	184	COOK ISLANDS	Cook Islands	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cr	cri	188	COSTA RICA	Costa Rica	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ci	civ	384	COTE D'IVOIRE	Cote D'Ivoire	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
hr	hrv	191	CROATIA	Croatia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cu	cub	192	CUBA	Cuba	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cw	cuw	531	CURAÇAO	Curaçao	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cy	cyp	196	CYPRUS	Cyprus	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
cz	cze	203	CZECH REPUBLIC	Czech Republic	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
dj	dji	262	DJIBOUTI	Djibouti	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
dm	dma	212	DOMINICA	Dominica	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
do	dom	214	DOMINICAN REPUBLIC	Dominican Republic	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ec	ecu	218	ECUADOR	Ecuador	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
eg	egy	818	EGYPT	Egypt	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
sv	slv	222	EL SALVADOR	El Salvador	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gq	gnq	226	EQUATORIAL GUINEA	Equatorial Guinea	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
er	eri	232	ERITREA	Eritrea	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ee	est	233	ESTONIA	Estonia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
et	eth	231	ETHIOPIA	Ethiopia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
fk	flk	238	FALKLAND ISLANDS (MALVINAS)	Falkland Islands (Malvinas)	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
fo	fro	234	FAROE ISLANDS	Faroe Islands	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
fj	fji	242	FIJI	Fiji	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
fi	fin	246	FINLAND	Finland	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gf	guf	254	FRENCH GUIANA	French Guiana	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
pf	pyf	258	FRENCH POLYNESIA	French Polynesia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
tf	atf	260	FRENCH SOUTHERN TERRITORIES	French Southern Territories	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ga	gab	266	GABON	Gabon	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gm	gmb	270	GAMBIA	Gambia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
ge	geo	268	GEORGIA	Georgia	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gh	gha	288	GHANA	Ghana	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gi	gib	292	GIBRALTAR	Gibraltar	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gr	grc	300	GREECE	Greece	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gl	grl	304	GREENLAND	Greenland	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gd	grd	308	GRENADA	Grenada	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gp	glp	312	GUADELOUPE	Guadeloupe	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gu	gum	316	GUAM	Guam	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gt	gtm	320	GUATEMALA	Guatemala	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
gg	ggy	831	GUERNSEY	Guernsey	\N	\N	2025-08-09 16:20:40.083+00	2025-08-09 16:20:40.083+00	\N
bt	btn	064	BHUTAN	Bhutan	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	\N	2025-08-09 16:20:40.083+00	2025-08-18 18:05:02.046+00	\N
gn	gin	324	GUINEA	Guinea	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
gw	gnb	624	GUINEA-BISSAU	Guinea-Bissau	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
gy	guy	328	GUYANA	Guyana	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ht	hti	332	HAITI	Haiti	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
hm	hmd	334	HEARD ISLAND AND MCDONALD ISLANDS	Heard Island And Mcdonald Islands	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
va	vat	336	HOLY SEE (VATICAN CITY STATE)	Holy See (Vatican City State)	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
hn	hnd	340	HONDURAS	Honduras	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
hk	hkg	344	HONG KONG	Hong Kong	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
hu	hun	348	HUNGARY	Hungary	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
is	isl	352	ICELAND	Iceland	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
id	idn	360	INDONESIA	Indonesia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ir	irn	364	IRAN, ISLAMIC REPUBLIC OF	Iran, Islamic Republic of	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
iq	irq	368	IRAQ	Iraq	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ie	irl	372	IRELAND	Ireland	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
im	imn	833	ISLE OF MAN	Isle Of Man	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
il	isr	376	ISRAEL	Israel	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
jm	jam	388	JAMAICA	Jamaica	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
jp	jpn	392	JAPAN	Japan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
je	jey	832	JERSEY	Jersey	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
jo	jor	400	JORDAN	Jordan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
kz	kaz	398	KAZAKHSTAN	Kazakhstan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ke	ken	404	KENYA	Kenya	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ki	kir	296	KIRIBATI	Kiribati	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
kp	prk	408	KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF	Korea, Democratic People's Republic of	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
kr	kor	410	KOREA, REPUBLIC OF	Korea, Republic of	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
xk	xkx	900	KOSOVO	Kosovo	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
kw	kwt	414	KUWAIT	Kuwait	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
kg	kgz	417	KYRGYZSTAN	Kyrgyzstan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
la	lao	418	LAO PEOPLE'S DEMOCRATIC REPUBLIC	Lao People's Democratic Republic	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
lv	lva	428	LATVIA	Latvia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
lb	lbn	422	LEBANON	Lebanon	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ls	lso	426	LESOTHO	Lesotho	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
lr	lbr	430	LIBERIA	Liberia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ly	lby	434	LIBYA	Libya	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
li	lie	438	LIECHTENSTEIN	Liechtenstein	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
lt	ltu	440	LITHUANIA	Lithuania	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
lu	lux	442	LUXEMBOURG	Luxembourg	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mo	mac	446	MACAO	Macao	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mg	mdg	450	MADAGASCAR	Madagascar	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mw	mwi	454	MALAWI	Malawi	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
my	mys	458	MALAYSIA	Malaysia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mv	mdv	462	MALDIVES	Maldives	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ml	mli	466	MALI	Mali	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mt	mlt	470	MALTA	Malta	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mh	mhl	584	MARSHALL ISLANDS	Marshall Islands	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mq	mtq	474	MARTINIQUE	Martinique	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mr	mrt	478	MAURITANIA	Mauritania	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mu	mus	480	MAURITIUS	Mauritius	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
yt	myt	175	MAYOTTE	Mayotte	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mx	mex	484	MEXICO	Mexico	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
fm	fsm	583	MICRONESIA, FEDERATED STATES OF	Micronesia, Federated States of	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
md	mda	498	MOLDOVA, REPUBLIC OF	Moldova, Republic of	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mc	mco	492	MONACO	Monaco	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mn	mng	496	MONGOLIA	Mongolia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
me	mne	499	MONTENEGRO	Montenegro	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ms	msr	500	MONTSERRAT	Montserrat	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ma	mar	504	MOROCCO	Morocco	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mz	moz	508	MOZAMBIQUE	Mozambique	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mm	mmr	104	MYANMAR	Myanmar	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
na	nam	516	NAMIBIA	Namibia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
nr	nru	520	NAURU	Nauru	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
nl	nld	528	NETHERLANDS	Netherlands	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
nc	ncl	540	NEW CALEDONIA	New Caledonia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
nz	nzl	554	NEW ZEALAND	New Zealand	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ni	nic	558	NICARAGUA	Nicaragua	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ne	ner	562	NIGER	Niger	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ng	nga	566	NIGERIA	Nigeria	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
nu	niu	570	NIUE	Niue	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
nf	nfk	574	NORFOLK ISLAND	Norfolk Island	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mk	mkd	807	NORTH MACEDONIA	North Macedonia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mp	mnp	580	NORTHERN MARIANA ISLANDS	Northern Mariana Islands	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
no	nor	578	NORWAY	Norway	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
om	omn	512	OMAN	Oman	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pk	pak	586	PAKISTAN	Pakistan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pw	plw	585	PALAU	Palau	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ps	pse	275	PALESTINIAN TERRITORY, OCCUPIED	Palestinian Territory, Occupied	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pa	pan	591	PANAMA	Panama	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pg	png	598	PAPUA NEW GUINEA	Papua New Guinea	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
py	pry	600	PARAGUAY	Paraguay	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pe	per	604	PERU	Peru	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ph	phl	608	PHILIPPINES	Philippines	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pn	pcn	612	PITCAIRN	Pitcairn	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pl	pol	616	POLAND	Poland	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pt	prt	620	PORTUGAL	Portugal	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pr	pri	630	PUERTO RICO	Puerto Rico	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
qa	qat	634	QATAR	Qatar	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
re	reu	638	REUNION	Reunion	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ro	rom	642	ROMANIA	Romania	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ru	rus	643	RUSSIAN FEDERATION	Russian Federation	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
rw	rwa	646	RWANDA	Rwanda	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
bl	blm	652	SAINT BARTHÉLEMY	Saint Barthélemy	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sh	shn	654	SAINT HELENA	Saint Helena	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
kn	kna	659	SAINT KITTS AND NEVIS	Saint Kitts and Nevis	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
lc	lca	662	SAINT LUCIA	Saint Lucia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
mf	maf	663	SAINT MARTIN (FRENCH PART)	Saint Martin (French part)	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
pm	spm	666	SAINT PIERRE AND MIQUELON	Saint Pierre and Miquelon	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
vc	vct	670	SAINT VINCENT AND THE GRENADINES	Saint Vincent and the Grenadines	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ws	wsm	882	SAMOA	Samoa	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sm	smr	674	SAN MARINO	San Marino	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
st	stp	678	SAO TOME AND PRINCIPE	Sao Tome and Principe	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sa	sau	682	SAUDI ARABIA	Saudi Arabia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sn	sen	686	SENEGAL	Senegal	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
rs	srb	688	SERBIA	Serbia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sc	syc	690	SEYCHELLES	Seychelles	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sl	sle	694	SIERRA LEONE	Sierra Leone	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sg	sgp	702	SINGAPORE	Singapore	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sx	sxm	534	SINT MAARTEN	Sint Maarten	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sk	svk	703	SLOVAKIA	Slovakia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
si	svn	705	SLOVENIA	Slovenia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sb	slb	090	SOLOMON ISLANDS	Solomon Islands	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
so	som	706	SOMALIA	Somalia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
za	zaf	710	SOUTH AFRICA	South Africa	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
gs	sgs	239	SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS	South Georgia and the South Sandwich Islands	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ss	ssd	728	SOUTH SUDAN	South Sudan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sd	sdn	729	SUDAN	Sudan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sr	sur	740	SURINAME	Suriname	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sj	sjm	744	SVALBARD AND JAN MAYEN	Svalbard and Jan Mayen	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sz	swz	748	SWAZILAND	Swaziland	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
ch	che	756	SWITZERLAND	Switzerland	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
sy	syr	760	SYRIAN ARAB REPUBLIC	Syrian Arab Republic	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tw	twn	158	TAIWAN, PROVINCE OF CHINA	Taiwan, Province of China	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tj	tjk	762	TAJIKISTAN	Tajikistan	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tz	tza	834	TANZANIA, UNITED REPUBLIC OF	Tanzania, United Republic of	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
th	tha	764	THAILAND	Thailand	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tl	tls	626	TIMOR LESTE	Timor Leste	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tg	tgo	768	TOGO	Togo	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tk	tkl	772	TOKELAU	Tokelau	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
to	ton	776	TONGA	Tonga	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tt	tto	780	TRINIDAD AND TOBAGO	Trinidad and Tobago	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.084+00	\N
tn	tun	788	TUNISIA	Tunisia	\N	\N	2025-08-09 16:20:40.084+00	2025-08-09 16:20:40.085+00	\N
tr	tur	792	TURKEY	Turkey	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
tm	tkm	795	TURKMENISTAN	Turkmenistan	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
tc	tca	796	TURKS AND CAICOS ISLANDS	Turks and Caicos Islands	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
tv	tuv	798	TUVALU	Tuvalu	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
ug	uga	800	UGANDA	Uganda	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
ua	ukr	804	UKRAINE	Ukraine	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
ae	are	784	UNITED ARAB EMIRATES	United Arab Emirates	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
us	usa	840	UNITED STATES	United States	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
um	umi	581	UNITED STATES MINOR OUTLYING ISLANDS	United States Minor Outlying Islands	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
uy	ury	858	URUGUAY	Uruguay	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
uz	uzb	860	UZBEKISTAN	Uzbekistan	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
vu	vut	548	VANUATU	Vanuatu	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
ve	ven	862	VENEZUELA	Venezuela	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
vn	vnm	704	VIET NAM	Viet Nam	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
vg	vgb	092	VIRGIN ISLANDS, BRITISH	Virgin Islands, British	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
vi	vir	850	VIRGIN ISLANDS, U.S.	Virgin Islands, U.S.	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
wf	wlf	876	WALLIS AND FUTUNA	Wallis and Futuna	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
eh	esh	732	WESTERN SAHARA	Western Sahara	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
ye	yem	887	YEMEN	Yemen	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
zm	zmb	894	ZAMBIA	Zambia	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
zw	zwe	716	ZIMBABWE	Zimbabwe	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
ax	ala	248	ÅLAND ISLANDS	Åland Islands	\N	\N	2025-08-09 16:20:40.085+00	2025-08-09 16:20:40.085+00	\N
lk	lka	144	SRI LANKA	Sri Lanka	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	\N	2025-08-09 16:20:40.084+00	2025-08-18 18:05:02.046+00	\N
dk	dnk	208	DENMARK	Denmark	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.083+00	2025-08-22 11:10:08.935+00	\N
fr	fra	250	FRANCE	France	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.083+00	2025-08-22 11:10:08.935+00	\N
de	deu	276	GERMANY	Germany	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.083+00	2025-08-22 11:10:08.935+00	\N
it	ita	380	ITALY	Italy	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.084+00	2025-08-22 11:10:08.935+00	\N
es	esp	724	SPAIN	Spain	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.084+00	2025-08-22 11:10:08.935+00	\N
np	npl	524	NEPAL	Nepal	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	\N	2025-08-09 16:20:40.084+00	2025-08-18 18:05:02.046+00	\N
in	ind	356	INDIA	India	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	\N	2025-08-09 16:20:40.084+00	2025-08-18 18:05:02.046+00	\N
se	swe	752	SWEDEN	Sweden	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.084+00	2025-08-22 11:10:08.935+00	\N
gb	gbr	826	UNITED KINGDOM	United Kingdom	reg_01K38QHGH1DNXQV6P26FYQKAF0	\N	2025-08-09 16:20:40.085+00	2025-08-22 11:10:08.935+00	\N
\.


--
-- Data for Name: region_payment_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.region_payment_provider (region_id, payment_provider_id, id, created_at, updated_at, deleted_at) FROM stdin;
reg_01K27T4TEJAKE14P075FWZVXKA	pp_system_default	regpp_01K27T4TF28ZM4Q2SDYYTS2JWE	2025-08-09 16:20:42.594645+00	2025-08-18 18:03:53.471+00	2025-08-18 18:03:53.47+00
reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	pp_system_default	regpp_01K2Z5PA7T5FQC43G8ACCC7JGP	2025-08-18 18:05:02.073887+00	2025-08-18 18:05:02.073887+00	\N
reg_01K38QHGH1DNXQV6P26FYQKAF0	pp_system_default	regpp_01K38QHGHNQK1WW0MENSSHBAPD	2025-08-22 11:10:08.949329+00	2025-08-22 12:10:40.106+00	2025-08-22 12:10:40.104+00
\.


--
-- Data for Name: reservation_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservation_item (id, created_at, updated_at, deleted_at, line_item_id, location_id, quantity, external_id, description, created_by, metadata, inventory_item_id, allow_backorder, raw_quantity) FROM stdin;
\.


--
-- Data for Name: return; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return (id, order_id, claim_id, exchange_id, order_version, display_id, status, no_notification, refund_amount, raw_refund_amount, metadata, created_at, updated_at, deleted_at, received_at, canceled_at, location_id, requested_at, created_by) FROM stdin;
\.


--
-- Data for Name: return_fulfillment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return_fulfillment (return_id, fulfillment_id, id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: return_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return_item (id, return_id, reason_id, item_id, quantity, raw_quantity, received_quantity, raw_received_quantity, note, metadata, created_at, updated_at, deleted_at, damaged_quantity, raw_damaged_quantity) FROM stdin;
\.


--
-- Data for Name: return_reason; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return_reason (id, value, label, description, metadata, parent_return_reason_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: sales_channel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_channel (id, name, description, is_disabled, metadata, created_at, updated_at, deleted_at) FROM stdin;
sc_01K27T4TD2684AR8098EEYSPXP	Website	This is the sales channel for website	f	\N	2025-08-09 16:20:42.53+00	2025-08-18 18:24:05.623+00	\N
sc_01K38QHGFZCEZW38YRKKMXN51C	Default Sales Channel	\N	f	\N	2025-08-22 11:10:08.895+00	2025-08-22 11:10:08.895+00	\N
\.


--
-- Data for Name: sales_channel_stock_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_channel_stock_location (sales_channel_id, stock_location_id, id, created_at, updated_at, deleted_at) FROM stdin;
sc_01K27T4TD2684AR8098EEYSPXP	sloc_01K27T4TFFAZ3896MP60BEWGD6	scloc_01K27T4THBDZD7R9MXNVX14JJZ	2025-08-09 16:20:42.667632+00	2025-08-18 18:01:28.182+00	2025-08-18 18:01:28.181+00
sc_01K38QHGFZCEZW38YRKKMXN51C	sloc_01K38QHGJF0Z7BZ1CV0JN6PFP4	scloc_01K38QHGQMWJCVGCS2FPATE0N2	2025-08-22 11:10:09.139808+00	2025-08-22 12:10:55.494+00	2025-08-22 12:10:55.493+00
\.


--
-- Data for Name: script_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.script_migrations (id, script_name, created_at, finished_at) FROM stdin;
1	migrate-product-shipping-profile.js	2025-08-09 16:20:40.631821+00	2025-08-09 16:20:40.651931+00
2	migrate-tax-region-provider.js	2025-08-09 16:20:40.653824+00	2025-08-09 16:20:40.665837+00
\.


--
-- Data for Name: service_zone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_zone (id, name, metadata, fulfillment_set_id, created_at, updated_at, deleted_at) FROM stdin;
serzo_01K27T4TFS4VTJM1V91DDWGBYZ	Europe	\N	fuset_01K27T4TFSTKJT6YXD3JEHNA4R	2025-08-09 16:20:42.617+00	2025-08-18 18:01:28.193+00	2025-08-18 18:01:28.187+00
serzo_01K38QHGK5FE3HZZA64GQXRHMS	Europe	\N	fuset_01K38QHGK537HYCDV6VQY2A2KX	2025-08-22 11:10:08.998+00	2025-08-22 12:10:55.505+00	2025-08-22 12:10:55.499+00
\.


--
-- Data for Name: shipping_option; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_option (id, name, price_type, service_zone_id, shipping_profile_id, provider_id, data, metadata, shipping_option_type_id, created_at, updated_at, deleted_at) FROM stdin;
so_01K27T4TGGZGCBWWTQAZRPVXEW	Standard Shipping	flat	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	manual_manual	\N	\N	sotype_01K27T4TGFAWDE0F4YHJBHKAZA	2025-08-09 16:20:42.64+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
so_01K27T4TGG38T95ESER8GV87NT	Express Shipping	flat	serzo_01K27T4TFS4VTJM1V91DDWGBYZ	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	manual_manual	\N	\N	sotype_01K27T4TGG41T3DS42GPQRWMV6	2025-08-09 16:20:42.641+00	2025-08-18 18:01:28.206+00	2025-08-18 18:01:28.187+00
so_01K38QHGM9TEB8KG7VCV07NVWK	Standard Shipping	flat	serzo_01K38QHGK5FE3HZZA64GQXRHMS	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	manual_manual	\N	\N	sotype_01K38QHGM822D4VX9JN12YKYJN	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.521+00	2025-08-22 12:10:55.499+00
so_01K38QHGM9KSWE02180A8Y68DG	Express Shipping	flat	serzo_01K38QHGK5FE3HZZA64GQXRHMS	sp_01K27T4RJ7QDGM6D2NE1BKRS1F	manual_manual	\N	\N	sotype_01K38QHGM9R6EFMWZHKYC4VNZP	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.521+00	2025-08-22 12:10:55.499+00
\.


--
-- Data for Name: shipping_option_price_set; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_option_price_set (shipping_option_id, price_set_id, id, created_at, updated_at, deleted_at) FROM stdin;
so_01K27T4TGGZGCBWWTQAZRPVXEW	pset_01K27T4TGT2CRRZ18PXB1NQN6E	sops_01K27T4TH7RWADFR6W9WA66WR4	2025-08-09 16:20:42.663499+00	2025-08-18 18:01:28.24+00	2025-08-18 18:01:28.239+00
so_01K27T4TGG38T95ESER8GV87NT	pset_01K27T4TGTDQEJESPY8BSR349W	sops_01K27T4TH74BCZ4Z4GDX1PKQ5F	2025-08-09 16:20:42.663499+00	2025-08-18 18:01:28.24+00	2025-08-18 18:01:28.239+00
so_01K38QHGM9TEB8KG7VCV07NVWK	pset_01K38QHGMVSTEV8NMMTH4MJ9MX	sops_01K38QHGP63XN3G0GWVHK2BSET	2025-08-22 11:10:09.090659+00	2025-08-22 12:10:55.549+00	2025-08-22 12:10:55.548+00
so_01K38QHGM9KSWE02180A8Y68DG	pset_01K38QHGMVS7GZ3JXN14HQJRMD	sops_01K38QHGPM4ZKEZYB4CWP6QER5	2025-08-22 11:10:09.090659+00	2025-08-22 12:10:55.549+00	2025-08-22 12:10:55.548+00
\.


--
-- Data for Name: shipping_option_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_option_rule (id, attribute, operator, value, shipping_option_id, created_at, updated_at, deleted_at) FROM stdin;
sorul_01K27T4TGG1J1TFEEWF6T3BZZ6	enabled_in_store	eq	"true"	so_01K27T4TGGZGCBWWTQAZRPVXEW	2025-08-09 16:20:42.641+00	2025-08-18 18:01:28.227+00	2025-08-18 18:01:28.187+00
sorul_01K27T4TGGM2YM86BAGZ0JFBD4	is_return	eq	"false"	so_01K27T4TGGZGCBWWTQAZRPVXEW	2025-08-09 16:20:42.641+00	2025-08-18 18:01:28.227+00	2025-08-18 18:01:28.187+00
sorul_01K27T4TGGJMF5HS5AH9E97E9X	enabled_in_store	eq	"true"	so_01K27T4TGG38T95ESER8GV87NT	2025-08-09 16:20:42.641+00	2025-08-18 18:01:28.227+00	2025-08-18 18:01:28.187+00
sorul_01K27T4TGG9N7QCQZSHGV7QHS0	is_return	eq	"false"	so_01K27T4TGG38T95ESER8GV87NT	2025-08-09 16:20:42.641+00	2025-08-18 18:01:28.227+00	2025-08-18 18:01:28.187+00
sorul_01K38QHGM9JD45CNX15HCZWQCD	enabled_in_store	eq	"true"	so_01K38QHGM9TEB8KG7VCV07NVWK	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.539+00	2025-08-22 12:10:55.499+00
sorul_01K38QHGM9G159TKF0P2VWMYPV	is_return	eq	"false"	so_01K38QHGM9TEB8KG7VCV07NVWK	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.539+00	2025-08-22 12:10:55.499+00
sorul_01K38QHGM9SX06VQCA7A60HMZ6	enabled_in_store	eq	"true"	so_01K38QHGM9KSWE02180A8Y68DG	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.538+00	2025-08-22 12:10:55.499+00
sorul_01K38QHGM9JZ3M1QBN2YZYXYWH	is_return	eq	"false"	so_01K38QHGM9KSWE02180A8Y68DG	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.538+00	2025-08-22 12:10:55.499+00
\.


--
-- Data for Name: shipping_option_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_option_type (id, label, description, code, created_at, updated_at, deleted_at) FROM stdin;
sotype_01K27T4TGFAWDE0F4YHJBHKAZA	Standard	Ship in 2-3 days.	standard	2025-08-09 16:20:42.64+00	2025-08-18 18:01:28.227+00	2025-08-18 18:01:28.187+00
sotype_01K27T4TGG41T3DS42GPQRWMV6	Express	Ship in 24 hours.	express	2025-08-09 16:20:42.641+00	2025-08-18 18:01:28.227+00	2025-08-18 18:01:28.187+00
sotype_01K38QHGM822D4VX9JN12YKYJN	Standard	Ship in 2-3 days.	standard	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.539+00	2025-08-22 12:10:55.499+00
sotype_01K38QHGM9R6EFMWZHKYC4VNZP	Express	Ship in 24 hours.	express	2025-08-22 11:10:09.034+00	2025-08-22 12:10:55.538+00	2025-08-22 12:10:55.499+00
\.


--
-- Data for Name: shipping_profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_profile (id, name, type, metadata, created_at, updated_at, deleted_at) FROM stdin;
sp_01K27T4RJ7QDGM6D2NE1BKRS1F	Default Shipping Profile	default	\N	2025-08-09 16:20:40.648+00	2025-08-09 16:20:40.648+00	\N
\.


--
-- Data for Name: stock_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_location (id, created_at, updated_at, deleted_at, name, address_id, metadata) FROM stdin;
sloc_01K27T4TFFAZ3896MP60BEWGD6	2025-08-09 16:20:42.608+00	2025-08-18 18:01:28.156+00	2025-08-18 18:01:28.154+00	European Warehouse	laddr_01K27T4TFFQZWJP6E7QAE7EFFV	\N
sloc_01K2Z63NV7KDFXY5A243XN4Q4N	2025-08-18 18:12:19.947+00	2025-08-18 18:12:19.947+00	\N	Head Office	laddr_01K2Z63NV61GZVB5V1TWGHQWG8	\N
sloc_01K38QHGJF0Z7BZ1CV0JN6PFP4	2025-08-22 11:10:08.976+00	2025-08-22 12:10:55.473+00	2025-08-22 12:10:55.47+00	European Warehouse	laddr_01K38QHGJFS9J91934FNJQRDSW	\N
\.


--
-- Data for Name: stock_location_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_location_address (id, created_at, updated_at, deleted_at, address_1, address_2, company, city, country_code, phone, province, postal_code, metadata) FROM stdin;
laddr_01K27T4TFFQZWJP6E7QAE7EFFV	2025-08-09 16:20:42.607+00	2025-08-18 18:01:28.166+00	2025-08-18 18:01:28.154+00		\N	\N	Copenhagen	DK	\N	\N	\N	\N
laddr_01K2Z63NV61GZVB5V1TWGHQWG8	2025-08-18 18:12:19.945+00	2025-08-18 18:12:19.945+00	\N	S3, C-253	Friday market road	Sassy Shrooms	New Delhi	in	9873395231	Delhi	110042	\N
laddr_01K38QHGJFS9J91934FNJQRDSW	2025-08-22 11:10:08.975+00	2025-08-22 12:10:55.479+00	2025-08-22 12:10:55.47+00		\N	\N	Copenhagen	DK	\N	\N	\N	\N
\.


--
-- Data for Name: store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store (id, name, default_sales_channel_id, default_region_id, default_location_id, metadata, created_at, updated_at, deleted_at) FROM stdin;
store_01K27T4TDDSEP8ARVQWJG92QF4	Medusa Store	sc_01K38QHGFZCEZW38YRKKMXN51C	reg_01K2Z5PA6DYDDH0DM3ZY7BEVJT	sloc_01K2Z63NV7KDFXY5A243XN4Q4N	\N	2025-08-09 16:20:42.540734+00	2025-08-09 16:20:42.540734+00	\N
\.


--
-- Data for Name: store_currency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_currency (id, currency_code, is_default, store_id, created_at, updated_at, deleted_at) FROM stdin;
stocur_01K38V2CZ7F5E3HPYJ43JN1XRV	inr	t	store_01K27T4TDDSEP8ARVQWJG92QF4	2025-08-22 12:11:48.067303+00	2025-08-22 12:11:48.067303+00	\N
\.


--
-- Data for Name: tax_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_provider (id, is_enabled, created_at, updated_at, deleted_at) FROM stdin;
tp_system	t	2025-08-09 16:20:40.112+00	2025-08-09 16:20:40.112+00	\N
\.


--
-- Data for Name: tax_rate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_rate (id, rate, code, name, is_default, is_combinable, tax_region_id, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
txr_01K38VBQB9H7QFS00MJ8B2S033	9	CGST	CGST	t	f	txreg_01K38VBQADEFMGK2T3PMHMH7B5	\N	2025-08-22 12:16:53.61+00	2025-08-22 12:16:53.61+00	user_01K27V4FV6AXTXHH3DB727SCX7	\N
\.


--
-- Data for Name: tax_rate_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_rate_rule (id, tax_rate_id, reference_id, reference, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
\.


--
-- Data for Name: tax_region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_region (id, provider_id, country_code, province_code, parent_id, metadata, created_at, updated_at, created_by, deleted_at) FROM stdin;
txreg_01K38VBQADEFMGK2T3PMHMH7B5	tp_system	in	\N	\N	\N	2025-08-22 12:16:53.584+00	2025-08-22 12:16:53.584+00	user_01K27V4FV6AXTXHH3DB727SCX7	\N
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, first_name, last_name, email, avatar_url, metadata, created_at, updated_at, deleted_at) FROM stdin;
user_01K27V4FV6AXTXHH3DB727SCX7	Praveen	Chaurasia	admin@sassyshrooms.com	\N	\N	2025-08-09 16:38:00.294+00	2025-08-18 18:26:08.817+00	\N
\.


--
-- Data for Name: workflow_execution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_execution (id, workflow_id, transaction_id, execution, context, state, created_at, updated_at, deleted_at, retention_time, run_id) FROM stdin;
\.


--
-- Name: link_module_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.link_module_migrations_id_seq', 126, true);


--
-- Name: mikro_orm_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mikro_orm_migrations_id_seq', 113, true);


--
-- Name: order_change_action_ordering_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_change_action_ordering_seq', 1, false);


--
-- Name: order_claim_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_claim_display_id_seq', 1, false);


--
-- Name: order_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_display_id_seq', 1, false);


--
-- Name: order_exchange_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_exchange_display_id_seq', 1, false);


--
-- Name: return_display_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.return_display_id_seq', 1, false);


--
-- Name: script_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.script_migrations_id_seq', 2, true);


--
-- Name: account_holder account_holder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_holder
    ADD CONSTRAINT account_holder_pkey PRIMARY KEY (id);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: application_method_buy_rules application_method_buy_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_method_buy_rules
    ADD CONSTRAINT application_method_buy_rules_pkey PRIMARY KEY (application_method_id, promotion_rule_id);


--
-- Name: application_method_target_rules application_method_target_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_method_target_rules
    ADD CONSTRAINT application_method_target_rules_pkey PRIMARY KEY (application_method_id, promotion_rule_id);


--
-- Name: auth_identity auth_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_identity
    ADD CONSTRAINT auth_identity_pkey PRIMARY KEY (id);


--
-- Name: capture capture_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.capture
    ADD CONSTRAINT capture_pkey PRIMARY KEY (id);


--
-- Name: cart_address cart_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_address
    ADD CONSTRAINT cart_address_pkey PRIMARY KEY (id);


--
-- Name: cart_line_item_adjustment cart_line_item_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_line_item_adjustment
    ADD CONSTRAINT cart_line_item_adjustment_pkey PRIMARY KEY (id);


--
-- Name: cart_line_item cart_line_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_line_item
    ADD CONSTRAINT cart_line_item_pkey PRIMARY KEY (id);


--
-- Name: cart_line_item_tax_line cart_line_item_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_line_item_tax_line
    ADD CONSTRAINT cart_line_item_tax_line_pkey PRIMARY KEY (id);


--
-- Name: cart_payment_collection cart_payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_payment_collection
    ADD CONSTRAINT cart_payment_collection_pkey PRIMARY KEY (cart_id, payment_collection_id);


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- Name: cart_promotion cart_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_promotion
    ADD CONSTRAINT cart_promotion_pkey PRIMARY KEY (cart_id, promotion_id);


--
-- Name: cart_shipping_method_adjustment cart_shipping_method_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_shipping_method_adjustment
    ADD CONSTRAINT cart_shipping_method_adjustment_pkey PRIMARY KEY (id);


--
-- Name: cart_shipping_method cart_shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_shipping_method
    ADD CONSTRAINT cart_shipping_method_pkey PRIMARY KEY (id);


--
-- Name: cart_shipping_method_tax_line cart_shipping_method_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_shipping_method_tax_line
    ADD CONSTRAINT cart_shipping_method_tax_line_pkey PRIMARY KEY (id);


--
-- Name: credit_line credit_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_line
    ADD CONSTRAINT credit_line_pkey PRIMARY KEY (id);


--
-- Name: currency currency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.currency
    ADD CONSTRAINT currency_pkey PRIMARY KEY (code);


--
-- Name: customer_account_holder customer_account_holder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_account_holder
    ADD CONSTRAINT customer_account_holder_pkey PRIMARY KEY (customer_id, account_holder_id);


--
-- Name: customer_address customer_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_address
    ADD CONSTRAINT customer_address_pkey PRIMARY KEY (id);


--
-- Name: customer_group_customer customer_group_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_group_customer
    ADD CONSTRAINT customer_group_customer_pkey PRIMARY KEY (id);


--
-- Name: customer_group customer_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_group
    ADD CONSTRAINT customer_group_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_address fulfillment_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_address
    ADD CONSTRAINT fulfillment_address_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_item fulfillment_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_item
    ADD CONSTRAINT fulfillment_item_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_label fulfillment_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_label
    ADD CONSTRAINT fulfillment_label_pkey PRIMARY KEY (id);


--
-- Name: fulfillment fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_provider fulfillment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_provider
    ADD CONSTRAINT fulfillment_provider_pkey PRIMARY KEY (id);


--
-- Name: fulfillment_set fulfillment_set_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_set
    ADD CONSTRAINT fulfillment_set_pkey PRIMARY KEY (id);


--
-- Name: geo_zone geo_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_zone
    ADD CONSTRAINT geo_zone_pkey PRIMARY KEY (id);


--
-- Name: image image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_pkey PRIMARY KEY (id);


--
-- Name: inventory_item inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_item
    ADD CONSTRAINT inventory_item_pkey PRIMARY KEY (id);


--
-- Name: inventory_level inventory_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_level
    ADD CONSTRAINT inventory_level_pkey PRIMARY KEY (id);


--
-- Name: invite invite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invite
    ADD CONSTRAINT invite_pkey PRIMARY KEY (id);


--
-- Name: link_module_migrations link_module_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.link_module_migrations
    ADD CONSTRAINT link_module_migrations_pkey PRIMARY KEY (id);


--
-- Name: link_module_migrations link_module_migrations_table_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.link_module_migrations
    ADD CONSTRAINT link_module_migrations_table_name_key UNIQUE (table_name);


--
-- Name: location_fulfillment_provider location_fulfillment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_fulfillment_provider
    ADD CONSTRAINT location_fulfillment_provider_pkey PRIMARY KEY (stock_location_id, fulfillment_provider_id);


--
-- Name: location_fulfillment_set location_fulfillment_set_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_fulfillment_set
    ADD CONSTRAINT location_fulfillment_set_pkey PRIMARY KEY (stock_location_id, fulfillment_set_id);


--
-- Name: mikro_orm_migrations mikro_orm_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mikro_orm_migrations
    ADD CONSTRAINT mikro_orm_migrations_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_provider notification_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_provider
    ADD CONSTRAINT notification_provider_pkey PRIMARY KEY (id);


--
-- Name: order_address order_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_address
    ADD CONSTRAINT order_address_pkey PRIMARY KEY (id);


--
-- Name: order_cart order_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_cart
    ADD CONSTRAINT order_cart_pkey PRIMARY KEY (order_id, cart_id);


--
-- Name: order_change_action order_change_action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_change_action
    ADD CONSTRAINT order_change_action_pkey PRIMARY KEY (id);


--
-- Name: order_change order_change_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_change
    ADD CONSTRAINT order_change_pkey PRIMARY KEY (id);


--
-- Name: order_claim_item_image order_claim_item_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_claim_item_image
    ADD CONSTRAINT order_claim_item_image_pkey PRIMARY KEY (id);


--
-- Name: order_claim_item order_claim_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_claim_item
    ADD CONSTRAINT order_claim_item_pkey PRIMARY KEY (id);


--
-- Name: order_claim order_claim_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_claim
    ADD CONSTRAINT order_claim_pkey PRIMARY KEY (id);


--
-- Name: order_credit_line order_credit_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_credit_line
    ADD CONSTRAINT order_credit_line_pkey PRIMARY KEY (id);


--
-- Name: order_exchange_item order_exchange_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_exchange_item
    ADD CONSTRAINT order_exchange_item_pkey PRIMARY KEY (id);


--
-- Name: order_exchange order_exchange_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_exchange
    ADD CONSTRAINT order_exchange_pkey PRIMARY KEY (id);


--
-- Name: order_fulfillment order_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_fulfillment
    ADD CONSTRAINT order_fulfillment_pkey PRIMARY KEY (order_id, fulfillment_id);


--
-- Name: order_item order_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_pkey PRIMARY KEY (id);


--
-- Name: order_line_item_adjustment order_line_item_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line_item_adjustment
    ADD CONSTRAINT order_line_item_adjustment_pkey PRIMARY KEY (id);


--
-- Name: order_line_item order_line_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line_item
    ADD CONSTRAINT order_line_item_pkey PRIMARY KEY (id);


--
-- Name: order_line_item_tax_line order_line_item_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line_item_tax_line
    ADD CONSTRAINT order_line_item_tax_line_pkey PRIMARY KEY (id);


--
-- Name: order_payment_collection order_payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_payment_collection
    ADD CONSTRAINT order_payment_collection_pkey PRIMARY KEY (order_id, payment_collection_id);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (id);


--
-- Name: order_promotion order_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_promotion
    ADD CONSTRAINT order_promotion_pkey PRIMARY KEY (order_id, promotion_id);


--
-- Name: order_shipping_method_adjustment order_shipping_method_adjustment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping_method_adjustment
    ADD CONSTRAINT order_shipping_method_adjustment_pkey PRIMARY KEY (id);


--
-- Name: order_shipping_method order_shipping_method_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping_method
    ADD CONSTRAINT order_shipping_method_pkey PRIMARY KEY (id);


--
-- Name: order_shipping_method_tax_line order_shipping_method_tax_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping_method_tax_line
    ADD CONSTRAINT order_shipping_method_tax_line_pkey PRIMARY KEY (id);


--
-- Name: order_shipping order_shipping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping
    ADD CONSTRAINT order_shipping_pkey PRIMARY KEY (id);


--
-- Name: order_summary order_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_summary
    ADD CONSTRAINT order_summary_pkey PRIMARY KEY (id);


--
-- Name: order_transaction order_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_transaction
    ADD CONSTRAINT order_transaction_pkey PRIMARY KEY (id);


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_collection_payment_providers
    ADD CONSTRAINT payment_collection_payment_providers_pkey PRIMARY KEY (payment_collection_id, payment_provider_id);


--
-- Name: payment_collection payment_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_collection
    ADD CONSTRAINT payment_collection_pkey PRIMARY KEY (id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: payment_provider payment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_provider
    ADD CONSTRAINT payment_provider_pkey PRIMARY KEY (id);


--
-- Name: payment_session payment_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_session
    ADD CONSTRAINT payment_session_pkey PRIMARY KEY (id);


--
-- Name: price_list price_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_list
    ADD CONSTRAINT price_list_pkey PRIMARY KEY (id);


--
-- Name: price_list_rule price_list_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_list_rule
    ADD CONSTRAINT price_list_rule_pkey PRIMARY KEY (id);


--
-- Name: price price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_pkey PRIMARY KEY (id);


--
-- Name: price_preference price_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_preference
    ADD CONSTRAINT price_preference_pkey PRIMARY KEY (id);


--
-- Name: price_rule price_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_rule
    ADD CONSTRAINT price_rule_pkey PRIMARY KEY (id);


--
-- Name: price_set price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_set
    ADD CONSTRAINT price_set_pkey PRIMARY KEY (id);


--
-- Name: product_category product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_pkey PRIMARY KEY (id);


--
-- Name: product_category_product product_category_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_category_product
    ADD CONSTRAINT product_category_product_pkey PRIMARY KEY (product_id, product_category_id);


--
-- Name: product_collection product_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_collection
    ADD CONSTRAINT product_collection_pkey PRIMARY KEY (id);


--
-- Name: product_option product_option_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_option
    ADD CONSTRAINT product_option_pkey PRIMARY KEY (id);


--
-- Name: product_option_value product_option_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_option_value
    ADD CONSTRAINT product_option_value_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: product_sales_channel product_sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales_channel
    ADD CONSTRAINT product_sales_channel_pkey PRIMARY KEY (product_id, sales_channel_id);


--
-- Name: product_shipping_profile product_shipping_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_shipping_profile
    ADD CONSTRAINT product_shipping_profile_pkey PRIMARY KEY (product_id, shipping_profile_id);


--
-- Name: product_tag product_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_tag
    ADD CONSTRAINT product_tag_pkey PRIMARY KEY (id);


--
-- Name: product_tags product_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_pkey PRIMARY KEY (product_id, product_tag_id);


--
-- Name: product_type product_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_type
    ADD CONSTRAINT product_type_pkey PRIMARY KEY (id);


--
-- Name: product_variant_inventory_item product_variant_inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_inventory_item
    ADD CONSTRAINT product_variant_inventory_item_pkey PRIMARY KEY (variant_id, inventory_item_id);


--
-- Name: product_variant_option product_variant_option_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_option
    ADD CONSTRAINT product_variant_option_pkey PRIMARY KEY (variant_id, option_value_id);


--
-- Name: product_variant product_variant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant
    ADD CONSTRAINT product_variant_pkey PRIMARY KEY (id);


--
-- Name: product_variant_price_set product_variant_price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_price_set
    ADD CONSTRAINT product_variant_price_set_pkey PRIMARY KEY (variant_id, price_set_id);


--
-- Name: promotion_application_method promotion_application_method_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_application_method
    ADD CONSTRAINT promotion_application_method_pkey PRIMARY KEY (id);


--
-- Name: promotion_campaign_budget promotion_campaign_budget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_campaign_budget
    ADD CONSTRAINT promotion_campaign_budget_pkey PRIMARY KEY (id);


--
-- Name: promotion_campaign promotion_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_campaign
    ADD CONSTRAINT promotion_campaign_pkey PRIMARY KEY (id);


--
-- Name: promotion promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT promotion_pkey PRIMARY KEY (id);


--
-- Name: promotion_promotion_rule promotion_promotion_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_promotion_rule
    ADD CONSTRAINT promotion_promotion_rule_pkey PRIMARY KEY (promotion_id, promotion_rule_id);


--
-- Name: promotion_rule promotion_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_rule
    ADD CONSTRAINT promotion_rule_pkey PRIMARY KEY (id);


--
-- Name: promotion_rule_value promotion_rule_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_rule_value
    ADD CONSTRAINT promotion_rule_value_pkey PRIMARY KEY (id);


--
-- Name: provider_identity provider_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_identity
    ADD CONSTRAINT provider_identity_pkey PRIMARY KEY (id);


--
-- Name: publishable_api_key_sales_channel publishable_api_key_sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publishable_api_key_sales_channel
    ADD CONSTRAINT publishable_api_key_sales_channel_pkey PRIMARY KEY (publishable_key_id, sales_channel_id);


--
-- Name: refund refund_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refund
    ADD CONSTRAINT refund_pkey PRIMARY KEY (id);


--
-- Name: refund_reason refund_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refund_reason
    ADD CONSTRAINT refund_reason_pkey PRIMARY KEY (id);


--
-- Name: region_country region_country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.region_country
    ADD CONSTRAINT region_country_pkey PRIMARY KEY (iso_2);


--
-- Name: region_payment_provider region_payment_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.region_payment_provider
    ADD CONSTRAINT region_payment_provider_pkey PRIMARY KEY (region_id, payment_provider_id);


--
-- Name: region region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.region
    ADD CONSTRAINT region_pkey PRIMARY KEY (id);


--
-- Name: reservation_item reservation_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation_item
    ADD CONSTRAINT reservation_item_pkey PRIMARY KEY (id);


--
-- Name: return_fulfillment return_fulfillment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_fulfillment
    ADD CONSTRAINT return_fulfillment_pkey PRIMARY KEY (return_id, fulfillment_id);


--
-- Name: return_item return_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_item
    ADD CONSTRAINT return_item_pkey PRIMARY KEY (id);


--
-- Name: return return_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return
    ADD CONSTRAINT return_pkey PRIMARY KEY (id);


--
-- Name: return_reason return_reason_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_reason
    ADD CONSTRAINT return_reason_pkey PRIMARY KEY (id);


--
-- Name: sales_channel sales_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_channel
    ADD CONSTRAINT sales_channel_pkey PRIMARY KEY (id);


--
-- Name: sales_channel_stock_location sales_channel_stock_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_channel_stock_location
    ADD CONSTRAINT sales_channel_stock_location_pkey PRIMARY KEY (sales_channel_id, stock_location_id);


--
-- Name: script_migrations script_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.script_migrations
    ADD CONSTRAINT script_migrations_pkey PRIMARY KEY (id);


--
-- Name: service_zone service_zone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_zone
    ADD CONSTRAINT service_zone_pkey PRIMARY KEY (id);


--
-- Name: shipping_option shipping_option_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_pkey PRIMARY KEY (id);


--
-- Name: shipping_option_price_set shipping_option_price_set_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option_price_set
    ADD CONSTRAINT shipping_option_price_set_pkey PRIMARY KEY (shipping_option_id, price_set_id);


--
-- Name: shipping_option_rule shipping_option_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option_rule
    ADD CONSTRAINT shipping_option_rule_pkey PRIMARY KEY (id);


--
-- Name: shipping_option_type shipping_option_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option_type
    ADD CONSTRAINT shipping_option_type_pkey PRIMARY KEY (id);


--
-- Name: shipping_profile shipping_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_profile
    ADD CONSTRAINT shipping_profile_pkey PRIMARY KEY (id);


--
-- Name: stock_location_address stock_location_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_location_address
    ADD CONSTRAINT stock_location_address_pkey PRIMARY KEY (id);


--
-- Name: stock_location stock_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_location
    ADD CONSTRAINT stock_location_pkey PRIMARY KEY (id);


--
-- Name: store_currency store_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_currency
    ADD CONSTRAINT store_currency_pkey PRIMARY KEY (id);


--
-- Name: store store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store
    ADD CONSTRAINT store_pkey PRIMARY KEY (id);


--
-- Name: tax_provider tax_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_provider
    ADD CONSTRAINT tax_provider_pkey PRIMARY KEY (id);


--
-- Name: tax_rate tax_rate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_rate
    ADD CONSTRAINT tax_rate_pkey PRIMARY KEY (id);


--
-- Name: tax_rate_rule tax_rate_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_rate_rule
    ADD CONSTRAINT tax_rate_rule_pkey PRIMARY KEY (id);


--
-- Name: tax_region tax_region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_region
    ADD CONSTRAINT tax_region_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: workflow_execution workflow_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_execution
    ADD CONSTRAINT workflow_execution_pkey PRIMARY KEY (workflow_id, transaction_id, run_id);


--
-- Name: IDX_account_holder_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_account_holder_deleted_at" ON public.account_holder USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_account_holder_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_account_holder_id_5cb3a0c0" ON public.customer_account_holder USING btree (account_holder_id);


--
-- Name: IDX_account_holder_provider_id_external_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_account_holder_provider_id_external_id_unique" ON public.account_holder USING btree (provider_id, external_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_adjustment_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_adjustment_item_id" ON public.cart_line_item_adjustment USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_adjustment_shipping_method_id" ON public.cart_shipping_method_adjustment USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_api_key_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_api_key_deleted_at" ON public.api_key USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_api_key_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_api_key_token_unique" ON public.api_key USING btree (token);


--
-- Name: IDX_api_key_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_api_key_type" ON public.api_key USING btree (type);


--
-- Name: IDX_application_method_allocation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_application_method_allocation" ON public.promotion_application_method USING btree (allocation);


--
-- Name: IDX_application_method_target_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_application_method_target_type" ON public.promotion_application_method USING btree (target_type);


--
-- Name: IDX_application_method_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_application_method_type" ON public.promotion_application_method USING btree (type);


--
-- Name: IDX_auth_identity_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_auth_identity_deleted_at" ON public.auth_identity USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_campaign_budget_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_campaign_budget_type" ON public.promotion_campaign_budget USING btree (type);


--
-- Name: IDX_capture_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_capture_deleted_at" ON public.capture USING btree (deleted_at);


--
-- Name: IDX_capture_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_capture_payment_id" ON public.capture USING btree (payment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_address_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_address_deleted_at" ON public.cart_address USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_billing_address_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_billing_address_id" ON public.cart USING btree (billing_address_id) WHERE ((deleted_at IS NULL) AND (billing_address_id IS NOT NULL));


--
-- Name: IDX_cart_credit_line_reference_reference_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_credit_line_reference_reference_id" ON public.credit_line USING btree (reference, reference_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_currency_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_currency_code" ON public.cart USING btree (currency_code);


--
-- Name: IDX_cart_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_customer_id" ON public.cart USING btree (customer_id) WHERE ((deleted_at IS NULL) AND (customer_id IS NOT NULL));


--
-- Name: IDX_cart_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_deleted_at" ON public.cart USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_id_-4a39f6c9" ON public.cart_payment_collection USING btree (cart_id);


--
-- Name: IDX_cart_id_-71069c16; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_id_-71069c16" ON public.order_cart USING btree (cart_id);


--
-- Name: IDX_cart_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_id_-a9d4a70b" ON public.cart_promotion USING btree (cart_id);


--
-- Name: IDX_cart_line_item_adjustment_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_line_item_adjustment_deleted_at" ON public.cart_line_item_adjustment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_line_item_adjustment_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_line_item_adjustment_item_id" ON public.cart_line_item_adjustment USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_line_item_cart_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_line_item_cart_id" ON public.cart_line_item USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_line_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_line_item_deleted_at" ON public.cart_line_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_line_item_tax_line_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_line_item_tax_line_deleted_at" ON public.cart_line_item_tax_line USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_line_item_tax_line_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_line_item_tax_line_item_id" ON public.cart_line_item_tax_line USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_region_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_region_id" ON public.cart USING btree (region_id) WHERE ((deleted_at IS NULL) AND (region_id IS NOT NULL));


--
-- Name: IDX_cart_sales_channel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_sales_channel_id" ON public.cart USING btree (sales_channel_id) WHERE ((deleted_at IS NULL) AND (sales_channel_id IS NOT NULL));


--
-- Name: IDX_cart_shipping_address_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_address_id" ON public.cart USING btree (shipping_address_id) WHERE ((deleted_at IS NULL) AND (shipping_address_id IS NOT NULL));


--
-- Name: IDX_cart_shipping_method_adjustment_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_method_adjustment_deleted_at" ON public.cart_shipping_method_adjustment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_method_adjustment_shipping_method_id" ON public.cart_shipping_method_adjustment USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_shipping_method_cart_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_method_cart_id" ON public.cart_shipping_method USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_cart_shipping_method_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_method_deleted_at" ON public.cart_shipping_method USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_tax_line_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_method_tax_line_deleted_at" ON public.cart_shipping_method_tax_line USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_cart_shipping_method_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_cart_shipping_method_tax_line_shipping_method_id" ON public.cart_shipping_method_tax_line USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_category_handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_category_handle_unique" ON public.product_category USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: IDX_collection_handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_collection_handle_unique" ON public.product_collection USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: IDX_credit_line_cart_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_credit_line_cart_id" ON public.credit_line USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_credit_line_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_credit_line_deleted_at" ON public.credit_line USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_address_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_address_customer_id" ON public.customer_address USING btree (customer_id);


--
-- Name: IDX_customer_address_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_address_deleted_at" ON public.customer_address USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_address_unique_customer_billing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_customer_address_unique_customer_billing" ON public.customer_address USING btree (customer_id) WHERE (is_default_billing = true);


--
-- Name: IDX_customer_address_unique_customer_shipping; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_customer_address_unique_customer_shipping" ON public.customer_address USING btree (customer_id) WHERE (is_default_shipping = true);


--
-- Name: IDX_customer_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_deleted_at" ON public.customer USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_email_has_account_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_customer_email_has_account_unique" ON public.customer USING btree (email, has_account) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_customer_customer_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_group_customer_customer_group_id" ON public.customer_group_customer USING btree (customer_group_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_customer_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_group_customer_customer_id" ON public.customer_group_customer USING btree (customer_id);


--
-- Name: IDX_customer_group_customer_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_group_customer_deleted_at" ON public.customer_group_customer USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_group_deleted_at" ON public.customer_group USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_customer_group_name" ON public.customer_group USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_group_name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_customer_group_name_unique" ON public.customer_group USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_customer_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_customer_id_5cb3a0c0" ON public.customer_account_holder USING btree (customer_id);


--
-- Name: IDX_deleted_at_-1d67bae40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-1e5992737; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-1e5992737" ON public.location_fulfillment_provider USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-31ea43a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-31ea43a" ON public.return_fulfillment USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-4a39f6c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-4a39f6c9" ON public.cart_payment_collection USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-71069c16; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-71069c16" ON public.order_cart USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-71518339; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-71518339" ON public.order_promotion USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-a9d4a70b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-a9d4a70b" ON public.cart_promotion USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-e88adb96; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-e88adb96" ON public.location_fulfillment_set USING btree (deleted_at);


--
-- Name: IDX_deleted_at_-e8d2543e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_-e8d2543e" ON public.order_fulfillment USING btree (deleted_at);


--
-- Name: IDX_deleted_at_17a262437; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_17a262437" ON public.product_shipping_profile USING btree (deleted_at);


--
-- Name: IDX_deleted_at_17b4c4e35; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_17b4c4e35" ON public.product_variant_inventory_item USING btree (deleted_at);


--
-- Name: IDX_deleted_at_1c934dab0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_1c934dab0" ON public.region_payment_provider USING btree (deleted_at);


--
-- Name: IDX_deleted_at_20b454295; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_20b454295" ON public.product_sales_channel USING btree (deleted_at);


--
-- Name: IDX_deleted_at_26d06f470; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_26d06f470" ON public.sales_channel_stock_location USING btree (deleted_at);


--
-- Name: IDX_deleted_at_52b23597; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_52b23597" ON public.product_variant_price_set USING btree (deleted_at);


--
-- Name: IDX_deleted_at_5cb3a0c0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_5cb3a0c0" ON public.customer_account_holder USING btree (deleted_at);


--
-- Name: IDX_deleted_at_ba32fa9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_ba32fa9c" ON public.shipping_option_price_set USING btree (deleted_at);


--
-- Name: IDX_deleted_at_f42b9949; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_deleted_at_f42b9949" ON public.order_payment_collection USING btree (deleted_at);


--
-- Name: IDX_fulfillment_address_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_address_deleted_at" ON public.fulfillment_address USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_deleted_at" ON public.fulfillment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_id_-31ea43a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_id_-31ea43a" ON public.return_fulfillment USING btree (fulfillment_id);


--
-- Name: IDX_fulfillment_id_-e8d2543e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_id_-e8d2543e" ON public.order_fulfillment USING btree (fulfillment_id);


--
-- Name: IDX_fulfillment_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_item_deleted_at" ON public.fulfillment_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_item_fulfillment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_item_fulfillment_id" ON public.fulfillment_item USING btree (fulfillment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_item_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_item_inventory_item_id" ON public.fulfillment_item USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_item_line_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_item_line_item_id" ON public.fulfillment_item USING btree (line_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_label_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_label_deleted_at" ON public.fulfillment_label USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_label_fulfillment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_label_fulfillment_id" ON public.fulfillment_label USING btree (fulfillment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_location_id" ON public.fulfillment USING btree (location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_provider_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_provider_deleted_at" ON public.fulfillment_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_provider_id_-1e5992737; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_provider_id_-1e5992737" ON public.location_fulfillment_provider USING btree (fulfillment_provider_id);


--
-- Name: IDX_fulfillment_set_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_set_deleted_at" ON public.fulfillment_set USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_fulfillment_set_id_-e88adb96; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_set_id_-e88adb96" ON public.location_fulfillment_set USING btree (fulfillment_set_id);


--
-- Name: IDX_fulfillment_set_name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_fulfillment_set_name_unique" ON public.fulfillment_set USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_fulfillment_shipping_option_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_fulfillment_shipping_option_id" ON public.fulfillment USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_geo_zone_city; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_geo_zone_city" ON public.geo_zone USING btree (city) WHERE ((deleted_at IS NULL) AND (city IS NOT NULL));


--
-- Name: IDX_geo_zone_country_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_geo_zone_country_code" ON public.geo_zone USING btree (country_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_geo_zone_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_geo_zone_deleted_at" ON public.geo_zone USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_geo_zone_province_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_geo_zone_province_code" ON public.geo_zone USING btree (province_code) WHERE ((deleted_at IS NULL) AND (province_code IS NOT NULL));


--
-- Name: IDX_geo_zone_service_zone_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_geo_zone_service_zone_id" ON public.geo_zone USING btree (service_zone_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_id_-1d67bae40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (id);


--
-- Name: IDX_id_-1e5992737; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-1e5992737" ON public.location_fulfillment_provider USING btree (id);


--
-- Name: IDX_id_-31ea43a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-31ea43a" ON public.return_fulfillment USING btree (id);


--
-- Name: IDX_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-4a39f6c9" ON public.cart_payment_collection USING btree (id);


--
-- Name: IDX_id_-71069c16; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-71069c16" ON public.order_cart USING btree (id);


--
-- Name: IDX_id_-71518339; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-71518339" ON public.order_promotion USING btree (id);


--
-- Name: IDX_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-a9d4a70b" ON public.cart_promotion USING btree (id);


--
-- Name: IDX_id_-e88adb96; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-e88adb96" ON public.location_fulfillment_set USING btree (id);


--
-- Name: IDX_id_-e8d2543e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_-e8d2543e" ON public.order_fulfillment USING btree (id);


--
-- Name: IDX_id_17a262437; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_17a262437" ON public.product_shipping_profile USING btree (id);


--
-- Name: IDX_id_17b4c4e35; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_17b4c4e35" ON public.product_variant_inventory_item USING btree (id);


--
-- Name: IDX_id_1c934dab0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_1c934dab0" ON public.region_payment_provider USING btree (id);


--
-- Name: IDX_id_20b454295; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_20b454295" ON public.product_sales_channel USING btree (id);


--
-- Name: IDX_id_26d06f470; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_26d06f470" ON public.sales_channel_stock_location USING btree (id);


--
-- Name: IDX_id_52b23597; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_52b23597" ON public.product_variant_price_set USING btree (id);


--
-- Name: IDX_id_5cb3a0c0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_5cb3a0c0" ON public.customer_account_holder USING btree (id);


--
-- Name: IDX_id_ba32fa9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_ba32fa9c" ON public.shipping_option_price_set USING btree (id);


--
-- Name: IDX_id_f42b9949; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_id_f42b9949" ON public.order_payment_collection USING btree (id);


--
-- Name: IDX_image_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_image_deleted_at" ON public.image USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_image_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_image_product_id" ON public.image USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_inventory_item_deleted_at" ON public.inventory_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_inventory_item_id_17b4c4e35; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_inventory_item_id_17b4c4e35" ON public.product_variant_inventory_item USING btree (inventory_item_id);


--
-- Name: IDX_inventory_item_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_inventory_item_sku" ON public.inventory_item USING btree (sku) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_inventory_level_deleted_at" ON public.inventory_level USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_inventory_level_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_inventory_level_inventory_item_id" ON public.inventory_level USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_item_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_inventory_level_item_location" ON public.inventory_level USING btree (inventory_item_id, location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_inventory_level_location_id" ON public.inventory_level USING btree (location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_inventory_level_location_id_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_inventory_level_location_id_inventory_item_id" ON public.inventory_level USING btree (inventory_item_id, location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_invite_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_invite_deleted_at" ON public.invite USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_invite_email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_invite_email_unique" ON public.invite USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: IDX_invite_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_invite_token" ON public.invite USING btree (token) WHERE (deleted_at IS NULL);


--
-- Name: IDX_line_item_adjustment_promotion_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_line_item_adjustment_promotion_id" ON public.cart_line_item_adjustment USING btree (promotion_id) WHERE ((deleted_at IS NULL) AND (promotion_id IS NOT NULL));


--
-- Name: IDX_line_item_cart_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_line_item_cart_id" ON public.cart_line_item USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_line_item_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_line_item_product_id" ON public.cart_line_item USING btree (product_id) WHERE ((deleted_at IS NULL) AND (product_id IS NOT NULL));


--
-- Name: IDX_line_item_product_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_line_item_product_type_id" ON public.cart_line_item USING btree (product_type_id) WHERE ((deleted_at IS NULL) AND (product_type_id IS NOT NULL));


--
-- Name: IDX_line_item_tax_line_tax_rate_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_line_item_tax_line_tax_rate_id" ON public.cart_line_item_tax_line USING btree (tax_rate_id) WHERE ((deleted_at IS NULL) AND (tax_rate_id IS NOT NULL));


--
-- Name: IDX_line_item_variant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_line_item_variant_id" ON public.cart_line_item USING btree (variant_id) WHERE ((deleted_at IS NULL) AND (variant_id IS NOT NULL));


--
-- Name: IDX_notification_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_deleted_at" ON public.notification USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_notification_idempotency_key_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_notification_idempotency_key_unique" ON public.notification USING btree (idempotency_key) WHERE (deleted_at IS NULL);


--
-- Name: IDX_notification_provider_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_provider_deleted_at" ON public.notification_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_notification_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_provider_id" ON public.notification USING btree (provider_id);


--
-- Name: IDX_notification_receiver_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_notification_receiver_id" ON public.notification USING btree (receiver_id);


--
-- Name: IDX_option_product_id_title_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_option_product_id_title_unique" ON public.product_option USING btree (product_id, title) WHERE (deleted_at IS NULL);


--
-- Name: IDX_option_value_option_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_option_value_option_id_unique" ON public.product_option_value USING btree (option_id, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_address_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_address_customer_id" ON public.order_address USING btree (customer_id);


--
-- Name: IDX_order_address_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_address_deleted_at" ON public.order_address USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_billing_address_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_billing_address_id" ON public."order" USING btree (billing_address_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_change_action_claim_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_claim_id" ON public.order_change_action USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_action_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_deleted_at" ON public.order_change_action USING btree (deleted_at);


--
-- Name: IDX_order_change_action_exchange_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_exchange_id" ON public.order_change_action USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_action_order_change_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_order_change_id" ON public.order_change_action USING btree (order_change_id);


--
-- Name: IDX_order_change_action_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_order_id" ON public.order_change_action USING btree (order_id);


--
-- Name: IDX_order_change_action_ordering; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_ordering" ON public.order_change_action USING btree (ordering);


--
-- Name: IDX_order_change_action_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_action_return_id" ON public.order_change_action USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_change_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_change_type" ON public.order_change USING btree (change_type);


--
-- Name: IDX_order_change_claim_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_claim_id" ON public.order_change USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_deleted_at" ON public.order_change USING btree (deleted_at);


--
-- Name: IDX_order_change_exchange_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_exchange_id" ON public.order_change USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_order_id" ON public.order_change USING btree (order_id);


--
-- Name: IDX_order_change_order_id_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_order_id_version" ON public.order_change USING btree (order_id, version);


--
-- Name: IDX_order_change_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_return_id" ON public.order_change USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_change_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_change_status" ON public.order_change USING btree (status);


--
-- Name: IDX_order_claim_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_deleted_at" ON public.order_claim USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_display_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_display_id" ON public.order_claim USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_claim_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_item_claim_id" ON public.order_claim_item USING btree (claim_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_item_deleted_at" ON public.order_claim_item USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_item_image_claim_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_item_image_claim_item_id" ON public.order_claim_item_image USING btree (claim_item_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_claim_item_image_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_item_image_deleted_at" ON public.order_claim_item_image USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_claim_item_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_item_item_id" ON public.order_claim_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_order_id" ON public.order_claim USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_claim_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_claim_return_id" ON public.order_claim USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_credit_line_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_credit_line_deleted_at" ON public.order_credit_line USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_credit_line_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_credit_line_order_id" ON public.order_credit_line USING btree (order_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_currency_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_currency_code" ON public."order" USING btree (currency_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_customer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_customer_id" ON public."order" USING btree (customer_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_deleted_at" ON public."order" USING btree (deleted_at);


--
-- Name: IDX_order_display_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_display_id" ON public."order" USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_deleted_at" ON public.order_exchange USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_display_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_display_id" ON public.order_exchange USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_item_deleted_at" ON public.order_exchange_item USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_item_exchange_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_item_exchange_id" ON public.order_exchange_item USING btree (exchange_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_item_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_item_item_id" ON public.order_exchange_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_order_id" ON public.order_exchange USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_exchange_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_exchange_return_id" ON public.order_exchange USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_id_-71069c16; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_id_-71069c16" ON public.order_cart USING btree (order_id);


--
-- Name: IDX_order_id_-71518339; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_id_-71518339" ON public.order_promotion USING btree (order_id);


--
-- Name: IDX_order_id_-e8d2543e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_id_-e8d2543e" ON public.order_fulfillment USING btree (order_id);


--
-- Name: IDX_order_id_f42b9949; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_id_f42b9949" ON public.order_payment_collection USING btree (order_id);


--
-- Name: IDX_order_is_draft_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_is_draft_order" ON public."order" USING btree (is_draft_order) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_item_deleted_at" ON public.order_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_item_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_item_item_id" ON public.order_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_item_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_item_order_id" ON public.order_item USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_item_order_id_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_item_order_id_version" ON public.order_item USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_adjustment_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_line_item_adjustment_item_id" ON public.order_line_item_adjustment USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_line_item_product_id" ON public.order_line_item USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_tax_line_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_line_item_tax_line_item_id" ON public.order_line_item_tax_line USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_line_item_variant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_line_item_variant_id" ON public.order_line_item USING btree (variant_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_region_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_region_id" ON public."order" USING btree (region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_address_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_address_id" ON public."order" USING btree (shipping_address_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_claim_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_claim_id" ON public.order_shipping USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_shipping_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_deleted_at" ON public.order_shipping USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_shipping_exchange_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_exchange_id" ON public.order_shipping USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_shipping_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_item_id" ON public.order_shipping USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_adjustment_shipping_method_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_method_adjustment_shipping_method_id" ON public.order_shipping_method_adjustment USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_shipping_option_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_method_shipping_option_id" ON public.order_shipping_method USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_method_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_method_tax_line_shipping_method_id" ON public.order_shipping_method_tax_line USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_order_id" ON public.order_shipping USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_order_id_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_order_id_version" ON public.order_shipping USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_shipping_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_shipping_return_id" ON public.order_shipping USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_summary_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_summary_deleted_at" ON public.order_summary USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_order_summary_order_id_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_summary_order_id_version" ON public.order_summary USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_claim_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_transaction_claim_id" ON public.order_transaction USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_transaction_currency_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_transaction_currency_code" ON public.order_transaction USING btree (currency_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_exchange_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_transaction_exchange_id" ON public.order_transaction USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_order_transaction_order_id_version; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_transaction_order_id_version" ON public.order_transaction USING btree (order_id, version) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_reference_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_transaction_reference_id" ON public.order_transaction USING btree (reference_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_order_transaction_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_order_transaction_return_id" ON public.order_transaction USING btree (return_id) WHERE ((return_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_payment_collection_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_collection_deleted_at" ON public.payment_collection USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_payment_collection_id_-4a39f6c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_collection_id_-4a39f6c9" ON public.cart_payment_collection USING btree (payment_collection_id);


--
-- Name: IDX_payment_collection_id_f42b9949; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_collection_id_f42b9949" ON public.order_payment_collection USING btree (payment_collection_id);


--
-- Name: IDX_payment_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_deleted_at" ON public.payment USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_payment_payment_collection_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_payment_collection_id" ON public.payment USING btree (payment_collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_payment_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_payment_session_id" ON public.payment USING btree (payment_session_id);


--
-- Name: IDX_payment_payment_session_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_payment_payment_session_id_unique" ON public.payment USING btree (payment_session_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_provider_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_provider_deleted_at" ON public.payment_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_provider_id" ON public.payment USING btree (provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_payment_provider_id_1c934dab0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_provider_id_1c934dab0" ON public.region_payment_provider USING btree (payment_provider_id);


--
-- Name: IDX_payment_session_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_session_deleted_at" ON public.payment_session USING btree (deleted_at);


--
-- Name: IDX_payment_session_payment_collection_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_payment_session_payment_collection_id" ON public.payment_session USING btree (payment_collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_currency_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_currency_code" ON public.price USING btree (currency_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_deleted_at" ON public.price USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_list_deleted_at" ON public.price_list USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_rule_attribute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_list_rule_attribute" ON public.price_list_rule USING btree (attribute) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_list_rule_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_list_rule_deleted_at" ON public.price_list_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_list_rule_price_list_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_list_rule_price_list_id" ON public.price_list_rule USING btree (price_list_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_preference_attribute_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_price_preference_attribute_value" ON public.price_preference USING btree (attribute, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_preference_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_preference_deleted_at" ON public.price_preference USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_price_list_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_price_list_id" ON public.price USING btree (price_list_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_price_set_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_price_set_id" ON public.price USING btree (price_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_attribute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_rule_attribute" ON public.price_rule USING btree (attribute) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_attribute_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_rule_attribute_value" ON public.price_rule USING btree (attribute, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_rule_deleted_at" ON public.price_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_rule_operator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_rule_operator" ON public.price_rule USING btree (operator);


--
-- Name: IDX_price_rule_operator_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_rule_operator_value" ON public.price_rule USING btree (operator, value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_price_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_rule_price_id" ON public.price_rule USING btree (price_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_rule_price_id_attribute_operator_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_price_rule_price_id_attribute_operator_unique" ON public.price_rule USING btree (price_id, attribute, operator) WHERE (deleted_at IS NULL);


--
-- Name: IDX_price_set_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_set_deleted_at" ON public.price_set USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_price_set_id_52b23597; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_set_id_52b23597" ON public.product_variant_price_set USING btree (price_set_id);


--
-- Name: IDX_price_set_id_ba32fa9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_price_set_id_ba32fa9c" ON public.shipping_option_price_set USING btree (price_set_id);


--
-- Name: IDX_product_category_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_category_deleted_at" ON public.product_collection USING btree (deleted_at);


--
-- Name: IDX_product_category_parent_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_category_parent_category_id" ON public.product_category USING btree (parent_category_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_category_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_category_path" ON public.product_category USING btree (mpath) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_collection_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_collection_deleted_at" ON public.product_collection USING btree (deleted_at);


--
-- Name: IDX_product_collection_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_collection_id" ON public.product USING btree (collection_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_deleted_at" ON public.product USING btree (deleted_at);


--
-- Name: IDX_product_handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_product_handle_unique" ON public.product USING btree (handle) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_id_17a262437; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_id_17a262437" ON public.product_shipping_profile USING btree (product_id);


--
-- Name: IDX_product_id_20b454295; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_id_20b454295" ON public.product_sales_channel USING btree (product_id);


--
-- Name: IDX_product_image_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_image_url" ON public.image USING btree (url) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_option_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_option_deleted_at" ON public.product_option USING btree (deleted_at);


--
-- Name: IDX_product_option_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_option_product_id" ON public.product_option USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_option_value_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_option_value_deleted_at" ON public.product_option_value USING btree (deleted_at);


--
-- Name: IDX_product_option_value_option_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_option_value_option_id" ON public.product_option_value USING btree (option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_tag_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_tag_deleted_at" ON public.product_tag USING btree (deleted_at);


--
-- Name: IDX_product_type_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_type_deleted_at" ON public.product_type USING btree (deleted_at);


--
-- Name: IDX_product_type_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_type_id" ON public.product USING btree (type_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_barcode_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_product_variant_barcode_unique" ON public.product_variant USING btree (barcode) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_variant_deleted_at" ON public.product_variant USING btree (deleted_at);


--
-- Name: IDX_product_variant_ean_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_product_variant_ean_unique" ON public.product_variant USING btree (ean) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_id_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_variant_id_product_id" ON public.product_variant USING btree (id, product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_product_variant_product_id" ON public.product_variant USING btree (product_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_sku_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_product_variant_sku_unique" ON public.product_variant USING btree (sku) WHERE (deleted_at IS NULL);


--
-- Name: IDX_product_variant_upc_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_product_variant_upc_unique" ON public.product_variant USING btree (upc) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_application_method_currency_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_application_method_currency_code" ON public.promotion_application_method USING btree (currency_code) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_promotion_application_method_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_application_method_deleted_at" ON public.promotion_application_method USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_application_method_promotion_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_promotion_application_method_promotion_id_unique" ON public.promotion_application_method USING btree (promotion_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_campaign_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_budget_campaign_id_unique" ON public.promotion_campaign_budget USING btree (campaign_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_budget_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_campaign_budget_deleted_at" ON public.promotion_campaign_budget USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_campaign_identifier_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_promotion_campaign_campaign_identifier_unique" ON public.promotion_campaign USING btree (campaign_identifier) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_campaign_deleted_at" ON public.promotion_campaign USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_campaign_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_campaign_id" ON public.promotion USING btree (campaign_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_deleted_at" ON public.promotion USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_id_-71518339; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_id_-71518339" ON public.order_promotion USING btree (promotion_id);


--
-- Name: IDX_promotion_id_-a9d4a70b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_id_-a9d4a70b" ON public.cart_promotion USING btree (promotion_id);


--
-- Name: IDX_promotion_rule_attribute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_rule_attribute" ON public.promotion_rule USING btree (attribute);


--
-- Name: IDX_promotion_rule_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_rule_deleted_at" ON public.promotion_rule USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_operator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_rule_operator" ON public.promotion_rule USING btree (operator);


--
-- Name: IDX_promotion_rule_value_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_rule_value_deleted_at" ON public.promotion_rule_value USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_rule_value_promotion_rule_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_rule_value_promotion_rule_id" ON public.promotion_rule_value USING btree (promotion_rule_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_status" ON public.promotion USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: IDX_promotion_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_promotion_type" ON public.promotion USING btree (type);


--
-- Name: IDX_provider_identity_auth_identity_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_provider_identity_auth_identity_id" ON public.provider_identity USING btree (auth_identity_id);


--
-- Name: IDX_provider_identity_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_provider_identity_deleted_at" ON public.provider_identity USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_provider_identity_provider_entity_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_provider_identity_provider_entity_id" ON public.provider_identity USING btree (entity_id, provider);


--
-- Name: IDX_publishable_key_id_-1d67bae40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_publishable_key_id_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (publishable_key_id);


--
-- Name: IDX_refund_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_refund_deleted_at" ON public.refund USING btree (deleted_at);


--
-- Name: IDX_refund_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_refund_payment_id" ON public.refund USING btree (payment_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_refund_reason_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_refund_reason_deleted_at" ON public.refund_reason USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_refund_refund_reason_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_refund_refund_reason_id" ON public.refund USING btree (refund_reason_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_region_country_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_region_country_deleted_at" ON public.region_country USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_region_country_region_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_region_country_region_id" ON public.region_country USING btree (region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_region_country_region_id_iso_2_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_region_country_region_id_iso_2_unique" ON public.region_country USING btree (region_id, iso_2);


--
-- Name: IDX_region_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_region_deleted_at" ON public.region USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_region_id_1c934dab0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_region_id_1c934dab0" ON public.region_payment_provider USING btree (region_id);


--
-- Name: IDX_reservation_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reservation_item_deleted_at" ON public.reservation_item USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_reservation_item_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reservation_item_inventory_item_id" ON public.reservation_item USING btree (inventory_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_reservation_item_line_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reservation_item_line_item_id" ON public.reservation_item USING btree (line_item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_reservation_item_location_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_reservation_item_location_id" ON public.reservation_item USING btree (location_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_claim_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_claim_id" ON public.return USING btree (claim_id) WHERE ((claim_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_return_display_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_display_id" ON public.return USING btree (display_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_exchange_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_exchange_id" ON public.return USING btree (exchange_id) WHERE ((exchange_id IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_return_id_-31ea43a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_id_-31ea43a" ON public.return_fulfillment USING btree (return_id);


--
-- Name: IDX_return_item_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_item_deleted_at" ON public.return_item USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_item_item_id" ON public.return_item USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_reason_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_item_reason_id" ON public.return_item USING btree (reason_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_item_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_item_return_id" ON public.return_item USING btree (return_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_return_order_id" ON public.return USING btree (order_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_return_reason_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_return_reason_value" ON public.return_reason USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_sales_channel_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_sales_channel_deleted_at" ON public.sales_channel USING btree (deleted_at);


--
-- Name: IDX_sales_channel_id_-1d67bae40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_sales_channel_id_-1d67bae40" ON public.publishable_api_key_sales_channel USING btree (sales_channel_id);


--
-- Name: IDX_sales_channel_id_20b454295; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_sales_channel_id_20b454295" ON public.product_sales_channel USING btree (sales_channel_id);


--
-- Name: IDX_sales_channel_id_26d06f470; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_sales_channel_id_26d06f470" ON public.sales_channel_stock_location USING btree (sales_channel_id);


--
-- Name: IDX_service_zone_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_service_zone_deleted_at" ON public.service_zone USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_service_zone_fulfillment_set_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_service_zone_fulfillment_set_id" ON public.service_zone USING btree (fulfillment_set_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_service_zone_name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_service_zone_name_unique" ON public.service_zone USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_method_adjustment_promotion_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_method_adjustment_promotion_id" ON public.cart_shipping_method_adjustment USING btree (promotion_id) WHERE ((deleted_at IS NULL) AND (promotion_id IS NOT NULL));


--
-- Name: IDX_shipping_method_cart_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_method_cart_id" ON public.cart_shipping_method USING btree (cart_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_method_option_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_method_option_id" ON public.cart_shipping_method USING btree (shipping_option_id) WHERE ((deleted_at IS NULL) AND (shipping_option_id IS NOT NULL));


--
-- Name: IDX_shipping_method_tax_line_tax_rate_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_method_tax_line_tax_rate_id" ON public.cart_shipping_method_tax_line USING btree (tax_rate_id) WHERE ((deleted_at IS NULL) AND (tax_rate_id IS NOT NULL));


--
-- Name: IDX_shipping_option_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_deleted_at" ON public.shipping_option USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_option_id_ba32fa9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_id_ba32fa9c" ON public.shipping_option_price_set USING btree (shipping_option_id);


--
-- Name: IDX_shipping_option_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_provider_id" ON public.shipping_option USING btree (provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_rule_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_rule_deleted_at" ON public.shipping_option_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_option_rule_shipping_option_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_rule_shipping_option_id" ON public.shipping_option_rule USING btree (shipping_option_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_service_zone_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_service_zone_id" ON public.shipping_option USING btree (service_zone_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_shipping_profile_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_shipping_profile_id" ON public.shipping_option USING btree (shipping_profile_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_shipping_option_type_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_option_type_deleted_at" ON public.shipping_option_type USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_profile_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_profile_deleted_at" ON public.shipping_profile USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_shipping_profile_id_17a262437; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_shipping_profile_id_17a262437" ON public.product_shipping_profile USING btree (shipping_profile_id);


--
-- Name: IDX_shipping_profile_name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_shipping_profile_name_unique" ON public.shipping_profile USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: IDX_single_default_region; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_single_default_region" ON public.tax_rate USING btree (tax_region_id) WHERE ((is_default = true) AND (deleted_at IS NULL));


--
-- Name: IDX_stock_location_address_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stock_location_address_deleted_at" ON public.stock_location_address USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_stock_location_address_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_stock_location_address_id_unique" ON public.stock_location USING btree (address_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_stock_location_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stock_location_deleted_at" ON public.stock_location USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_stock_location_id_-1e5992737; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stock_location_id_-1e5992737" ON public.location_fulfillment_provider USING btree (stock_location_id);


--
-- Name: IDX_stock_location_id_-e88adb96; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stock_location_id_-e88adb96" ON public.location_fulfillment_set USING btree (stock_location_id);


--
-- Name: IDX_stock_location_id_26d06f470; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_stock_location_id_26d06f470" ON public.sales_channel_stock_location USING btree (stock_location_id);


--
-- Name: IDX_store_currency_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_store_currency_deleted_at" ON public.store_currency USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_store_currency_store_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_store_currency_store_id" ON public.store_currency USING btree (store_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_store_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_store_deleted_at" ON public.store USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tag_value_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_tag_value_unique" ON public.product_tag USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_line_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_line_item_id" ON public.cart_line_item_tax_line USING btree (item_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_line_shipping_method_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_line_shipping_method_id" ON public.cart_shipping_method_tax_line USING btree (shipping_method_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_provider_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_provider_deleted_at" ON public.tax_provider USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_rate_deleted_at" ON public.tax_rate USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tax_rate_rule_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_rate_rule_deleted_at" ON public.tax_rate_rule USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tax_rate_rule_reference_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_rate_rule_reference_id" ON public.tax_rate_rule USING btree (reference_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_rule_tax_rate_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_rate_rule_tax_rate_id" ON public.tax_rate_rule USING btree (tax_rate_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_rule_unique_rate_reference; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_tax_rate_rule_unique_rate_reference" ON public.tax_rate_rule USING btree (tax_rate_id, reference_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_rate_tax_region_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_rate_tax_region_id" ON public.tax_rate USING btree (tax_region_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_region_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_region_deleted_at" ON public.tax_region USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_tax_region_parent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_region_parent_id" ON public.tax_region USING btree (parent_id);


--
-- Name: IDX_tax_region_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_tax_region_provider_id" ON public.tax_region USING btree (provider_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_tax_region_unique_country_nullable_province; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_tax_region_unique_country_nullable_province" ON public.tax_region USING btree (country_code) WHERE ((province_code IS NULL) AND (deleted_at IS NULL));


--
-- Name: IDX_tax_region_unique_country_province; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_tax_region_unique_country_province" ON public.tax_region USING btree (country_code, province_code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_type_value_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_type_value_unique" ON public.product_type USING btree (value) WHERE (deleted_at IS NULL);


--
-- Name: IDX_unique_promotion_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_unique_promotion_code" ON public.promotion USING btree (code) WHERE (deleted_at IS NULL);


--
-- Name: IDX_user_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_user_deleted_at" ON public."user" USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: IDX_user_email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_user_email_unique" ON public."user" USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: IDX_variant_id_17b4c4e35; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_variant_id_17b4c4e35" ON public.product_variant_inventory_item USING btree (variant_id);


--
-- Name: IDX_variant_id_52b23597; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_variant_id_52b23597" ON public.product_variant_price_set USING btree (variant_id);


--
-- Name: IDX_workflow_execution_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_workflow_execution_deleted_at" ON public.workflow_execution USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_workflow_execution_id" ON public.workflow_execution USING btree (id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_state; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_workflow_execution_state" ON public.workflow_execution USING btree (state) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_transaction_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_workflow_execution_transaction_id" ON public.workflow_execution USING btree (transaction_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_workflow_execution_workflow_id" ON public.workflow_execution USING btree (workflow_id) WHERE (deleted_at IS NULL);


--
-- Name: IDX_workflow_execution_workflow_id_transaction_id_run_id_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "IDX_workflow_execution_workflow_id_transaction_id_run_id_unique" ON public.workflow_execution USING btree (workflow_id, transaction_id, run_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_script_name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_script_name_unique ON public.script_migrations USING btree (script_name);


--
-- Name: tax_rate_rule FK_tax_rate_rule_tax_rate_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_rate_rule
    ADD CONSTRAINT "FK_tax_rate_rule_tax_rate_id" FOREIGN KEY (tax_rate_id) REFERENCES public.tax_rate(id) ON DELETE CASCADE;


--
-- Name: tax_rate FK_tax_rate_tax_region_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_rate
    ADD CONSTRAINT "FK_tax_rate_tax_region_id" FOREIGN KEY (tax_region_id) REFERENCES public.tax_region(id) ON DELETE CASCADE;


--
-- Name: tax_region FK_tax_region_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_region
    ADD CONSTRAINT "FK_tax_region_parent_id" FOREIGN KEY (parent_id) REFERENCES public.tax_region(id) ON DELETE CASCADE;


--
-- Name: tax_region FK_tax_region_provider_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_region
    ADD CONSTRAINT "FK_tax_region_provider_id" FOREIGN KEY (provider_id) REFERENCES public.tax_provider(id) ON DELETE SET NULL;


--
-- Name: application_method_buy_rules application_method_buy_rules_application_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_method_buy_rules
    ADD CONSTRAINT application_method_buy_rules_application_method_id_foreign FOREIGN KEY (application_method_id) REFERENCES public.promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_buy_rules application_method_buy_rules_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_method_buy_rules
    ADD CONSTRAINT application_method_buy_rules_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_target_rules application_method_target_rules_application_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_method_target_rules
    ADD CONSTRAINT application_method_target_rules_application_method_id_foreign FOREIGN KEY (application_method_id) REFERENCES public.promotion_application_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_method_target_rules application_method_target_rules_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_method_target_rules
    ADD CONSTRAINT application_method_target_rules_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: capture capture_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.capture
    ADD CONSTRAINT capture_payment_id_foreign FOREIGN KEY (payment_id) REFERENCES public.payment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_billing_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_billing_address_id_foreign FOREIGN KEY (billing_address_id) REFERENCES public.cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_line_item_adjustment cart_line_item_adjustment_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_line_item_adjustment
    ADD CONSTRAINT cart_line_item_adjustment_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_line_item cart_line_item_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_line_item
    ADD CONSTRAINT cart_line_item_cart_id_foreign FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_line_item_tax_line cart_line_item_tax_line_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_line_item_tax_line
    ADD CONSTRAINT cart_line_item_tax_line_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.cart_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart cart_shipping_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_shipping_address_id_foreign FOREIGN KEY (shipping_address_id) REFERENCES public.cart_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_shipping_method_adjustment cart_shipping_method_adjustment_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_shipping_method_adjustment
    ADD CONSTRAINT cart_shipping_method_adjustment_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_shipping_method cart_shipping_method_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_shipping_method
    ADD CONSTRAINT cart_shipping_method_cart_id_foreign FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_shipping_method_tax_line cart_shipping_method_tax_line_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_shipping_method_tax_line
    ADD CONSTRAINT cart_shipping_method_tax_line_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.cart_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: credit_line credit_line_cart_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_line
    ADD CONSTRAINT credit_line_cart_id_foreign FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON UPDATE CASCADE;


--
-- Name: customer_address customer_address_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_address
    ADD CONSTRAINT customer_address_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_group_customer customer_group_customer_customer_group_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_group_customer
    ADD CONSTRAINT customer_group_customer_customer_group_id_foreign FOREIGN KEY (customer_group_id) REFERENCES public.customer_group(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_group_customer customer_group_customer_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_group_customer
    ADD CONSTRAINT customer_group_customer_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment fulfillment_delivery_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_delivery_address_id_foreign FOREIGN KEY (delivery_address_id) REFERENCES public.fulfillment_address(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fulfillment_item fulfillment_item_fulfillment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_item
    ADD CONSTRAINT fulfillment_item_fulfillment_id_foreign FOREIGN KEY (fulfillment_id) REFERENCES public.fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment_label fulfillment_label_fulfillment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment_label
    ADD CONSTRAINT fulfillment_label_fulfillment_id_foreign FOREIGN KEY (fulfillment_id) REFERENCES public.fulfillment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fulfillment fulfillment_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_provider_id_foreign FOREIGN KEY (provider_id) REFERENCES public.fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: fulfillment fulfillment_shipping_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fulfillment
    ADD CONSTRAINT fulfillment_shipping_option_id_foreign FOREIGN KEY (shipping_option_id) REFERENCES public.shipping_option(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: geo_zone geo_zone_service_zone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_zone
    ADD CONSTRAINT geo_zone_service_zone_id_foreign FOREIGN KEY (service_zone_id) REFERENCES public.service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: image image_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_level inventory_level_inventory_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_level
    ADD CONSTRAINT inventory_level_inventory_item_id_foreign FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification notification_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_provider_id_foreign FOREIGN KEY (provider_id) REFERENCES public.notification_provider(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order order_billing_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_billing_address_id_foreign FOREIGN KEY (billing_address_id) REFERENCES public.order_address(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_change_action order_change_action_order_change_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_change_action
    ADD CONSTRAINT order_change_action_order_change_id_foreign FOREIGN KEY (order_change_id) REFERENCES public.order_change(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_change order_change_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_change
    ADD CONSTRAINT order_change_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_credit_line order_credit_line_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_credit_line
    ADD CONSTRAINT order_credit_line_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item order_item_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_item order_item_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_item
    ADD CONSTRAINT order_item_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item_adjustment order_line_item_adjustment_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line_item_adjustment
    ADD CONSTRAINT order_line_item_adjustment_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item_tax_line order_line_item_tax_line_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line_item_tax_line
    ADD CONSTRAINT order_line_item_tax_line_item_id_foreign FOREIGN KEY (item_id) REFERENCES public.order_line_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_line_item order_line_item_totals_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_line_item
    ADD CONSTRAINT order_line_item_totals_id_foreign FOREIGN KEY (totals_id) REFERENCES public.order_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order order_shipping_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_shipping_address_id_foreign FOREIGN KEY (shipping_address_id) REFERENCES public.order_address(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping_method_adjustment order_shipping_method_adjustment_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping_method_adjustment
    ADD CONSTRAINT order_shipping_method_adjustment_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping_method_tax_line order_shipping_method_tax_line_shipping_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping_method_tax_line
    ADD CONSTRAINT order_shipping_method_tax_line_shipping_method_id_foreign FOREIGN KEY (shipping_method_id) REFERENCES public.order_shipping_method(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_shipping order_shipping_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_shipping
    ADD CONSTRAINT order_shipping_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_summary order_summary_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_summary
    ADD CONSTRAINT order_summary_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_transaction order_transaction_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_transaction
    ADD CONSTRAINT order_transaction_order_id_foreign FOREIGN KEY (order_id) REFERENCES public."order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_payment_col_aa276_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_collection_payment_providers
    ADD CONSTRAINT payment_collection_payment_providers_payment_col_aa276_foreign FOREIGN KEY (payment_collection_id) REFERENCES public.payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_collection_payment_providers payment_collection_payment_providers_payment_pro_2d555_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_collection_payment_providers
    ADD CONSTRAINT payment_collection_payment_providers_payment_pro_2d555_foreign FOREIGN KEY (payment_provider_id) REFERENCES public.payment_provider(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment payment_payment_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_payment_collection_id_foreign FOREIGN KEY (payment_collection_id) REFERENCES public.payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_session payment_session_payment_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_session
    ADD CONSTRAINT payment_session_payment_collection_id_foreign FOREIGN KEY (payment_collection_id) REFERENCES public.payment_collection(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_list_rule price_list_rule_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_list_rule
    ADD CONSTRAINT price_list_rule_price_list_id_foreign FOREIGN KEY (price_list_id) REFERENCES public.price_list(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price price_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_price_list_id_foreign FOREIGN KEY (price_list_id) REFERENCES public.price_list(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price price_price_set_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price
    ADD CONSTRAINT price_price_set_id_foreign FOREIGN KEY (price_set_id) REFERENCES public.price_set(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: price_rule price_rule_price_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_rule
    ADD CONSTRAINT price_rule_price_id_foreign FOREIGN KEY (price_id) REFERENCES public.price(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category product_category_parent_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_parent_category_id_foreign FOREIGN KEY (parent_category_id) REFERENCES public.product_category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category_product product_category_product_product_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_category_product
    ADD CONSTRAINT product_category_product_product_category_id_foreign FOREIGN KEY (product_category_id) REFERENCES public.product_category(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_category_product product_category_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_category_product
    ADD CONSTRAINT product_category_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product product_collection_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_collection_id_foreign FOREIGN KEY (collection_id) REFERENCES public.product_collection(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_option product_option_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_option
    ADD CONSTRAINT product_option_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_option_value product_option_value_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_option_value
    ADD CONSTRAINT product_option_value_option_id_foreign FOREIGN KEY (option_id) REFERENCES public.product_option(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_tags product_tags_product_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_tags
    ADD CONSTRAINT product_tags_product_tag_id_foreign FOREIGN KEY (product_tag_id) REFERENCES public.product_tag(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product product_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_type_id_foreign FOREIGN KEY (type_id) REFERENCES public.product_type(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: product_variant_option product_variant_option_option_value_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_option
    ADD CONSTRAINT product_variant_option_option_value_id_foreign FOREIGN KEY (option_value_id) REFERENCES public.product_option_value(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant_option product_variant_option_variant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant_option
    ADD CONSTRAINT product_variant_option_variant_id_foreign FOREIGN KEY (variant_id) REFERENCES public.product_variant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_variant product_variant_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_variant
    ADD CONSTRAINT product_variant_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.product(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_application_method promotion_application_method_promotion_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_application_method
    ADD CONSTRAINT promotion_application_method_promotion_id_foreign FOREIGN KEY (promotion_id) REFERENCES public.promotion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_campaign_budget promotion_campaign_budget_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_campaign_budget
    ADD CONSTRAINT promotion_campaign_budget_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.promotion_campaign(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion promotion_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion
    ADD CONSTRAINT promotion_campaign_id_foreign FOREIGN KEY (campaign_id) REFERENCES public.promotion_campaign(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: promotion_promotion_rule promotion_promotion_rule_promotion_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_promotion_rule
    ADD CONSTRAINT promotion_promotion_rule_promotion_id_foreign FOREIGN KEY (promotion_id) REFERENCES public.promotion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_promotion_rule promotion_promotion_rule_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_promotion_rule
    ADD CONSTRAINT promotion_promotion_rule_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: promotion_rule_value promotion_rule_value_promotion_rule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.promotion_rule_value
    ADD CONSTRAINT promotion_rule_value_promotion_rule_id_foreign FOREIGN KEY (promotion_rule_id) REFERENCES public.promotion_rule(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: provider_identity provider_identity_auth_identity_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provider_identity
    ADD CONSTRAINT provider_identity_auth_identity_id_foreign FOREIGN KEY (auth_identity_id) REFERENCES public.auth_identity(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refund refund_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refund
    ADD CONSTRAINT refund_payment_id_foreign FOREIGN KEY (payment_id) REFERENCES public.payment(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: region_country region_country_region_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.region_country
    ADD CONSTRAINT region_country_region_id_foreign FOREIGN KEY (region_id) REFERENCES public.region(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: reservation_item reservation_item_inventory_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservation_item
    ADD CONSTRAINT reservation_item_inventory_item_id_foreign FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_item(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: return_reason return_reason_parent_return_reason_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_reason
    ADD CONSTRAINT return_reason_parent_return_reason_id_foreign FOREIGN KEY (parent_return_reason_id) REFERENCES public.return_reason(id);


--
-- Name: service_zone service_zone_fulfillment_set_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_zone
    ADD CONSTRAINT service_zone_fulfillment_set_id_foreign FOREIGN KEY (fulfillment_set_id) REFERENCES public.fulfillment_set(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_provider_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_provider_id_foreign FOREIGN KEY (provider_id) REFERENCES public.fulfillment_provider(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipping_option_rule shipping_option_rule_shipping_option_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option_rule
    ADD CONSTRAINT shipping_option_rule_shipping_option_id_foreign FOREIGN KEY (shipping_option_id) REFERENCES public.shipping_option(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_service_zone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_service_zone_id_foreign FOREIGN KEY (service_zone_id) REFERENCES public.service_zone(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipping_option shipping_option_shipping_option_type_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_shipping_option_type_id_foreign FOREIGN KEY (shipping_option_type_id) REFERENCES public.shipping_option_type(id) ON UPDATE CASCADE;


--
-- Name: shipping_option shipping_option_shipping_profile_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_option
    ADD CONSTRAINT shipping_option_shipping_profile_id_foreign FOREIGN KEY (shipping_profile_id) REFERENCES public.shipping_profile(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_location stock_location_address_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_location
    ADD CONSTRAINT stock_location_address_id_foreign FOREIGN KEY (address_id) REFERENCES public.stock_location_address(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: store_currency store_currency_store_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_currency
    ADD CONSTRAINT store_currency_store_id_foreign FOREIGN KEY (store_id) REFERENCES public.store(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

