"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const algoliasearch_1 = require("algoliasearch");
class AlgoliaModuleService {
    constructor({}, options) {
        this.client = (0, algoliasearch_1.algoliasearch)(options.appId, options.apiKey);
        this.options = options;
    }
    async getIndexName(type) {
        switch (type) {
            case "product":
                return this.options.productIndexName;
            case "productTag":
                return this.options.productTagIndexName;
            case "productCategory":
                return this.options.productCategoryIndexName;
            case "productCollection":
                return this.options.productCollectionIndexName;
            case "productVariant":
                return this.options.productVariantIndexName;
            default:
                return this.options.productIndexName;
        }
    }
    async indexData(data, type = "product") {
        const indexName = await this.getIndexName(type);
        this.client.saveObjects({
            indexName,
            objects: data.map((item) => ({
                ...item,
                // set the object ID to allow updating later
                objectID: item.id,
            })),
        });
    }
    async retrieveFromIndex(objectIDs, type = "product") {
        const indexName = await this.getIndexName(type);
        return await this.client.getObjects({
            requests: objectIDs.map((objectID) => ({
                indexName,
                objectID,
            })),
        });
    }
    async deleteFromIndex(objectIDs, type = "product") {
        const indexName = await this.getIndexName(type);
        await this.client.deleteObjects({
            indexName,
            objectIDs,
        });
    }
    async search(query, type = "product") {
        const indexName = await this.getIndexName(type);
        return await this.client.search({
            requests: [
                {
                    indexName,
                    query,
                },
            ],
        });
    }
}
exports.default = AlgoliaModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2FsZ29saWEvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLGlEQUEyRDtBQWMzRCxNQUFxQixvQkFBb0I7SUFJdkMsWUFBWSxFQUFFLEVBQUUsT0FBdUI7UUFDckMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFBLDZCQUFhLEVBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDMUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUE7SUFDeEIsQ0FBQztJQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBc0I7UUFDdkMsUUFBUSxJQUFJLEVBQUUsQ0FBQztZQUNiLEtBQUssU0FBUztnQkFDWixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUE7WUFDdEMsS0FBSyxZQUFZO2dCQUNmLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQTtZQUN6QyxLQUFLLGlCQUFpQjtnQkFDcEIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLHdCQUF3QixDQUFBO1lBQzlDLEtBQUssbUJBQW1CO2dCQUN0QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsMEJBQTBCLENBQUE7WUFDaEQsS0FBSyxnQkFBZ0I7Z0JBQ25CLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQTtZQUM3QztnQkFDRSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUE7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsU0FBUyxDQUFDLElBQStCLEVBQUUsT0FBeUIsU0FBUztRQUNqRixNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7WUFDdEIsU0FBUztZQUNULE9BQU8sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUMzQixHQUFHLElBQUk7Z0JBQ1AsNENBQTRDO2dCQUM1QyxRQUFRLEVBQUUsSUFBSSxDQUFDLEVBQUU7YUFDbEIsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUNELEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxTQUFtQixFQUFFLE9BQXlCLFNBQVM7UUFDN0UsTUFBTSxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQy9DLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBMEI7WUFDM0QsUUFBUSxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3JDLFNBQVM7Z0JBQ1QsUUFBUTthQUNULENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxLQUFLLENBQUMsZUFBZSxDQUFDLFNBQW1CLEVBQUUsT0FBeUIsU0FBUztRQUMzRSxNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDL0MsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztZQUM5QixTQUFTO1lBQ1QsU0FBUztTQUNWLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQWEsRUFBRSxPQUF5QixTQUFTO1FBQzVELE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUMvQyxPQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDOUIsUUFBUSxFQUFFO2dCQUNSO29CQUNFLFNBQVM7b0JBQ1QsS0FBSztpQkFDTjthQUNGO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztDQUNGO0FBbEVELHVDQWtFQyJ9