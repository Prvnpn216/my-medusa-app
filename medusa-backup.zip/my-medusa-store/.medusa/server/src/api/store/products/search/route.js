"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchSchema = void 0;
exports.POST = POST;
const algolia_1 = require("../../../../modules/algolia");
const zod_1 = require("zod");
exports.SearchSchema = zod_1.z.object({
    query: zod_1.z.string(),
});
async function POST(req, res) {
    const algoliaModuleService = req.scope.resolve(algolia_1.ALGOLIA_MODULE);
    const { query } = req.validatedBody;
    const results = await algoliaModuleService.search(query);
    res.json(results);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3Byb2R1Y3RzL3NlYXJjaC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFXQSxvQkFhQztBQXZCRCx5REFBNEQ7QUFFNUQsNkJBQXVCO0FBRVYsUUFBQSxZQUFZLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUNuQyxLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtDQUNsQixDQUFDLENBQUE7QUFJSyxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFpQyxFQUNqQyxHQUFtQjtJQUVuQixNQUFNLG9CQUFvQixHQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx3QkFBYyxDQUFDLENBQUE7SUFFcEYsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUE7SUFFbkMsTUFBTSxPQUFPLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxNQUFNLENBQy9DLEtBQWUsQ0FDaEIsQ0FBQTtJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7QUFDbkIsQ0FBQyJ9