"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
async function POST(req, res) {
    const eventModuleService = req.scope.resolve(utils_1.Modules.EVENT_BUS);
    await eventModuleService.emit({
        name: "algolia.sync",
        data: {},
    });
    res.send({
        message: "Syncing data to Algolia",
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2FsZ29saWEvc3luYy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUdBLG9CQVlDO0FBZEQscURBQW1EO0FBRTVDLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0lBQy9ELE1BQU0sa0JBQWtCLENBQUMsSUFBSSxDQUFDO1FBQzVCLElBQUksRUFBRSxjQUFjO1FBQ3BCLElBQUksRUFBRSxFQUFFO0tBQ1QsQ0FBQyxDQUFBO0lBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLE9BQU8sRUFBRSx5QkFBeUI7S0FDbkMsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9