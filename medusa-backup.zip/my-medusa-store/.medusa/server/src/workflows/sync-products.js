"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncProductsWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const core_flows_1 = require("@medusajs/medusa/core-flows");
const sync_products_1 = require("./steps/sync-products");
exports.syncProductsWorkflow = (0, workflows_sdk_1.createWorkflow)("sync-products", ({ filters, limit, offset }) => {
    const { data, metadata } = (0, core_flows_1.useQueryGraphStep)({
        entity: "product",
        fields: ["id", "title", "description", "handle", "thumbnail", "collection_id"],
        pagination: {
            take: limit,
            skip: offset,
        },
        filters: {
            status: "published",
            ...filters,
        },
    });
    (0, sync_products_1.syncProductsStep)({
        products: data,
    });
    return new workflows_sdk_1.WorkflowResponse({
        products: data,
        metadata,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3luYy1wcm9kdWN0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3luYy1wcm9kdWN0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBb0Y7QUFDcEYsNERBQStEO0FBQy9ELHlEQUErRTtBQVFsRSxRQUFBLG9CQUFvQixHQUFHLElBQUEsOEJBQWMsRUFDaEQsZUFBZSxFQUNmLENBQUMsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBNkIsRUFBRSxFQUFFO0lBQ3hELE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBQSw4QkFBaUIsRUFBQztRQUMzQyxNQUFNLEVBQUUsU0FBUztRQUNqQixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLGFBQWEsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQztRQUM5RSxVQUFVLEVBQUU7WUFDVixJQUFJLEVBQUUsS0FBSztZQUNYLElBQUksRUFBRSxNQUFNO1NBQ2I7UUFDRCxPQUFPLEVBQUU7WUFDUCxNQUFNLEVBQUUsV0FBVztZQUNuQixHQUFHLE9BQU87U0FDWDtLQUNGLENBQUMsQ0FBQTtJQUVGLElBQUEsZ0NBQWdCLEVBQUM7UUFDZixRQUFRLEVBQUUsSUFBSTtLQUNVLENBQUMsQ0FBQTtJQUUzQixPQUFPLElBQUksZ0NBQWdCLENBQUM7UUFDMUIsUUFBUSxFQUFFLElBQUk7UUFDZCxRQUFRO0tBQ1QsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUNGLENBQUEifQ==