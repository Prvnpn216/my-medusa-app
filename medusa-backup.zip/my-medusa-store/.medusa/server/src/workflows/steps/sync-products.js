"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncProductsStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const algolia_1 = require("../../modules/algolia");
exports.syncProductsStep = (0, workflows_sdk_1.createStep)("sync-products", async ({ products }, { container }) => {
    const algoliaModuleService = container.resolve(algolia_1.ALGOLIA_MODULE);
    const existingProducts = (await algoliaModuleService.retrieveFromIndex(products.map((product) => product.id), "product")).results.filter(Boolean);
    const newProducts = products.filter((product) => !existingProducts.some((p) => p.objectID === product.id));
    await algoliaModuleService.indexData(products, "product");
    return new workflows_sdk_1.StepResponse(undefined, {
        newProducts: newProducts.map((product) => product.id),
        existingProducts,
    });
}, 
// compensation step
async (input, { container }) => {
    if (!input) {
        return;
    }
    const algoliaModuleService = container.resolve(algolia_1.ALGOLIA_MODULE);
    if (input.newProducts) {
        await algoliaModuleService.deleteFromIndex(input.newProducts, "product");
    }
    if (input.existingProducts) {
        await algoliaModuleService.indexData(input.existingProducts, "product");
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3luYy1wcm9kdWN0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvc3luYy1wcm9kdWN0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxRUFBNEU7QUFDNUUsbURBQXNEO0FBT3pDLFFBQUEsZ0JBQWdCLEdBQUcsSUFBQSwwQkFBVSxFQUN4QyxlQUFlLEVBQ2YsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUF5QixFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMzRCxNQUFNLG9CQUFvQixHQUF5QixTQUFTLENBQUMsT0FBTyxDQUFDLHdCQUFjLENBQUMsQ0FBQTtJQUVwRixNQUFNLGdCQUFnQixHQUFHLENBQUMsTUFBTSxvQkFBb0IsQ0FBQyxpQkFBaUIsQ0FDcEUsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUNyQyxTQUFTLENBQ1YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDMUIsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FDakMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FDdEUsQ0FBQTtJQUNELE1BQU0sb0JBQW9CLENBQUMsU0FBUyxDQUNsQyxRQUFnRCxFQUNoRCxTQUFTLENBQ1YsQ0FBQTtJQUVELE9BQU8sSUFBSSw0QkFBWSxDQUFDLFNBQVMsRUFBRTtRQUNqQyxXQUFXLEVBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNyRCxnQkFBZ0I7S0FDakIsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUNELG9CQUFvQjtBQUNwQixLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUM3QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxPQUFNO0lBQ1IsQ0FBQztJQUVELE1BQU0sb0JBQW9CLEdBQXlCLFNBQVMsQ0FBQyxPQUFPLENBQUMsd0JBQWMsQ0FBQyxDQUFBO0lBRXBGLElBQUksS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RCLE1BQU0sb0JBQW9CLENBQUMsZUFBZSxDQUN4QyxLQUFLLENBQUMsV0FBVyxFQUNqQixTQUFTLENBQ1YsQ0FBQTtJQUNILENBQUM7SUFFRCxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzNCLE1BQU0sb0JBQW9CLENBQUMsU0FBUyxDQUNsQyxLQUFLLENBQUMsZ0JBQWdCLEVBQ3RCLFNBQVMsQ0FDVixDQUFBO0lBQ0gsQ0FBQztBQUNILENBQUMsQ0FDRixDQUFBIn0=