"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = algoliaSyncHandler;
const sync_products_1 = require("../workflows/sync-products");
async function algoliaSyncHandler({ container, }) {
    const logger = container.resolve("logger");
    let hasMore = true;
    let offset = 0;
    const limit = 50;
    let totalIndexed = 0;
    logger.info("Starting product indexing...");
    while (hasMore) {
        const { result: { products, metadata } } = await (0, sync_products_1.syncProductsWorkflow)(container)
            .run({
            input: {
                limit,
                offset,
            },
        });
        hasMore = offset + limit < (metadata?.count ?? 0);
        offset += limit;
        totalIndexed += products.length;
    }
    logger.info(`Successfully indexed ${totalIndexed} products`);
}
exports.config = {
    event: "algolia.sync",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxnb2xpYS1zeW5jLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL2FsZ29saWEtc3luYy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFNRSxxQ0EyQkM7QUE3QkQsOERBQWlFO0FBRWxELEtBQUssVUFBVSxrQkFBa0IsQ0FBQyxFQUMvQyxTQUFTLEdBQ007SUFDZixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQTtJQUNsQixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUE7SUFDZCxNQUFNLEtBQUssR0FBRyxFQUFFLENBQUE7SUFDaEIsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFBO0lBRXBCLE1BQU0sQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQTtJQUUzQyxPQUFPLE9BQU8sRUFBRSxDQUFDO1FBQ2YsTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRSxHQUFHLE1BQU0sSUFBQSxvQ0FBb0IsRUFBQyxTQUFTLENBQUM7YUFDN0UsR0FBRyxDQUFDO1lBQ0gsS0FBSyxFQUFFO2dCQUNMLEtBQUs7Z0JBQ0wsTUFBTTthQUNQO1NBQ0YsQ0FBQyxDQUFBO1FBRUosT0FBTyxHQUFHLE1BQU0sR0FBRyxLQUFLLEdBQUcsQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFBO1FBQ2pELE1BQU0sSUFBSSxLQUFLLENBQUE7UUFDZixZQUFZLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQTtJQUNqQyxDQUFDO0lBRUQsTUFBTSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsWUFBWSxXQUFXLENBQUMsQ0FBQTtBQUM5RCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxjQUFjO0NBQ3RCLENBQUEifQ==