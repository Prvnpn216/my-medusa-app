"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = handleProductEvents;
const sync_products_1 = require("../workflows/sync-products");
async function handleProductEvents({ event: { data }, container, }) {
    await (0, sync_products_1.syncProductsWorkflow)(container)
        .run({
        input: {
            filters: {
                id: data.id,
            },
        },
    });
}
exports.config = {
    event: ["product.created", "product.updated"],
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdC1zeW5jLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3Byb2R1Y3Qtc3luYy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFHQSxzQ0FZQztBQWRELDhEQUFpRTtBQUVsRCxLQUFLLFVBQVUsbUJBQW1CLENBQUMsRUFDaEQsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2YsU0FBUyxHQUNzQjtJQUMvQixNQUFNLElBQUEsb0NBQW9CLEVBQUMsU0FBUyxDQUFDO1NBQ2xDLEdBQUcsQ0FBQztRQUNILEtBQUssRUFBRTtZQUNMLE9BQU8sRUFBRTtnQkFDUCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7YUFDWjtTQUNGO0tBQ0YsQ0FBQyxDQUFBO0FBQ04sQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFxQjtJQUN0QyxLQUFLLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxpQkFBaUIsQ0FBQztDQUM5QyxDQUFBIn0=