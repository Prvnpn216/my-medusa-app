var a=new Intl.NumberFormat([],{style:"percent",minimumFractionDigits:2}),m=(t,e=!1)=>{let r=t||0;return e||(r=r/100),a.format(r)};export{m as f};
