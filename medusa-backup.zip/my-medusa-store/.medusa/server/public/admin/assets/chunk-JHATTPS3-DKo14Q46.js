var _="inventory_item_ids";export{_ as I};
