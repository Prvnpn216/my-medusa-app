import{ab as u}from"./index-Br34qVCR.js";function m(e,r){const[t]=u(),s={};return e.forEach(a=>{const n=r?`${r}_${a}`:a,o=t.get(n)||void 0;s[a]=o}),s}export{m as u};
