var n=(r,e)=>new Intl.NumberFormat(void 0,{style:"currency",currency:e,signDisplay:"auto"}).format(r);export{n as f};
