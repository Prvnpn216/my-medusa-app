import{aC as i}from"./index-Br34qVCR.js";var a=i("product","*categories,*shipping_profile,-variants");export{a as P};
