const http = require('http');

// Configuration
const ENDPOINT = '/admin/product-tags';
const AUTH_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY3Rvcl9pZCI6InVzZXJfMDFLMjdWNEZWNkFYVFhISDNEQjcyN1NDWDciLCJhY3Rvcl90eXBlIjoidXNlciIsImF1dGhfaWRlbnRpdHlfaWQiOiJhdXRoaWRfMDFLMjdWNEZYWVFGN1c1VFBHR0VTTldBTlkiLCJhcHBfbWV0YWRhdGEiOnsidXNlcl9pZCI6InVzZXJfMDFLMjdWNEZWNkFYVFhISDNEQjcyN1NDWDcifSwiaWF0IjoxNzU3Nzc5Mzk1LCJleHAiOjE3NTc4NjU3OTV9.4yerSwKYRGHR2XlSIqFMQClnJBbc8GtpAz6KVCkLDQk';

// Sample data for bulk creation
const productTagsData = [
    {
        "mental_clarity": {
            "tag_name": "Mental Clarity",
            "customer_friendly_description": "Sharper thinking and clearer mind",
            "mushrooms": [
                "Lions Mane",
                "Reishi"
            ]
        }
    },
    {
        "focus_concentration": {
            "tag_name": "Focus & Concentration",
            "customer_friendly_description": "Stay focused and productive",
            "mushrooms": [
                "Lions Mane",
                "Cordyceps"
            ]
        }
    },
    {
        "memory_support": {
            "tag_name": "Memory Support",
            "customer_friendly_description": "Better memory and recall",
            "mushrooms": [
                "Lions Mane"
            ]
        }
    },
    {
        "brain_health": {
            "tag_name": "Brain Health",
            "customer_friendly_description": "Support long-term brain wellness",
            "mushrooms": [
                "Lions Mane",
                "Reishi"
            ]
        }
    },
    {
        "neuroprotection": {
            "tag_name": "Neuroprotection",
            "customer_friendly_description": "Protect your brain cells naturally",
            "mushrooms": [
                "Lions Mane"
            ]
        }
    },
    {
        "cognitive_function": {
            "tag_name": "Cognitive Function",
            "customer_friendly_description": "Enhance mental performance",
            "mushrooms": [
                "Lions Mane",
                "Cordyceps"
            ]
        }
    },
    {
        "natural_energy": {
            "tag_name": "Natural Energy",
            "customer_friendly_description": "Sustained energy without crash",
            "mushrooms": [
                "Cordyceps",
                "Lions Mane"
            ]
        }
    },
    {
        "stamina_endurance": {
            "tag_name": "Stamina & Endurance",
            "customer_friendly_description": "Go further and push harder",
            "mushrooms": [
                "Cordyceps"
            ]
        }
    },
    {
        "athletic_performance": {
            "tag_name": "Athletic Performance",
            "customer_friendly_description": "Enhance your workout performance",
            "mushrooms": [
                "Cordyceps",
                "Shiitake"
            ]
        }
    },
    {
        "vitality_boost": {
            "tag_name": "Vitality Boost",
            "customer_friendly_description": "Feel more alive and energetic",
            "mushrooms": [
                "Cordyceps",
                "Reishi"
            ]
        }
    },
    {
        "sustained_energy": {
            "tag_name": "Sustained Energy",
            "customer_friendly_description": "Long-lasting energy throughout the day",
            "mushrooms": [
                "Cordyceps"
            ]
        }
    },
    {
        "recovery_support": {
            "tag_name": "Recovery Support",
            "customer_friendly_description": "Enhance physical and mental recovery",
            "mushrooms": [
                "Cordyceps",
                "Reishi"
            ]
        }
    },
    {
        "stress_relief": {
            "tag_name": "Stress Relief",
            "customer_friendly_description": "Find your calm in chaos",
            "mushrooms": [
                "Reishi",
                "Chaga"
            ]
        }
    },
    {
        "better_sleep": {
            "tag_name": "Better Sleep",
            "customer_friendly_description": "Rest deeper and wake refreshed",
            "mushrooms": [
                "Reishi"
            ]
        }
    },
    {
        "emotional_balance": {
            "tag_name": "Emotional Balance",
            "customer_friendly_description": "Feel more balanced and centered",
            "mushrooms": [
                "Reishi"
            ]
        }
    },
    {
        "relaxation": {
            "tag_name": "Relaxation",
            "customer_friendly_description": "Unwind and let go of tension",
            "mushrooms": [
                "Reishi",
                "Chaga"
            ]
        }
    },
    {
        "adaptogenic": {
            "tag_name": "Adaptogenic",
            "customer_friendly_description": "Help your body adapt to stress naturally",
            "mushrooms": [
                "Reishi",
                "Cordyceps",
                "Chaga"
            ]
        }
    },
    {
        "anxiety_support": {
            "tag_name": "Anxiety Support",
            "customer_friendly_description": "Natural support for anxious feelings",
            "mushrooms": [
                "Reishi"
            ]
        }
    },
    {
        "immune_support": {
            "tag_name": "Immune Support",
            "customer_friendly_description": "Strengthen your natural defenses",
            "mushrooms": [
                "Turkey Tail",
                "Reishi",
                "Chaga",
                "Shiitake",
                "Maitake"
            ]
        }
    },
    {
        "antioxidant_protection": {
            "tag_name": "Antioxidant Protection",
            "customer_friendly_description": "Fight free radicals naturally",
            "mushrooms": [
                "Chaga",
                "Turkey Tail",
                "Reishi"
            ]
        }
    },
    {
        "anti_inflammatory": {
            "tag_name": "Anti-Inflammatory",
            "customer_friendly_description": "Reduce inflammation naturally",
            "mushrooms": [
                "Turkey Tail",
                "Chaga",
                "Shiitake",
                "Maitake"
            ]
        }
    },
    {
        "seasonal_wellness": {
            "tag_name": "Seasonal Wellness",
            "customer_friendly_description": "Stay healthy year-round",
            "mushrooms": [
                "Turkey Tail",
                "Chaga",
                "Reishi"
            ]
        }
    },
    {
        "overall_wellness": {
            "tag_name": "Overall Wellness",
            "customer_friendly_description": "Support your total well-being",
            "mushrooms": [
                "Turkey Tail",
                "Reishi",
                "Chaga"
            ]
        }
    },
    {
        "skin_health": {
            "tag_name": "Skin Health",
            "customer_friendly_description": "Glow from the inside out",
            "mushrooms": [
                "Chaga",
                "Tremella",
                "Turkey Tail"
            ]
        }
    },
    {
        "anti_aging": {
            "tag_name": "Anti-Aging",
            "customer_friendly_description": "Age gracefully and naturally",
            "mushrooms": [
                "Chaga",
                "Reishi",
                "Tremella"
            ]
        }
    },
    {
        "natural_beauty": {
            "tag_name": "Natural Beauty",
            "customer_friendly_description": "Enhance your natural radiance",
            "mushrooms": [
                "Chaga",
                "Tremella"
            ]
        }
    },
    {
        "collagen_support": {
            "tag_name": "Collagen Support",
            "customer_friendly_description": "Support your skin's structure naturally",
            "mushrooms": [
                "Tremella",
                "Chaga"
            ]
        }
    },
    {
        "gut_health": {
            "tag_name": "Gut Health",
            "customer_friendly_description": "Support your second brain",
            "mushrooms": [
                "Turkey Tail",
                "Shiitake",
                "Maitake"
            ]
        }
    },
    {
        "digestive_comfort": {
            "tag_name": "Digestive Comfort",
            "customer_friendly_description": "Feel comfortable after meals",
            "mushrooms": [
                "Turkey Tail",
                "Shiitake"
            ]
        }
    },
    {
        "microbiome_support": {
            "tag_name": "Microbiome Support",
            "customer_friendly_description": "Feed your good bacteria",
            "mushrooms": [
                "Turkey Tail"
            ]
        }
    },
    {
        "prebiotic_benefits": {
            "tag_name": "Prebiotic Benefits",
            "customer_friendly_description": "Nourish your beneficial gut bacteria",
            "mushrooms": [
                "Turkey Tail",
                "Shiitake"
            ]
        }
    },
    {
        "gut_brain_connection": {
            "tag_name": "Gut-Brain Connection",
            "customer_friendly_description": "Support the connection between gut and mind",
            "mushrooms": [
                "Turkey Tail"
            ]
        }
    },
    {
        "heart_health": {
            "tag_name": "Heart Health",
            "customer_friendly_description": "Keep your heart strong and healthy",
            "mushrooms": [
                "Shiitake",
                "Maitake",
                "Oyster",
                "Reishi"
            ]
        }
    },
    {
        "circulation_support": {
            "tag_name": "Circulation Support",
            "customer_friendly_description": "Improve blood flow naturally",
            "mushrooms": [
                "Shiitake",
                "Cordyceps",
                "King Oyster"
            ]
        }
    },
    {
        "cholesterol_support": {
            "tag_name": "Cholesterol Support",
            "customer_friendly_description": "Support healthy cholesterol levels",
            "mushrooms": [
                "Shiitake",
                "Maitake"
            ]
        }
    },
    {
        "blood_pressure_support": {
            "tag_name": "Blood Pressure Support",
            "customer_friendly_description": "Support healthy blood pressure",
            "mushrooms": [
                "Reishi",
                "Maitake"
            ]
        }
    },
    {
        "lung_health": {
            "tag_name": "Lung Health",
            "customer_friendly_description": "Support respiratory wellness",
            "mushrooms": [
                "Cordyceps"
            ]
        }
    },
    {
        "libido_support": {
            "tag_name": "Libido Support",
            "customer_friendly_description": "Natural support for healthy intimacy",
            "mushrooms": [
                "Cordyceps"
            ]
        }
    },
    {
        "weight_management": {
            "tag_name": "Weight Management",
            "customer_friendly_description": "Support healthy weight goals",
            "mushrooms": [
                "Maitake"
            ]
        }
    },
    {
        "metabolism_support": {
            "tag_name": "Metabolism Support",
            "customer_friendly_description": "Support healthy metabolic function",
            "mushrooms": [
                "Maitake"
            ]
        }
    },
    {
        "blood_sugar_support": {
            "tag_name": "Blood Sugar Support",
            "customer_friendly_description": "Support healthy blood sugar levels",
            "mushrooms": [
                "Maitake"
            ]
        }
    }
];

// Function to make a single curl request
function makeRequest(data, index) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify(data);
        
        const options = {
            hostname: 'localhost',
            port: 9000,
            path: ENDPOINT,
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${AUTH_TOKEN}`,
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = http.request(options, (res) => {
            let responseData = '';

            res.on('data', (chunk) => {
                responseData += chunk;
            });

            res.on('end', () => {
                console.log(`Request ${index + 1} completed with status: ${res.statusCode}`);
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    console.log(`✅ Success: Created product tag "${data.value}"`);
                    resolve({ success: true, data: responseData, statusCode: res.statusCode });
                } else {
                    console.log(`❌ Error: Failed to create product tag "${data.value}"`);
                    console.log(`Response: ${responseData}`);
                    resolve({ success: false, data: responseData, statusCode: res.statusCode });
                }
            });
        });

        req.on('error', (error) => {
            console.log(`❌ Request ${index + 1} failed:`, error.message);
            reject(error);
        });

        req.write(postData);
        req.end();
    });
}

// Function to make requests with delay
async function makeBulkRequests(dataArray, delayMs = 1000) {
    console.log(`🚀 Starting bulk creation of ${dataArray.length} product tags...\n`);
    
    const results = [];
    
    for (let i = 0; i < dataArray.length; i++) {
        try {
            const slug = Object.keys(dataArray[i])[0];
            const tag_name = dataArray[i][slug].tag_name;
            const description = dataArray[i][slug].customer_friendly_description;
            const mushrooms = dataArray[i][slug].mushrooms;
            const metadata = {
                slug: slug,
                description: description,
                mushrooms: mushrooms
            };
            
            const data = {
                value: tag_name,
                metadata: metadata
            }
            const result = await makeRequest(data, i);
            results.push(result);
            
            // Add delay between requests to avoid overwhelming the server
            if (i < dataArray.length - 1) {
                console.log(`⏳ Waiting ${delayMs}ms before next request...\n`);
                await new Promise(resolve => setTimeout(resolve, delayMs));
            }
        } catch (error) {
            console.log(`❌ Request ${i + 1} failed with error:`, error.message);
            results.push({ success: false, error: error.message });
        }
    }
    
    // Summary
    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    
    console.log(`\n📊 Summary:`);
    console.log(`✅ Successful: ${successful}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`📈 Total: ${results.length}`);
    
    return results;
}

// Main execution
async function main() {
    console.log('🚀 Starting bulk creation of 9 product tags...\n');
    await makeBulkRequests(productTagsData, 1000); // 1 second delay
    
}

// Run the script
if (require.main === module) {
    main().catch(console.error);
}

main();
