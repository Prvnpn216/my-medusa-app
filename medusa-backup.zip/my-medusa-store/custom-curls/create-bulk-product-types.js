const http = require('http');

// Configuration
const ENDPOINT = '/admin/product-types';
const AUTH_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY3Rvcl9pZCI6InVzZXJfMDFLMjdWNEZWNkFYVFhISDNEQjcyN1NDWDciLCJhY3Rvcl90eXBlIjoidXNlciIsImF1dGhfaWRlbnRpdHlfaWQiOiJhdXRoaWRfMDFLMjdWNEZYWVFGN1c1VFBHR0VTTldBTlkiLCJhcHBfbWV0YWRhdGEiOnsidXNlcl9pZCI6InVzZXJfMDFLMjdWNEZWNkFYVFhISDNEQjcyN1NDWDcifSwiaWF0IjoxNzU3Nzc5Mzk1LCJleHAiOjE3NTc4NjU3OTV9.4yerSwKYRGHR2XlSIqFMQClnJBbc8GtpAz6KVCkLDQk';

// Sample data for bulk creation
const productTypesData = [ {
    "mind": {
      "category_name": "Mind",
      "description": "Cognitive support, memory, focus & mental clarity",
      "color": "#4A90E2",
      "icon": "brain",
      "tags": [
        "mental_clarity",
        "focus_concentration", 
        "memory_support",
        "brain_health",
        "neuroprotection",
        "cognitive_function"
      ]
    }
    },{
    "energy": {
      "category_name": "Energy", 
      "description": "Natural energy, stamina & vitality boost",
      "color": "#F5A623",
      "icon": "energy",
      "tags": [
        "natural_energy",
        "stamina_endurance",
        "athletic_performance",
        "vitality_boost",
        "sustained_energy",
        "recovery_support"
      ]
    }},{
    "calm_relaxation": {
      "category_name": "Calm & Relaxation",
      "description": "Stress relief, better sleep & emotional balance",
      "color": "#7ED321",
      "icon": "zen", 
      "tags": [
        "stress_relief",
        "better_sleep",
        "emotional_balance",
        "relaxation",
        "adaptogenic",
        "anxiety_support"
      ]
    }},{
    "immunity": {
      "category_name": "Immunity",
      "description": "Immune system support & overall wellness",
      "color": "#BD10E0",
      "icon": "shield",
      "tags": [
        "immune_support",
        "antioxidant_protection",
        "anti_inflammatory",
        "seasonal_wellness",
        "overall_wellness"
      ]
    }},{
    "beauty": {
      "category_name": "Beauty",
      "description": "Skin health, anti-aging & natural radiance",
      "color": "#F8E71C", 
      "icon": "sparkles",
      "tags": [
        "skin_health",
        "anti_aging",
        "natural_beauty",
        "collagen_support"
      ]
    }},{
    "gut": {
      "category_name": "Gut",
      "description": "Digestive health & gut microbiome support",
      "color": "#50E3C2",
      "icon": "gut",
      "tags": [
        "gut_health",
        "digestive_comfort",
        "microbiome_support",
        "prebiotic_benefits",
        "gut_brain_connection"
      ]
    }},{
    "heart": {
      "category_name": "Heart",
      "description": "Cardiovascular health & circulation support", 
      "color": "#D0021B",
      "icon": "heart",
      "tags": [
        "heart_health",
        "circulation_support",
        "cholesterol_support",
        "blood_pressure_support"
      ]
    }},{
    "wellness": {
      "category_name": "Wellness",
      "description": "Specialized health benefits & metabolic support",
      "color": "#9013FE",
      "icon": "wellness",
      "tags": [
        "lung_health",
        "libido_support",
        "weight_management",
        "metabolism_support",
        "blood_sugar_support"
      ]
    }}
];

// Function to make a single curl request
function makeRequest(data, index) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify(data);
        
        const options = {
            hostname: 'localhost',
            port: 9000,
            path: ENDPOINT,
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${AUTH_TOKEN}`,
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = http.request(options, (res) => {
            let responseData = '';

            res.on('data', (chunk) => {
                responseData += chunk;
            });

            res.on('end', () => {
                console.log(`Request ${index + 1} completed with status: ${res.statusCode}`);
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    console.log(`✅ Success: Created product tag "${data.value}"`);
                    resolve({ success: true, data: responseData, statusCode: res.statusCode });
                } else {
                    console.log(`❌ Error: Failed to create product tag "${data.value}"`);
                    console.log(`Response: ${responseData}`);
                    resolve({ success: false, data: responseData, statusCode: res.statusCode });
                }
            });
        });

        req.on('error', (error) => {
            console.log(`❌ Request ${index + 1} failed:`, error.message);
            reject(error);
        });

        req.write(postData);
        req.end();
    });
}

// Function to make requests with delay
async function makeBulkRequests(dataArray, delayMs = 1000) {
    console.log(`🚀 Starting bulk creation of ${dataArray.length} product tags...\n`);
    
    const results = [];
    
    for (let i = 0; i < dataArray.length; i++) {
        try {
            const slug = Object.keys(dataArray[i])[0];
            const category_name = dataArray[i][slug].category_name;
            const description = dataArray[i][slug].description;
            const tags = dataArray[i][slug].tags;
            const metadata = {
                slug: slug,
                description: description,
                tags: tags,
                color: dataArray[i][slug].color,
                icon: dataArray[i][slug].icon
            };
            
            const data = {
                value: category_name,
                metadata: metadata
            }
            const result = await makeRequest(data, i);
            results.push(result);
            
            // Add delay between requests to avoid overwhelming the server
            if (i < dataArray.length - 1) {
                console.log(`⏳ Waiting ${delayMs}ms before next request...\n`);
                await new Promise(resolve => setTimeout(resolve, delayMs));
            }
        } catch (error) {
            console.log(`❌ Request ${i + 1} failed with error:`, error.message);
            results.push({ success: false, error: error.message });
        }
    }
    
    // Summary
    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    
    console.log(`\n📊 Summary:`);
    console.log(`✅ Successful: ${successful}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`📈 Total: ${results.length}`);
    
    return results;
}

// Main execution
async function main() {
    console.log('🚀 Starting bulk creation of 9 product tags...\n');
    await makeBulkRequests(productTypesData, 1000); // 1 second delay
    
}

// Run the script
if (require.main === module) {
    main().catch(console.error);
}

main();
