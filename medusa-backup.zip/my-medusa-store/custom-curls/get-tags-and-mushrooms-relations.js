
const collections = [{
    "mental_clarity_collection": {
      "collection_name": "Mental Clarity",
      "description": "Sharpen your mind and boost cognitive performance",
      "target_audience": "Students, professionals, knowledge workers",
      "tags": [
        "mental_clarity",
        "focus_concentration",
        "memory_support", 
        "cognitive_function",
        "brain_health"
      ]
    }},{
    "natural_energy_collection": {
      "collection_name": "Natural Energy",
      "description": "Sustainable energy without the crash",
      "target_audience": "Active individuals, athletes, busy professionals",
      "tags": [
        "natural_energy",
        "sustained_energy",
        "vitality_boost",
        "stamina_endurance"
      ]
    }},{
    "stress_relief_collection": {
      "collection_name": "Stress Relief",
      "description": "Find your calm in the chaos of daily life",
      "target_audience": "Stressed professionals, busy parents, overwhelmed individuals",
      "tags": [
        "stress_relief",
        "better_sleep",
        "emotional_balance",
        "relaxation",
        "adaptogenic"
      ]
    }},{
    "immune_defense_collection": {
      "collection_name": "Immune Defense",
      "description": "Strengthen your body's natural defenses",
      "target_audience": "Health-conscious individuals, seasonal wellness seekers",
      "tags": [
        "immune_support",
        "antioxidant_protection",
        "anti_inflammatory",
        "seasonal_wellness",
        "overall_wellness"
      ]
    }},{
    "radiant_skin_collection": {
      "collection_name": "Radiant Skin",
      "description": "Beauty that starts from within",
      "target_audience": "Beauty enthusiasts, anti-aging focused, skin health conscious",
      "tags": [
        "skin_health",
        "anti_aging", 
        "natural_beauty",
        "collagen_support",
        "antioxidant_protection"
      ]
    }},{
    "digestive_wellness_collection": {
      "collection_name": "Digestive Wellness", 
      "description": "Support your second brain - your gut",
      "target_audience": "Digestive health conscious, gut health enthusiasts",
      "tags": [
        "gut_health",
        "digestive_comfort",
        "microbiome_support",
        "prebiotic_benefits",
        "gut_brain_connection"
      ]
    }},{
    "heart_health_collection": {
      "collection_name": "Heart Health",
      "description": "Support your cardiovascular system naturally",
      "target_audience": "Health-conscious adults, cardiovascular wellness focused",
      "tags": [
        "heart_health",
        "circulation_support",
        "cholesterol_support",
        "blood_pressure_support"
      ]
    }},{
    "peak_performance_collection": {
      "collection_name": "Peak Performance",
      "description": "For athletes and active individuals seeking optimal performance",
      "target_audience": "Athletes, fitness enthusiasts, active professionals", 
      "tags": [
        "athletic_performance",
        "natural_energy",
        "stamina_endurance",
        "focus_concentration",
        "recovery_support"
      ]
    }},{
    "sleep_recovery_collection": {
      "collection_name": "Sleep & Recovery",
      "description": "Better rest and recovery for optimal wellness",
      "target_audience": "People with sleep issues, recovery-focused individuals",
      "tags": [
        "better_sleep",
        "stress_relief",
        "relaxation",
        "recovery_support",
        "adaptogenic"
      ]
    }},{
    "wellness_starter_collection": {
      "collection_name": "Wellness Starter Kit",
      "description": "Perfect introduction to functional mushrooms",
      "target_audience": "Mushroom newcomers, wellness beginners",
      "tags": [
        "mental_clarity",
        "stress_relief",
        "natural_energy",
        "immune_support",
        "overall_wellness"
      ]
    }},{
    "metabolic_health_collection": {
      "collection_name": "Metabolic Health",
      "description": "Support healthy weight and metabolic function",
      "target_audience": "People focused on weight management and metabolic wellness",
      "tags": [
        "weight_management",
        "metabolism_support",
        "blood_sugar_support"
      ]
    }},{
    "anxiety_calm_collection": {
      "collection_name": "Anxiety & Calm",
      "description": "Natural support for anxious minds seeking peace",
      "target_audience": "People dealing with anxiety, stress, or overthinking",
      "tags": [
        "anxiety_support",
        "stress_relief",
        "emotional_balance",
        "relaxation",
        "adaptogenic"
      ]
    }}
  ];

const categories = [ {
    "mind": {
      "category_name": "Mind",
      "description": "Cognitive support, memory, focus & mental clarity",
      "color": "#4A90E2",
      "icon": "brain",
      "tags": [
        "mental_clarity",
        "focus_concentration", 
        "memory_support",
        "brain_health",
        "neuroprotection",
        "cognitive_function"
      ]
    }
    },{
    "energy": {
      "category_name": "Energy", 
      "description": "Natural energy, stamina & vitality boost",
      "color": "#F5A623",
      "icon": "energy",
      "tags": [
        "natural_energy",
        "stamina_endurance",
        "athletic_performance",
        "vitality_boost",
        "sustained_energy",
        "recovery_support"
      ]
    }},{
    "calm_relaxation": {
      "category_name": "Calm & Relaxation",
      "description": "Stress relief, better sleep & emotional balance",
      "color": "#7ED321",
      "icon": "zen", 
      "tags": [
        "stress_relief",
        "better_sleep",
        "emotional_balance",
        "relaxation",
        "adaptogenic",
        "anxiety_support"
      ]
    }},{
    "immunity": {
      "category_name": "Immunity",
      "description": "Immune system support & overall wellness",
      "color": "#BD10E0",
      "icon": "shield",
      "tags": [
        "immune_support",
        "antioxidant_protection",
        "anti_inflammatory",
        "seasonal_wellness",
        "overall_wellness"
      ]
    }},{
    "beauty": {
      "category_name": "Beauty",
      "description": "Skin health, anti-aging & natural radiance",
      "color": "#F8E71C", 
      "icon": "sparkles",
      "tags": [
        "skin_health",
        "anti_aging",
        "natural_beauty",
        "collagen_support"
      ]
    }},{
    "gut": {
      "category_name": "Gut",
      "description": "Digestive health & gut microbiome support",
      "color": "#50E3C2",
      "icon": "gut",
      "tags": [
        "gut_health",
        "digestive_comfort",
        "microbiome_support",
        "prebiotic_benefits",
        "gut_brain_connection"
      ]
    }},{
    "heart": {
      "category_name": "Heart",
      "description": "Cardiovascular health & circulation support", 
      "color": "#D0021B",
      "icon": "heart",
      "tags": [
        "heart_health",
        "circulation_support",
        "cholesterol_support",
        "blood_pressure_support"
      ]
    }},{
    "wellness": {
      "category_name": "Wellness",
      "description": "Specialized health benefits & metabolic support",
      "color": "#9013FE",
      "icon": "wellness",
      "tags": [
        "lung_health",
        "libido_support",
        "weight_management",
        "metabolism_support",
        "blood_sugar_support"
      ]
    }}
];

const tags = [
    {
    "mental_clarity": {
      "tag_name": "Mental Clarity",
      "customer_friendly_description": "Sharper thinking and clearer mind",
      "mushrooms": ["Lions Mane", "Reishi"]
    }
    },
    {
    "focus_concentration": {
      "tag_name": "Focus & Concentration", 
      "customer_friendly_description": "Stay focused and productive",
      "mushrooms": ["Lions Mane", "Cordyceps"]
    }
    },
    {
    "memory_support": {
      "tag_name": "Memory Support",
      "customer_friendly_description": "Better memory and recall",
      "mushrooms": ["Lions Mane"]
    }
    },
    {
    "brain_health": {
      "tag_name": "Brain Health",
      "customer_friendly_description": "Support long-term brain wellness",
      "mushrooms": ["Lions Mane", "Reishi"]
    }
    },
    {
    "neuroprotection": {
      "tag_name": "Neuroprotection",
      "customer_friendly_description": "Protect your brain cells naturally",
      "mushrooms": ["Lions Mane"]
    }
    },
    {
    "cognitive_function": {
      "tag_name": "Cognitive Function",
      "customer_friendly_description": "Enhance mental performance",
      "mushrooms": ["Lions Mane", "Cordyceps"]
    }
    },
    { 
    "natural_energy": {
      "tag_name": "Natural Energy",
      "customer_friendly_description": "Sustained energy without crash",
      "mushrooms": ["Cordyceps", "Lions Mane"]
    }
    },
    {
    "stamina_endurance": {
      "tag_name": "Stamina & Endurance",
      "customer_friendly_description": "Go further and push harder",
      "mushrooms": ["Cordyceps"]
    }
    },
    {
    "athletic_performance": {
      "tag_name": "Athletic Performance",
      "customer_friendly_description": "Enhance your workout performance",
      "mushrooms": ["Cordyceps", "Shiitake"]
    }
    },
    {
    "vitality_boost": {
      "tag_name": "Vitality Boost", 
      "customer_friendly_description": "Feel more alive and energetic",
      "mushrooms": ["Cordyceps", "Reishi"]
    }
    },
    {
    "sustained_energy": {
      "tag_name": "Sustained Energy",
      "customer_friendly_description": "Long-lasting energy throughout the day",
      "mushrooms": ["Cordyceps"]
    }
    },
    {
    "recovery_support": {
      "tag_name": "Recovery Support",
      "customer_friendly_description": "Enhance physical and mental recovery", 
      "mushrooms": ["Cordyceps", "Reishi"]
    }
    },
    {
    "stress_relief": {
      "tag_name": "Stress Relief",
      "customer_friendly_description": "Find your calm in chaos",
      "mushrooms": ["Reishi", "Chaga"]
    }
    },
    {
    "better_sleep": {
      "tag_name": "Better Sleep",
      "customer_friendly_description": "Rest deeper and wake refreshed",
      "mushrooms": ["Reishi"]
    }
    },
    {
    "emotional_balance": {
      "tag_name": "Emotional Balance",
      "customer_friendly_description": "Feel more balanced and centered", 
      "mushrooms": ["Reishi"]
    }
    },
    {
    "relaxation": {
      "tag_name": "Relaxation",
      "customer_friendly_description": "Unwind and let go of tension",
      "mushrooms": ["Reishi", "Chaga"]
    }
    },
    {
    "adaptogenic": {
      "tag_name": "Adaptogenic",
      "customer_friendly_description": "Help your body adapt to stress naturally",
      "mushrooms": ["Reishi", "Cordyceps", "Chaga"]
    }
    },
    {
    "anxiety_support": {
      "tag_name": "Anxiety Support",
      "customer_friendly_description": "Natural support for anxious feelings",
      "mushrooms": ["Reishi"]
    }
    },
    {
    "immune_support": {
      "tag_name": "Immune Support",
      "customer_friendly_description": "Strengthen your natural defenses",
      "mushrooms": ["Turkey Tail", "Reishi", "Chaga", "Shiitake", "Maitake"]
    }
    },
    {
    "antioxidant_protection": {
      "tag_name": "Antioxidant Protection", 
      "customer_friendly_description": "Fight free radicals naturally",
      "mushrooms": ["Chaga", "Turkey Tail", "Reishi"]
    }
    },
    {
    "anti_inflammatory": {
      "tag_name": "Anti-Inflammatory",
      "customer_friendly_description": "Reduce inflammation naturally",
      "mushrooms": ["Turkey Tail", "Chaga", "Shiitake", "Maitake"]
    }
    },
    {
    "seasonal_wellness": {
      "tag_name": "Seasonal Wellness",
      "customer_friendly_description": "Stay healthy year-round",
      "mushrooms": ["Turkey Tail", "Chaga", "Reishi"]
    }
    },
    {
    "overall_wellness": {
      "tag_name": "Overall Wellness",
      "customer_friendly_description": "Support your total well-being", 
      "mushrooms": ["Turkey Tail", "Reishi", "Chaga"]
    }
    },
    {
    "skin_health": {
      "tag_name": "Skin Health",
      "customer_friendly_description": "Glow from the inside out",
      "mushrooms": ["Chaga", "Tremella", "Turkey Tail"]
    }
    },
    {
    "anti_aging": {
      "tag_name": "Anti-Aging",
      "customer_friendly_description": "Age gracefully and naturally",
      "mushrooms": ["Chaga", "Reishi", "Tremella"]
    }
    },
    {
    "natural_beauty": {
      "tag_name": "Natural Beauty",
      "customer_friendly_description": "Enhance your natural radiance",
      "mushrooms": ["Chaga", "Tremella"]
    }
    },
    {
    "collagen_support": {
      "tag_name": "Collagen Support", 
      "customer_friendly_description": "Support your skin's structure naturally",
      "mushrooms": ["Tremella", "Chaga"]
    }
    },
    {
    "gut_health": {
      "tag_name": "Gut Health",
      "customer_friendly_description": "Support your second brain",
      "mushrooms": ["Turkey Tail", "Shiitake", "Maitake"]
    }
    },
    {
    "digestive_comfort": {
      "tag_name": "Digestive Comfort",
      "customer_friendly_description": "Feel comfortable after meals",
      "mushrooms": ["Turkey Tail", "Shiitake"]
    }
    },
    {
    "microbiome_support": {
      "tag_name": "Microbiome Support",
      "customer_friendly_description": "Feed your good bacteria",
      "mushrooms": ["Turkey Tail"]
    }
    },
    {
    "prebiotic_benefits": {
      "tag_name": "Prebiotic Benefits", 
      "customer_friendly_description": "Nourish your beneficial gut bacteria",
      "mushrooms": ["Turkey Tail", "Shiitake"]
    }
    },
    {
    "gut_brain_connection": {
      "tag_name": "Gut-Brain Connection",
      "customer_friendly_description": "Support the connection between gut and mind",
      "mushrooms": ["Turkey Tail"]
    }
    },
    {
    "heart_health": {
      "tag_name": "Heart Health",
      "customer_friendly_description": "Keep your heart strong and healthy",
      "mushrooms": ["Shiitake", "Maitake", "Oyster", "Reishi"]
    }
    },
    {
    "circulation_support": {
      "tag_name": "Circulation Support",
      "customer_friendly_description": "Improve blood flow naturally",
      "mushrooms": ["Shiitake", "Cordyceps", "King Oyster"]
    }
    },
    {
    "cholesterol_support": {
      "tag_name": "Cholesterol Support",
      "customer_friendly_description": "Support healthy cholesterol levels", 
      "mushrooms": ["Shiitake", "Maitake"]
    }
    },
    {
    "blood_pressure_support": {
      "tag_name": "Blood Pressure Support",
      "customer_friendly_description": "Support healthy blood pressure",
      "mushrooms": ["Reishi", "Maitake"]
    }
    },
    {
    "lung_health": {
      "tag_name": "Lung Health",
      "customer_friendly_description": "Support respiratory wellness",
      "mushrooms": ["Cordyceps"]
    }
    },
    {
    "libido_support": {
      "tag_name": "Libido Support",
      "customer_friendly_description": "Natural support for healthy intimacy",
      "mushrooms": ["Cordyceps"]
    }
    },
    {
    "weight_management": {
      "tag_name": "Weight Management",
      "customer_friendly_description": "Support healthy weight goals",
      "mushrooms": ["Maitake"]
    }
    },
    {
    "metabolism_support": {
      "tag_name": "Metabolism Support", 
      "customer_friendly_description": "Support healthy metabolic function",
      "mushrooms": ["Maitake"]
    }
    },
    {
    "blood_sugar_support": {
      "tag_name": "Blood Sugar Support",
      "customer_friendly_description": "Support healthy blood sugar levels",
      "mushrooms": ["Maitake"]
    }}
];
const category_mushrooms = {};
const collection_mushrooms = {};
const tag_mushrooms = {};
for (const collection of collections) {
    const collection_name = Object.keys(collection)[0];
    const collection_tags = collection[collection_name].tags; // Rename to avoid conflict
    const tag_mushrooms= [];
    collection_mushrooms[collection_name] = {}; // Initialize the object first
    collection_mushrooms[collection_name]["tags"] = collection_tags.join("','");
    for (const tag_name of collection_tags) {
        // Find the tag object in the tags array
        const tag_obj = tags.find(tag => Object.keys(tag)[0] === tag_name);
        if (tag_obj) {
            const mushrooms = tag_obj[tag_name].mushrooms;
            tag_mushrooms.push(mushrooms);
        }else{
            console.log("tag_name", tag_name, "not found in tags array");
        }
    }
    collection_mushrooms[collection_name]["mushrooms"] = [...new Set(tag_mushrooms.flat())].join(",");
}

for (const category of categories) {
    const category_name = Object.keys(category)[0];
    const category_tags = category[category_name].tags;
    const tag_mushrooms= [];
    category_mushrooms[category_name] = {};
    category_mushrooms[category_name]["tags"] = category_tags.join("','");
    for (const tag_name of category_tags) {
        const tag_obj = tags.find(tag => Object.keys(tag)[0] === tag_name);
        if (tag_obj) {
            const mushrooms = tag_obj[tag_name].mushrooms;
            tag_mushrooms.push(mushrooms);
        }else{
            console.log("tag_name", tag_name, "not found in tags array");
        }
    }
    category_mushrooms[category_name]["mushrooms"] = [...new Set(tag_mushrooms.flat())].join(",");
}

for (const tag of tags) {
    const tag_name = Object.keys(tag)[0];
    const mushrooms = tag[tag_name].mushrooms;
    tag_mushrooms[tag_name] = [...new Set(mushrooms)];
}

// console.log("tag_mushrooms", JSON.stringify(tag_mushrooms, null, 2));

console.log("collection_mushrooms", JSON.stringify(collection_mushrooms, null, 2));
// console.log("category_mushrooms", JSON.stringify(category_mushrooms, null, 2));