import { loadEnv, defineConfig } from '@medusajs/framework/utils'

loadEnv(process.env.NODE_ENV || 'development', process.cwd())

module.exports = defineConfig({
  projectConfig: {
    databaseUrl: process.env.DATABASE_URL,
    http: {
      storeCors: process.env.STORE_CORS || "http://localhost:8000",
      adminCors: process.env.ADMIN_CORS || "http://localhost:9000",
      authCors: process.env.AUTH_CORS || "http://localhost:8000,http://localhost:9000",
      jwtSecret: process.env.JWT_SECRET || "supersecret",
      cookieSecret: process.env.COOKIE_SECRET || "supersecret",
    },
    databaseDriverOptions: {
      ssl: false,
      sslmode: "disable",
    },
  },
  modules: [
    {
      resolve: "./src/modules/algolia",
      options: {
        appId: process.env.ALGOLIA_APP_ID!,
        apiKey: process.env.ALGOLIA_API_KEY!,
        productIndexName: process.env.ALGOLIA_PRODUCT_INDEX_NAME!,
        productTagIndexName: process.env.ALGOLIA_PRODUCT_TAG_INDEX_NAME!,
        productCategoryIndexName: process.env.ALGOLIA_PRODUCT_CATEGORY_INDEX_NAME!,
        productCollectionIndexName: process.env.ALGOLIA_PRODUCT_COLLECTION_INDEX_NAME!,
        productVariantIndexName: process.env.ALGOLIA_PRODUCT_VARIANT_INDEX_NAME!,
      },
    },
  ],
})
